BioCManagerLibraries <- c()
requiredLibraries <- c(BioCManagerLibraries, 
                       "shiny",
                       "grid",
                       "VennDiagram",
                       "nVennR",
                       "visNetwork",
                       "igraph",
                       "DT",
                       'dplyr',
                       'dbplyr',
                       "shinyWidgets",
                       "ggVennDiagram",
                       "ggplot2",
                       "readxl",
                       "shinythemes",
                       "stringr",
                       'DBI',
                       'pool')


for (packageName in requiredLibraries){
  if (!is.element(packageName, installed.packages()[,1])){
    print(paste("Installing package: ", packageName))
    if (packageName %in% BioCManagerLibraries) {
      BiocManager::install(packageName, type="binary")#INSTALL_opts = '--no-lock')
    }
    else {
      install.packages(packageName, dependencies = TRUE, INSTALL_opts = '--no-lock')
      #install.packages("table1", dependencies = TRUE, INSTALL_opts = '--no-lock')#type="binary")#
      
    }
    
  } 
  
  suppressMessages(library(packageName, character.only = TRUE))
  print(paste("Loaded package: ", packageName))
  
}

add_SL_cluster <- function(vector_attributes, comp, number_to_include, tag){
  more_than_n_SL <- which(comp$csize > number_to_include)
  more_than_n_SL <- which(comp$membership %in% more_than_n_SL)
  more_than_n_SL <- names(comp$membership[more_than_n_SL])
  vector_attributes[more_than_n_SL] = tag
  return(vector_attributes)
}


####### SL connectivity #######

# con <- pool::dbPool(drv = RSQLite::SQLite(), 
#                     dbname = "KB/SLKB_sqlite3")
con <- pool::dbPool(
  drv = RMySQL::MySQL(),
  dbname = "SLKB_mysql",
  host = "slkb-mysql.mysql.database.azure.com",
  username = "guest",
  password = "password"
)

init.study_SL <- 'SELECT * FROM CDKO_ORIGINAL_SL_RESULTS'

study_SL_init <- tbl( con, sql(sqlInterpolate(con, init.study_SL))) %>% filter(gene_1 != gene_2) %>% collect()
table(study_SL_init$SL_or_not)

unique(study_SL_init[study_SL_init$study_origin == '33637726',]$cell_line_origin)

study_SL_init <- tbl( con, sql(sqlInterpolate(con, init.study_SL))) %>% filter(SL_or_not == 'SL') %>% filter(gene_1 != gene_2) %>% collect()
study_SL_init

total_clusters <- 0
total_available_clusters_sizes <- 0
giant_total_clusters <- 0
mega_total_clusters <- 0
for (study in sort(unique(study_SL_init$study_origin))){
  print(study)
  # get current study
  curr_study <- study_SL_init[study_SL_init$study_origin == study, ]
  
  for (cell_line in sort(unique(curr_study$cell_line_origin))){
    
    # get current cell line (SL run)
    curr_subset <- curr_study[curr_study$cell_line_origin == cell_line, ]
    
    curr.graph <- graph_from_data_frame(curr_subset[,c('gene_1', 'gene_2')], directed = F)
    comp <- components(curr.graph)
    print(paste('SL clusters with more than 2 members:', sum(comp$csize > 2)))
    #print(comp$csize[comp$csize > 2])
    total_available_clusters_sizes <- total_available_clusters_sizes + sum(comp$csize[comp$csize > 2])
    total_clusters <- total_clusters + length(comp$csize[comp$csize > 2])
    giant_total_clusters <- giant_total_clusters + length(comp$csize[comp$csize > 10])
    mega_total_clusters <- mega_total_clusters+ length(comp$csize[comp$csize > 20])
  }
}

print(paste('total_available_clusters_sizes:', total_available_clusters_sizes))
print(paste('total_clusters:', total_clusters))
print(paste('giant_total_clusters:', giant_total_clusters))
print(paste('mega_total_clusters:', mega_total_clusters))

####### Identify Hub Genes #######

hub_genes <- list()

for (study in sort(unique(study_SL_init$study_origin))){
  
  # get current study
  study <- '29452643'
  curr_study <- study_SL_init[study_SL_init$study_origin == study, ]
  
  hub_genes[[study]] <- list()
  
  all_cell_lines <- sort(unique(curr_study$cell_line_origin))
  
  if (length(all_cell_lines) == 1){
    next
  }
  print(study)
  
  for (cell_line in all_cell_lines){
    if ((study == "29251726") & (cell_line == "HT29")){
      next
    }
    
    # get current cell line (SL run)
    curr_subset <- curr_study[curr_study$cell_line_origin == cell_line, ]
    
    gene_freqs <- sort(table(c(curr_subset$gene_1, curr_subset$gene_2)), decreasing = T)
    
    # get top 10%
    hub_genes[[study]][[cell_line]] <- names(gene_freqs)[1:round(length(gene_freqs) * 0.20)]
    
  }
  
  overlapping_hub <- Reduce(intersect, hub_genes[[study]])
  print(paste('Available Cell Lines:', paste0(sort(unique(curr_study$cell_line_origin)), collapse = ';')))
  print(paste('Total intersecting hub size:', length(overlapping_hub)))
  print(overlapping_hub)
  
  print('------')
}

####### SL connectivity (Raw) #######
# 
# curr.graph <- graph_from_data_frame(study_SL_init[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin')], directed = F)
# comp <- components(curr.graph)
# 
# vector_attributes <- rep('Lone SL', length(V(curr.graph)))
# names(vector_attributes) <- V(curr.graph)$name
# 
# vector_attributes <- add_SL_cluster(vector_attributes, comp, 2, 'SL Cluster')
# vector_attributes <- add_SL_cluster(vector_attributes, comp, 10, 'SL Giant Cluster')
# vector_attributes <- add_SL_cluster(vector_attributes, comp, 20, 'SL Mega Cluster')
# 
# curr.graph <- set_vertex_attr(curr.graph, 'group', names(vector_attributes), vector_attributes)
# 
# curr.graph <- toVisNetworkData(curr.graph)
# 
# #edges$color <- 
#   
# 
# color_cl <- rainbow(length(sort(unique(curr.graph$edges$cell_line_origin))))
# names(color_cl) <- sort(unique(curr.graph$edges$cell_line_origin))
# 
# color_vector <- rep('', length(curr.graph$edges$from))
# for (cl in unique(curr.graph$edges$cell_line_origin)){
#   color_vector[which(cl == curr.graph$edges$cell_line_origin)] <- color_cl[cl]
# }
# 
# curr.graph$edges$color <- color_vector
# 
# curr.graph <- visNetwork(curr.graph$nodes, curr.graph$edges, width = 1920, height = 1920) %>%
#   visLayout(randomSeed = 42) %>%
#   visNodes(size = 10) %>%
#   visGroups(groupname = "Lone SL", color = "blue") %>%
#   visGroups(groupname = "SL Cluster", color = "red") %>%
#   visGroups(groupname = "SL Giant Cluster", color = "yellow") %>%
#   visGroups(groupname = "SL Mega Cluster", color = "green") %>%
#   visPhysics(solver = "forceAtlas2Based",
#              forceAtlas2Based = list(gravitationalConstant = -100),
#              hierarchicalRepulsion = list(avoidOverlap = 0.99)) %>%
#   visOptions(highlightNearest = list(enabled = TRUE, degree = 1,
#                                      labelOnly = T, hover = TRUE),
#              nodesIdSelection = TRUE,
#              selectedBy = list(variable = "group", multiple = TRUE)) %>%
#   visLegend(useGroups = T, main = 'Legend', position = 'right')
# 
# curr.graph %>% visSave(file = "KB/network.html", background = "white")



####### Create Venn Diagrams #######

direct_area_names <- c("1, 0, 0, 0, 0 (MEDIAN-B/NB Score)", #1
                       "0, 1, 0, 0, 0 (sgRNA-Derived B/NB Score)", #2
                       "0, 0, 1, 0, 0 (HORLBECK-Score)", #3
                       "0, 0, 0, 1, 0 (MAGECK-Score)", #4
                       "0, 0, 0, 0, 1 (GEMINI-Score)", #5
                       "0, 0, 1, 0, 1 (HORLBECK-Score, GEMINI-Score)", #6
                       "1, 0, 0, 0, 1 (MEDIAN-B/NB Score, GEMINI-Score)", #7
                       "1, 0, 0, 1, 0 (MEDIAN-B/NB Score, MAGECK-Score)", #8
                       "1, 1, 0, 0, 0 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score)", #9
                       "0, 1, 0, 0, 1 (sgRNA-Derived B/NB Score, GEMINI-Score)", #10
                       "0, 1, 1, 0, 0 (sgRNA-Derived B/NB Score, HORLBECK-Score)", #11
                       "1, 0, 1, 0, 0 (MEDIAN-B/NB Score, HORLBECK-Score)", #12
                       "0, 0, 1, 1, 0 (HORLBECK-Score, MAGECK-Score)", #13
                       "0, 1, 0, 1, 0 (sgRNA-Derived B/NB Score, MAGECK-Score)", #14
                       "0, 0, 0, 1, 1 (MAGECK-Score, GEMINI-Score)", #15
                       "0, 0, 1, 1, 1 (HORLBECK-Score, MAGECK-Score, GEMINI-Score)", #16
                       "1, 0, 1, 0, 1 (MEDIAN-B/NB Score, HORLBECK-Score, GEMINI-Score)", #17
                       "1, 0, 0, 1, 1 (MEDIAN-B/NB Score, MAGECK-Score, GEMINI-Score)", #18
                       "1, 1, 0, 1, 0 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, MAGECK-Score)", #19
                       "1, 1, 0, 0, 1 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, GEMINI-Score)", #20
                       "0, 1, 1, 0, 1 (sgRNA-Derived B/NB Score, HORLBECK-Score, GEMINI-Score)", #21
                       "1, 1, 1, 0, 0 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, HORLBECK-Score)", #22
                       "1, 0, 1, 1, 0 (MEDIAN-B/NB Score, HORLBECK-Score, MAGECK-Score)", #23
                       "0, 1, 1, 1, 0 (sgRNA-Derived B/NB Score, HORLBECK-Score, MAGECK-Score)", #24
                       "0, 1, 0, 1, 1 (sgRNA-Derived B/NB Score, MAGECK-Score, GEMINI-Score)", #25
                       "0, 1, 1, 1, 1 (sgRNA-Derived B/NB Score, HORLBECK-Score, MAGECK-Score, GEMINI-Score)", #26
                       "1, 0, 1, 1, 1 (MEDIAN-B/NB Score, HORLBECK-Score, MAGECK-Score, GEMINI-Score)", #27
                       "1, 1, 0, 1, 1 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, MAGECK-Score, GEMINI-Score)", #28
                       "1, 1, 1, 0, 1 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, HORLBECK-Score, GEMINI-Score)" , #29
                       "1, 1, 1, 1, 0 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, HORLBECK-Score, MAGECK-Score)", #30
                       "1, 1, 1, 1, 1 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, HORLBECK-Score, MAGECK-Score, GEMINI-Score)") #31

all_possible_scores <- c('MEDIAN-B/NB Score', 'sgRNA-Derived B/NB Score', 'HORLBECK-Score', 'MAGECK-Score', 'GEMINI-Score')

get_ordered_vector <- function(venn_partitions){
  
  curr_ordered_vector <- rep(0, length(direct_area_names))
  names(curr_ordered_vector) <- direct_area_names
  name <- names(curr_ordered_vector)[1]
  
  
  #name <- "1, 1, 1, 1, 0 (MEDIAN-B/NB Score, sgRNA-Derived B/NB Score, HORLBECK-Score, MAGECK-Score)"
  for (name in names(curr_ordered_vector)){
    splited <- strsplit(name, split = '(', fixed = T)[[1]][2]
    splited <- strsplit(splited, split = ')', fixed = T)[[1]][1]
    splited <- strsplit(splited, split = ', ', fixed = T)[[1]]
    idx_loc <- rep(T, dim(venn_partitions)[1])
    item <- splited[1]
    for (item in splited){
      idx_loc <- idx_loc & venn_partitions[[item]]
    }
    for (item in setdiff(all_possible_scores, splited)){
      idx_loc <- idx_loc & !venn_partitions[[item]]
    }
    if (sum(idx_loc) != 1){
      print('error')
    }
    curr_ordered_vector[name] <- venn_partitions[idx_loc, '..percentage..']
  }
  
  return(curr_ordered_vector)
}

SLKB_scores <- read.csv('www/SLKB_calculated_scores.csv')


top_p_choice <- '10percent'
create_figures <- T
venn_diagram_loc <- paste0('V_D_Update+', top_p_choice)

dir.create(venn_diagram_loc, recursive = T, showWarnings = F)
# 
# curr_scores <- curr_subset
# score_name <- "GEMINI_SCORE_SL_score_Strong"
# top_n_pairs <- top_p

get_top_n_pairs <- function(curr_scores, score_name, top_n_pairs){
  if (score_name == "GEMINI_SCORE_SL_score_Strong"){
    curr_scores <- curr_scores[order(curr_scores[[score_name]], decreasing = T), ]
  } else {
    curr_scores <- curr_scores[order(curr_scores[[score_name]], decreasing = F), ]
  }
  
  # remove the NA ones (if possible)
  curr_scores <- curr_scores[!(is.na(curr_scores[[score_name]])),]
  
  # in the case the remaining scores are less (too many NAs, in case)
  top_pairs_to_get <- min(top_n_pairs, dim(curr_scores)[1])
  return(curr_scores$gene_pair[1:top_pairs_to_get])
  
}


create_plot_with_coloring <- function(curr.graph, input_genes = NULL, input_pairs = NULL, target_pairs = NULL){
  
  if (!is.null(input_genes)){
    # Filter to get interactions for the selected genes
    curr.graph <- curr.graph[(curr.graph$gene_1 %in% input_genes) | (curr.graph$gene_2 %in% input_genes), ]
    
    # identify N hop overlaps
    gene_list <- list()
    for (gene in input_genes){
      curr <- curr.graph[grepl(gene, curr.graph$gene_pair, fixed = TRUE),]
      gene_list[[gene]] <- unique(c(curr[grepl(gene, curr$gene_1, fixed = TRUE),'gene_2'], curr[grepl(gene, curr$gene_2, fixed = TRUE),'gene_1']))
    }
    
    if (length(gene_list) > 1){
      res.venn <- plotVenn(gene_list, showPlot = F)
      res.regions <- listVennRegions(res.venn, na.rm = T)
      
      # 2 way: red, 3 way: orange, 4 way: green
      overlapped_genes <- list()
      overlapped_genes[["2_way"]] <- c()
      overlapped_genes[["3_way"]] <- c()
      overlapped_genes[["4_way"]] <- c()
      for (name in names(res.regions)){
        count_category <- strsplit(name, "(", fixed = TRUE)[[1]][1]
        count_category <- str_count(count_category, "1")
        if (count_category < 2){
          next
        }
        count_category <- min(count_category, 4)
        overlapped_genes[[paste0(count_category, "_way")]] <- c(overlapped_genes[[paste0(count_category, "_way")]], res.regions[[name]])
      }
    }
    
    
    print(dim(curr.graph))
    
    curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)
    
    curr.graph <- toVisNetworkData(curr.graph)
    
    gene_idx <- curr.graph$nodes$id %in% input_genes
    
    curr.graph$nodes$group <- rep("node", length(gene_idx))
    curr.graph$nodes$group[gene_idx] <- "chosen_node"
    
    curr.graph$edges$color <- rep("blue", dim(curr.graph$edges)[1])
    
    if (length(gene_list) > 1){
      overlapped_genes[["2_way"]] <- setdiff(overlapped_genes[["2_way"]], input_genes)
      overlapped_genes[["3_way"]] <- setdiff(overlapped_genes[["3_way"]], input_genes)
      overlapped_genes[["4_way"]] <- setdiff(overlapped_genes[["4_way"]], input_genes)
      for (gene in overlapped_genes[["2_way"]]){
        curr.graph$edges$color[grepl(gene, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'red'
      }
      for (gene in overlapped_genes[["3_way"]]){
        curr.graph$edges$color[grepl(gene, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'orange'
      }
      for (gene in overlapped_genes[["4_way"]]){
        curr.graph$edges$color[grepl(gene, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'green'
      }
      
      for (i in seq_along(input_genes)){
        if (i == length(input_genes)){
          next
        }
        gene1 <- input_genes[i]
        for (gene2 in input_genes[(i+1):length(input_genes)]){
          curr.graph$edges$color[grepl(gene1, curr.graph$edges$gene_pair, fixed = TRUE) & grepl(gene2, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'purple'
        }
      }
      
      gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["2_way"]]
      curr.graph$nodes$group[gene_idx] <- "chosen_node_2_way"
      
      gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["3_way"]]
      curr.graph$nodes$group[gene_idx] <- "chosen_node_3_way"
      
      gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["4_way"]]
      curr.graph$nodes$group[gene_idx] <- "chosen_node_4_way"
      
    }
    
    # color based on cell lines
    category <- 'cell_line_origin'
    #category <- 'study_origin'
    color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
    names(color_cl) <- sort(unique(curr.graph$edges[, category]))
    
    color_vector <- rep('', length(curr.graph$edges$from))
    for (cl in unique(curr.graph$edges[, category])){
      color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
    }
    
    curr.graph$edges$color <- color_vector
    
    edge_legend <- data.frame(color = color_cl, 
                              label = names(color_cl)) 
    
    if (!is.null(target_pairs)){
      curr.graph$edges[curr.graph$edges$gene_pair %in% target_pairs, 'color'] <- '#008000'
      print(table(curr.graph$edges$color))
    }
    
    print(length(curr.graph$nodes))
    res_plot <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
      visGroups(groupname = "chosen_node", color = "purple") %>%
      visGroups(groupname = "chosen_node_2_way", color = "red") %>%
      visGroups(groupname = "chosen_node_3_way", color = "orange") %>%
      visGroups(groupname = "chosen_node_4_way", color = "green") %>%
      visGroups(groupname = "node", color = "blue") %>% 
      visExport() %>%
      visLayout(randomSeed = 42) %>%
      visPhysics(solver = "forceAtlas2Based",
                 forceAtlas2Based = list(gravitationalConstant = -100),
                 hierarchicalRepulsion = list(avoidOverlap = 0.99)) %>%
      visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)
  } else {
    
    curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)
    
    curr.graph <- toVisNetworkData(curr.graph)
    
    #gene_idx <- curr.graph$nodes$id %in% genes
    
    # color based on cell lines
    category <- 'cell_line_origin'
    #category <- 'study_origin'
    color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
    names(color_cl) <- sort(unique(curr.graph$edges[, category]))
    
    color_vector <- rep('', length(curr.graph$edges$from))
    for (cl in unique(curr.graph$edges[, category])){
      color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
    }
    
    curr.graph$edges$color <- color_vector
    
    edge_legend <- data.frame(color = color_cl, 
                              label = names(color_cl)) 
    
    
    if (!is.null(target_pairs)){
      curr.graph$edges[curr.graph$edges$gene_pair %in% target_pairs, 'color'] <- '#008000'
      print(table(curr.graph$edges$color))
    }
    
    print('len')
    print(length(curr.graph$nodes))
    res_plot <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
      visGroups(groupname = "node", color = "blue") %>% 
      visExport() %>%
      visLayout(randomSeed = 42) %>%
      visPhysics(solver = "forceAtlas2Based",
                 forceAtlas2Based = list(gravitationalConstant = -100),
                 hierarchicalRepulsion = list(avoidOverlap = 0.99),
                 minVelocity = 2) %>%
      visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)
    
    
  }
  
  
  return(res_plot)
  
}

create_venn_diagrams <- function(curr_subset)


all_venn_partitions <- list()
study <- sort(unique(SLKB_scores$study_origin))[1]
old_par <- par(no.readonly = T)
pairwise_table <- list()
for (study in sort(unique(SLKB_scores$study_origin))){
  all_venn_partitions[[study]] <- list()
  print(study)
  # get current study
  curr_study <- SLKB_scores[SLKB_scores$study_origin == study, ]
  
  pairwise_table[[as.character(study)]] <- list()
  
  cell_line <- sort(unique(curr_study$cell_line_origin))[1]
  for (cell_line in sort(unique(curr_study$cell_line_origin))){
    
    curr_save_loc <- file.path(venn_diagram_loc, study, cell_line)
    dir.create(curr_save_loc, recursive = T, showWarnings = F)
    
    # get current cell line (SL run)
    curr_subset <- curr_study[curr_study$cell_line_origin == cell_line, ]
    
    # get the number of pairs to get from each approach
    top_p <- dim(curr_subset)[1]
    if (top_p_choice == 'all_pairs'){
      print('Getting all pairs...')
    } else {
      if (grepl('percent', top_p_choice, fixed = TRUE)){
        print('Percent!!')
        top_p <- as.numeric(gsub('percent', '', top_p_choice, fixed = TRUE))
        top_p <- round((dim(curr_subset)[1] * top_p) / 100)
      } else {
        top_p <- as.numeric(top_p_choice)
      } 
      # at maximum, get all pairs if error by user
      top_p <- min(top_p, dim(curr_subset)[1])
      print(paste('Set pairs to get:', top_p))
    }
    
    
    venn_list <- list("GEMINI-Score" = get_top_n_pairs(curr_subset, "GEMINI_SCORE_SL_score_Strong", top_p),
                      "HORLBECK-Score" = get_top_n_pairs(curr_subset, "HORLBECK_SCORE_SL_score", top_p),
                      "MAGECK-Score" = get_top_n_pairs(curr_subset, "MAGECK_SCORE_Z_SL_score", top_p),
                      "MEDIAN-B/NB Score" = c(),
                      "sgRNA-Derived B/NB Score" = c()
                      )
  
    if (sum(is.na(curr_subset[["MEDIAN_B_SCORE_Z_SL_score"]])) == dim(curr_subset)[1]){
      print('No background!!')
      venn_list[["MEDIAN-B/NB Score"]] <-  get_top_n_pairs(curr_subset, "MEDIAN_NB_SCORE_Z_SL_score", top_p)
      venn_list[["sgRNA-Derived B/NB Score"]] <-  get_top_n_pairs(curr_subset, "SGRA_DERIVED_NB_SCORE_SL_score", top_p)
    } else {
      print('There is background!')
      venn_list[["MEDIAN-B/NB Score"]] <-  get_top_n_pairs(curr_subset, "MEDIAN_B_SCORE_Z_SL_score", top_p)
      venn_list[["sgRNA-Derived B/NB Score"]] <-  get_top_n_pairs(curr_subset, "SGRA_DERIVED_B_SCORE_SL_score", top_p)
    }
    
    # create the venn diagram, and also get the regions
    venn_partitions <- get.venn.partitions(venn_list, force.unique = TRUE, keep.elements = TRUE)
    
    # get total number of unique pairs
    unique_pairs_count <- sum(venn_partitions$..count..)
    
    venn_partitions$..percentage.. <- venn_partitions$..count.. * 100/unique_pairs_count
    
    #rownames(venn_partitions) <- venn_partitions$..set..
    
    all_venn_partitions[[study]][[cell_line]] <- venn_partitions
    
    if (create_figures){
      venn.diagram(venn_list, filename = file.path(curr_save_loc, 'venn_raw.tiff'),
                   width = 4000, height = 4000,
                          category = names(venn_list),#c("MEDIAN-B/NB Score", "sgRNA-Derived B/NB Score", "HORLBECK-Score", "MAGECK-Score", "GEMINI-Score"),
                          fill = c("orange", "red", "green", "blue", "pink"),
                          cat.col = c("orange", "red", "green", "blue", "pink"),
                          print.mode="raw",
                          disable.logging = T,
                   cat.just=list(c(0.6,1) , c(0,-7) , c(0,0) , c(1,1) , c(1,-5)))
  
      venn.diagram(venn_list, filename = file.path(curr_save_loc, 'venn_percent.tiff'),
                   width = 4000, height = 4000,
                   #category = names(venn_list),#c("MEDIAN-B/NB Score", "sgRNA-Derived B/NB Score", "HORLBECK-Score", "MAGECK-Score", "GEMINI-Score"),
                   fill = c("orange", "red", "green", "blue", "pink"),
                   cat.col = c("orange", "red", "green", "blue", "pink"),
                   print.mode="percent",
                   disable.logging = T,
                 cat.just=list(c(0.6,1) , c(0,-7) , c(0,0) , c(1,1) , c(1,-5)))
    }
    # 
    # venn.diagram(venn_list, filename = NULL,
    #              width = 4000, height = 4000,
    #              #category = names(venn_list),#c("MEDIAN-B/NB Score", "sgRNA-Derived B/NB Score", "HORLBECK-Score", "MAGECK-Score", "GEMINI-Score"),
    #              fill = c("orange", "red", "green", "blue", "pink"),
    #              cat.col = c("orange", "red", "green", "blue", "pink"),
    #              print.mode="percent",
    #              disable.logging = T,
    #              cat.just=list(c(0.6,1) , c(0,-7) , c(0,0) , c(1,1) , c(1,-5)))
    
    interaction_table <- matrix(0, nrow = 5, ncol = 5)
    colnames(interaction_table) <- sort(names(venn_list))
    rownames(interaction_table) <- sort(names(venn_list))
    for (i in rownames(interaction_table)){
      for (j in colnames(interaction_table)){
        # if (i == j){
        #   next
        # }
        union_genes <- union(venn_list[[i]], venn_list[[j]])
        intersecting_genes <- intersect(venn_list[[i]], venn_list[[j]])
        interaction_table[i, j] <- length(intersecting_genes) * 100 / length(union_genes)#top_p#
        #interaction_table[j, i] <- length(intersecting_genes) / length(union_genes)
      }
    }
    #interaction_table['Median-B', 'Median-B'] <- 100
    #interaction_table[lower.tri(interaction_table)] <- NaN
    interaction_table[is.na(interaction_table)] <- 0
    
    pairwise_table[[as.character(study)]][[cell_line]] <- interaction_table
    
    par(old_par)
    
  }
  
}


average_store <- venn_partitions[,c(1:5)]
average_store$..percentage.. = rep(0, dim(average_store)[1])

# get the average percentages
count_studies <- 0
for (study in sort(unique(SLKB_scores$study_origin))){
  curr_study <- SLKB_scores[SLKB_scores$study_origin == study, ]
  for (cell_line in sort(unique(curr_study$cell_line_origin))){
    average_store$..percentage.. <- average_store$..percentage.. + all_venn_partitions[[study]][[cell_line]]$..percentage..
    count_studies <- count_studies + 1
    
  }
}
# average
average_store$..percentage.. <-  round(average_store$..percentage../count_studies, 2)

all_possible_scores <- c('MEDIAN-B/NB Score', 'sgRNA-Derived B/NB Score', 'HORLBECK-Score', 'MAGECK-Score', 'GEMINI-Score')

#average_store[[method_1]] & average_store[[method_2]]
#method_2 <- names(curr_ordered_vector)[2]

method_1 <- 'MEDIAN-B/NB Score'
curr_ordered_vector <- rep(0, length(all_possible_scores))
names(curr_ordered_vector) <- all_possible_scores
for (method_2 in names(curr_ordered_vector)){
  if (method_1 == method_2){
    next
  }
  idx_loc <- average_store[[method_1]] & average_store[[method_2]]
  print(method_2)
  print(sum(average_store$..percentage..[idx_loc]))
  curr_ordered_vector[method_1] <-  curr_ordered_vector[method_1] + sum(average_store$..percentage..[idx_loc])
}


  
get_pairwise_average <- function(average_partitions){
  
  curr_ordered_vector <- rep(0, length(all_possible_scores))
  names(curr_ordered_vector) <- all_possible_scores

  for (method_1 in names(curr_ordered_vector)){
    for (method_2 in names(curr_ordered_vector)){
      if (method_1 == method_2){
        next
      }
      idx_loc <- average_store[[method_1]] & average_store[[method_2]]
      curr_ordered_vector[method_1] <-  curr_ordered_vector[method_1] + sum(average_partitions$..percentage..[idx_loc])
    }
  }
  
  return(curr_ordered_vector)
}

pairwise_res <- get_pairwise_average(average_store)
print('Pairwise result:')
print(pairwise_res)

## do the tables
avg_interaction_table <- matrix(0, nrow = 5, ncol = 5)
colnames(avg_interaction_table) <- sort(names(venn_list))
rownames(avg_interaction_table) <- sort(names(venn_list))
count_studies <- 0
for (study in names(pairwise_table)){
  for (cell_line in names(pairwise_table[[study]])){
    avg_interaction_table <- avg_interaction_table + pairwise_table[[study]][[cell_line]]
    #print(pairwise_table[[study]][[cell_line]])
    count_studies <- count_studies + 1
  }
}
avg_interaction_table <- avg_interaction_table / count_studies

avg_interaction_table[avg_interaction_table == 100] <- 0
rowSums(avg_interaction_table)/4

avg_interaction_table

# get pairwise averages

# proceed to plot it
ordered_area <- get_ordered_vector(average_store)
# percentage_plot <- draw.quintuple.venn(category = c("MEDIAN-B/NB Score", "sgRNA-Derived B/NB Score", "HORLBECK-Score", "MAGECK-Score", "GEMINI-Score"),
#                                        
#                                        fill = c("orange", "red", "green", "blue", "pink"),
#                                        cat.col = c("orange", "red", "green", "blue", "pink"),
#                                        direct.area = TRUE,
#                                        area.vector = ordered_area,
#                                        cat.just=list(c(0.6,1) , c(0,-9) , c(0,0) , c(1,1) , c(1,-6)))
# 
# 
# 
# tiff(filename =  file.path(venn_diagram_loc, 'average_percentage.tiff'))
# 
# grid.draw(percentage_plot);
# dev.off()
if (create_figures){
  venn.diagram(NULL, filename = file.path(venn_diagram_loc, 'average_percentage.tiff'),
               width = 4000, height = 4000,
               category = c("MEDIAN-B/NB Score", "sgRNA-Derived B/NB Score", "HORLBECK-Score", "MAGECK-Score", "GEMINI-Score"),
               fill = c("orange", "red", "green", "blue", "pink"),
               cat.col = c("orange", "red", "green", "blue", "pink"),
               print.mode="percent",
               disable.logging = T,
               direct.area = T,
               area.vector = ordered_area,
               cat.just=list(c(0.6,1) , c(0,-7) , c(0,0) , c(1,1) , c(1,-5)))
}

####### Majority Vote Predict #######

all_predictions <- list()
all_predictions_excel <- list()
study <- sort(unique(SLKB_scores$study_origin))[1]
old_par <- par(no.readonly = T)

total_SL <- 0
for (study in sort(unique(SLKB_scores$study_origin))){
  all_predictions[[study]] <- list()
  print(study)
  # get current study
  curr_study <- SLKB_scores[SLKB_scores$study_origin == study, ]
  
  
  cell_line <- sort(unique(curr_study$cell_line_origin))[1]
  for (cell_line in sort(unique(curr_study$cell_line_origin))){
    
    # curr_save_loc <- file.path(venn_diagram_loc, study, cell_line)
    # dir.create(curr_save_loc, recursive = T, showWarnings = F)
    # 
    # get current cell line (SL run)
    curr_subset <- curr_study[curr_study$cell_line_origin == cell_line, ]
    
    # get the number of pairs to get from each approach
    top_p <- dim(curr_subset)[1]
    if (top_p_choice == 'all_pairs'){
      print('Getting all pairs...')
    } else {
      if (grepl('percent', top_p_choice, fixed = TRUE)){
        print('Percent!!')
        top_p <- as.numeric(gsub('percent', '', top_p_choice, fixed = TRUE))
        top_p <- round((dim(curr_subset)[1] * top_p) / 100)
      } else {
        top_p <- as.numeric(top_p_choice)
      } 
      # at maximum, get all pairs if error by user
      top_p <- min(top_p, dim(curr_subset)[1])
      print(paste('Set pairs to get:', top_p))
    }
    
    
    majority_vote <- list("GEMINI-Score" = get_top_n_pairs(curr_subset, "GEMINI_SCORE_SL_score_Strong", top_p),
                      "HORLBECK-Score" = get_top_n_pairs(curr_subset, "HORLBECK_SCORE_SL_score", top_p),
                      "MAGECK-Score" = get_top_n_pairs(curr_subset, "MAGECK_SCORE_Z_SL_score", top_p),
                      "MEDIAN-B/NB Score" = c(),
                      "sgRNA-Derived B/NB Score" = c()
    )
    
    if (sum(is.na(curr_subset[["MEDIAN_B_SCORE_Z_SL_score"]])) == dim(curr_subset)[1]){
      print('No background!!')
      majority_vote[["MEDIAN-B/NB Score"]] <-  get_top_n_pairs(curr_subset, "MEDIAN_NB_SCORE_Z_SL_score", top_p)
      majority_vote[["sgRNA-Derived B/NB Score"]] <-  get_top_n_pairs(curr_subset, "SGRA_DERIVED_NB_SCORE_SL_score", top_p)
    } else {
      print('There is background!')
      majority_vote[["MEDIAN-B/NB Score"]] <-  get_top_n_pairs(curr_subset, "MEDIAN_B_SCORE_Z_SL_score", top_p)
      majority_vote[["sgRNA-Derived B/NB Score"]] <-  get_top_n_pairs(curr_subset, "SGRA_DERIVED_B_SCORE_SL_score", top_p)
    }
    
    
    voted_pairs <- unlist(majority_vote, recursive = FALSE)
    voted_pairs <- sort(table(voted_pairs), decreasing = T)
    
    # get overlapping info for context
    overlapping_pairs <- sort(voted_pairs[Reduce(intersect, majority_vote)], decreasing = T)
    
    # annotation for each SL gene/pair
    participation_table_pairs <- matrix(0, nrow = length(voted_pairs), ncol = length(majority_vote), dimnames = list(names(voted_pairs), names(majority_vote)))
    
    for (item in rownames(participation_table_pairs)){
      for (strategy in colnames(participation_table_pairs)){
        if (item %in% majority_vote[[strategy]]){
          participation_table_pairs[item, strategy] <- 1
        }
      }
    }
    
    total_count <- rowSums(participation_table_pairs)
    participation_table_pairs <- cbind(participation_table_pairs[names(total_count),], total_count)
    
    sheet <- paste0(study, '_', cell_line)
    
    #xlsx::write.xlsx(participation_table_pairs, file=file.path(venn_diagram_loc, 'SLKB_predictions.xlsx'), sheetName =, append=T)
    
    all_predictions[[study]][[cell_line]] <- participation_table_pairs
    all_predictions_excel[[sheet]] <- participation_table_pairs
    
    total_SL <- total_SL + sum(participation_table_pairs[,'total_count'] > 2)
  }
}

print(paste('Total number of SL:', total_SL))
print(paste('Total number of Not SL:', dim(SLKB_scores)[1] - total_SL))

openxlsx::write.xlsx(all_predictions_excel, file = file.path(venn_diagram_loc, 'SLKB_predictions.xlsx'))

