library(shiny)
library(visNetwork)
BioCManagerLibraries <- c()
requiredLibraries <- c(BioCManagerLibraries, 
                       "shiny",
                       "VennDiagram",
                       "nVennR",
                       "visNetwork",
                       "igraph",
                       "DT",
                       'dplyr',
                       'dbplyr',
                       "shinyWidgets",
                       "ggVennDiagram",
                       "ggplot2",
                       "readxl",
                       "shinythemes",
                       "stringr",
                       'DBI',
                       'pool')

for (packageName in requiredLibraries){
  if (!is.element(packageName, installed.packages()[,1])){
    print(paste("Installing package: ", packageName))
    if (packageName %in% BioCManagerLibraries) {
      BiocManager::install(packageName, type="binary")#INSTALL_opts = '--no-lock')
    }
    else {
      install.packages(packageName, dependencies = TRUE, INSTALL_opts = '--no-lock')
      #install.packages("table1", dependencies = TRUE, INSTALL_opts = '--no-lock')#type="binary")#
      
    }
    
  } 
  
  suppressMessages(library(packageName, character.only = TRUE))
  print(paste("Loaded package: ", packageName))
  
}


#### Shan Version 2

data.all <- read.csv('others/shan_SLKB_calculated_scores.csv')

shared_SL <- openxlsx::read.xlsx('others/SL_Birkan_1.xlsx')

sorted_pair <- c()
for (i in seq_along(shared_SL$gene_1)){
  gene_1 <- shared_SL$gene_1[i]
  gene_2 <- shared_SL$gene_2[i]
  sorted_pair <- c(sorted_pair, paste0(sort(c(gene_1, gene_2)), collapse = '|'))
}

shared_SL$gene_pair <-sorted_pair

setdiff(shared_SL$gene_pair, data.all$gene_pair)

# network for SAOS

SAOS_filt <- shared_SL[(shared_SL$SaOS2_Agree > 2),]

curr.graph <- data.all[(data.all$gene_pair %in% SAOS_filt$gene_pair) & (data.all$cell_line_origin == 'SAOS2'), ]

curr.graph <- create_plot_with_coloring(curr.graph) %>% visNodes(font = list(size = 60))

visSave(curr.graph, file = file.path('others', 'shan_share_v4', 'SAOS2.html'))

# network for SAOS

TT2_filt <- shared_SL[(shared_SL$TT2_Agree > 2),]

curr.graph <- data.all[(data.all$gene_pair %in% TT2_filt$gene_pair) & (data.all$cell_line_origin == 'TT2'), ]

curr.graph <- create_plot_with_coloring(curr.graph) %>% visNodes(font = list(size = 60))

visSave(curr.graph, file = file.path('others', 'shan_share_v4', 'TT2.html'))

# both

both_filt <- shared_SL[(shared_SL$SaOS2_Agree > 2) & (shared_SL$TT2_Agree > 2),]

curr.graph <- data.all[(data.all$gene_pair %in% both_filt$gene_pair) & (data.all$cell_line_origin == 'TT2'), ]

curr.graph <- create_plot_with_coloring(curr.graph) %>% visNodes(font = list(size = 60))

visSave(curr.graph, file = file.path('others', 'shan_share_v4', 'both.html'))



# conn <- pool::dbPool(drv = RSQLite::SQLite(),
#                     dbname = "KB/SLKB_sqlite3")
conn <- pool::dbPool(
  drv = RMySQL::MySQL(),
  dbname = "SLKB_mysql_live",
  host = "slkb-mysql.mysql.database.azure.com",
  username = "guest",
  password = "password"
)

init.study_SL <- 'SELECT * FROM CDKO_ORIGINAL_SL_RESULTS'
temp <- tbl( conn, sql(sqlInterpolate(conn, init.study_SL))) %>% filter(study_origin %in% '30033366') %>% collect()
temp_JURKAT <- tbl( conn, sql(sqlInterpolate(conn, init.study_SL))) %>% filter(cell_line_origin %in% 'JURKAT') %>% filter(study_origin %in% '30033366') %>% collect()
length(unique(c(temp_JURKAT$gene_1, temp_JURKAT$gene_2)))

temp_K562 <- tbl( conn, sql(sqlInterpolate(conn, init.study_SL))) %>% filter(cell_line_origin %in% 'K562') %>% filter(study_origin %in% '30033366') %>% collect()
length(unique(c(temp_K562$gene_1, temp_K562$gene_2)))

length(intersect(unique(c(temp_K562$gene_1, temp_K562$gene_2)), unique(c(temp_JURKAT$gene_1, temp_JURKAT$gene_2))))

horlbeck_SL <- tbl( conn, sql(sqlInterpolate(conn, init.study_SL))) %>% filter(study_origin %in% '30033366')  %>% filter(SL_or_not == 'SL')
JURKAT_SL <- horlbeck_SL %>% filter(cell_line_origin %in% 'JURKAT') %>% collect()
K562_SL <- horlbeck_SL %>% filter(cell_line_origin %in% 'K562') %>% collect()
horlbeck_SL <- horlbeck_SL %>% collect()

length(intersect(JURKAT_SL$gene_pair, K562_SL$gene_pair))

K562_gene_freqs <- sort(table(c(K562_SL$gene_1, K562_SL$gene_2)), decreasing = T)
JURKAT_gene_freqs <- sort(table(c(JURKAT_SL$gene_1, JURKAT_SL$gene_2)), decreasing = T)

K562_hub <- names(K562_gene_freqs[1:floor(length(JURKAT_gene_freqs)  * 0.075)])
JURKAT_hub <- names(JURKAT_gene_freqs[1: floor(length(JURKAT_gene_freqs) * 0.075)])

setdiff(K562_hub, unique(c(temp_JURKAT$gene_1, temp_JURKAT$gene_2)))
setdiff(JURKAT_hub, unique(c(temp_K562$gene_1, temp_K562$gene_2)))

setdiff(K562_hub, JURKAT_hub)
setdiff(JURKAT_hub, K562_hub)
intersect(K562_hub, JURKAT_hub)

###### make scatterplot
scatter_df <- data.frame(hub_gene = sort(unique(c(JURKAT_hub, K562_hub))),
                         K562_freq = 0,
                         JURKAT_freq = 0)
idx <- scatter_df$hub_gene %in% K562_hub
scatter_df$K562_freq[idx] <- K562_gene_freqs[scatter_df$hub_gene[idx]]

idx <- scatter_df$hub_gene %in% JURKAT_hub
scatter_df$JURKAT_freq[idx] <- JURKAT_gene_freqs[scatter_df$hub_gene[idx]]

scatter_df %>% ggplot() + aes(x = K562_freq, y = JURKAT_freq, label = hub_gene) + geom_point() + ggrepel::geom_text_repel(max.overlaps = 15) +
  ylab('# of JURKAT SL Partners') + xlab('# of K562 SL Partners') + 
  labs(subtitle="Top 15 genes from JURKAT and K562 cell lines",
       title= "Horlbeck et al. 2018, SL Hub Gene Partners")
ggsave('standalone_networks/scatter.png')# + #+ geom_text(angle = 45, check_overlap = F) #+ geom_label()#+ geom_jitter()

#ggplot2::qplot(K562_freq,JURKAT_freq, shape = 'circle', data = scatter_df, label = hub_gene) + geom_text(check_overlap = F) + geom_jitter()


scatter_df <- data.frame()
both_hubs <- union(K562_hub, JURKAT_hub)
for (gene in both_hubs){
  
  row <- c(gene, 'K562', 0.2)
  if (gene %in% K562_hub){
    row <- c(gene, 'K562', as.numeric(K562_gene_freqs[gene]))
  }
  scatter_df <- rbind(scatter_df, row)
  
  row <- c(gene, 'JURKAT', 0.2)
  if (gene %in% JURKAT_hub){
    row <- c(gene, 'JURKAT', as.numeric(JURKAT_gene_freqs[gene]))
  }
  scatter_df <- rbind(scatter_df, row)
  

}
# for (gene in K562_hub){
#   row <- c(gene, 'K562', as.numeric(K562_gene_freqs[gene]))
#   scatter_df <- rbind(scatter_df, row)
# }
# for (gene in JURKAT_hub){
#   row <- c(gene, 'JURKAT', -as.numeric(JURKAT_gene_freqs[gene]))
#   scatter_df <- rbind(scatter_df, row)
# }
colnames(scatter_df) <- c('hub_gene', 'cell_line', 'freq')
scatter_df$freq <- as.numeric(scatter_df$freq)
#colnames(scatter_df) <- c('x', 'group', 'value')
# colour = Species, shape = Predicted,
#scatter_df <- scatter_df[order(scatter_df$hub_gene),]

scatter_df <- scatter_df[order(scatter_df$freq),]
#scatter_df$hub_gene <- factor(scatter_df$hub_gene , levels = scatter_df$hub_gene )

scatter_df %>% ggplot(aes(fill=cell_line, y=freq, x= forcats::fct_rev(hub_gene))) + 
  geom_bar(position="dodge", stat="identity") + coord_flip() + 
  scale_fill_discrete(name="Cell Line") + ylab('# of SL Partners') + xlab('Hub Gene') + 
  labs(subtitle="Top 15 genes from JURKAT and K562 cell lines",
       title= "Horlbeck et al. 2018, SL Hub Gene Partners")
ggsave('standalone_networks/bar.png')


# + scale_x_discrete(limits = rev(levels(dbv$Sektion)))
# 
# 
# ggplot2::ggplot(scatter_df[c(1,2,3,4),], ggplot2::aes(fill=group, y=value, x=x)) + ggplot2::geom_bar(position="stack", stat="identity")
# scatter_df[c(1,2,3,4),]
# temp <- data_long[c(1, 3, 5, 7),]
# temp$group <- scatter_df[c(1,2,3,4),'group']
# temp$x <- scatter_df[c(1,2,3,4),'x']
# temp$value <- scatter_df[c(1,2,3,4),'value']
# ggplot2::ggplot(temp, ggplot2::aes(fill=group, y=value, x=x)) + ggplot2::geom_bar(position="stack", stat="identity")
# 
# 
# scatter_df[c(1,2,3,4),]
# data_long[c(1, 3, 5, 7),]
# 
# 
# ggplot(data_long[c(1, 3, 5, 7),], aes(fill=group, y=value, x=x)) + 
#   geom_bar(position="stack", stat="identity")

scatter_df %>% ggplot() + aes(x = K562_freq, y = JURKAT_freq, label = hub_gene) + geom_point() + ggrepel::geom_text_repel(max.overlaps = 15)# + #+ geom_text(angle = 45, check_overlap = F) #+ geom_label()#+ geom_jitter()



####
# Data Prep
data("mtcars")  # load data
mtcars$`car name` <- rownames(mtcars)  # create new column for car names
mtcars$mpg_z <- round((mtcars$mpg - mean(mtcars$mpg))/sd(mtcars$mpg), 2)  # compute normalized mpg
mtcars$mpg_type <- ifelse(mtcars$mpg_z < 0, "below", "above")  # above / below avg flag
mtcars <- mtcars[order(mtcars$mpg_z), ]  # sort
mtcars$`car name` <- factor(mtcars$`car name`, levels = mtcars$`car name`)  # convert to factor to retain sorted order in plot.

# Diverging Barcharts
ggplot(mtcars, aes(x=`car name`, y=mpg_z, label=mpg_z)) + 
  geom_bar(position="stack", stat='identity', aes(fill=mpg_type), width=.5)  +
  scale_fill_manual(name="Mileage", 
                    labels = c("Above Average", "Below Average"), 
                    values = c("above"="#00ba38", "below"="#f8766d")) + 
  labs(subtitle="Normalised mileage from 'mtcars'", 
       title= "Diverging Bars") + 
  coord_flip()



###
library(tidyr)
data <- read.table("https://raw.githubusercontent.com/holtzy/R-graph-gallery/master/DATA/stacked_barplot_negative_values.csv", header=T, sep=",")

data_long <- gather(data, group, value, groupA:groupD) %>%
  arrange(factor(x, levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct"))) %>% 
  mutate(x=factor(x, levels=unique(x)))

ggplot(data_long, aes(fill=group, y=value, x=x)) + 
  geom_bar(position="stack", stat="identity")
###



ggplot2::qplot(K562_freq,JURKAT_freq, shape = 'circle', data = scatter_df, label = hub_gene) + geom_text(check_overlap = F) + geom_jitter()

#curr.graph <- create_plot_with_coloring(horlbeck_SL, input_genes = NULL, target_pairs = NULL) %>% visNodes(font = list(size = 80))


######

curr.graph <- JURKAT_SL

#curr.graph <- curr.graph[(curr.graph$gene_1 %in% unique(c(K562_hub, JURKAT_hub))) & (curr.graph$gene_2 %in% unique(c(K562_hub, JURKAT_hub))),]

curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)



curr.graph <- toVisNetworkData(curr.graph)

#gene_idx <- curr.graph$nodes$id %in% genes

# color based on cell lines
category <- 'cell_line_origin'
#category <- 'study_origin'
color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
names(color_cl) <- sort(unique(curr.graph$edges[, category]))

print(color_cl)
color_cl[1] <- 'red'


color_vector <- rep('', length(curr.graph$edges$from))
for (cl in unique(curr.graph$edges[, category])){
  color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
}

curr.graph$edges$color <- color_vector

edge_legend <- data.frame(color = color_cl, 
                          label = names(color_cl)) 

curr.graph$nodes$group <- 'node'
curr.graph$nodes[curr.graph$nodes$label %in% JURKAT_hub, 'group'] <- 'JURKAT Hub Gene'
curr.graph$nodes[(curr.graph$nodes$label %in% K562_hub) & (curr.graph$nodes$label %in% JURKAT_hub), 'group'] <- 'JURKAT & K562 Hub Gene'


print('len')
print(length(curr.graph$nodes))
curr.graph <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
  visNodes(shape='circle', font = list(color = '#FFFFFF')) %>%
  visGroups(groupname = "node", color = "#e5e5e5", size = 20, font = list(size = 0)) %>% 
  visGroups(groupname = "JURKAT Hub Gene", color = "red", size = 40, font = list(size = 60)) %>% 
  visGroups(groupname = "JURKAT & K562 Hub Gene", color = "purple", size = 60, font = list(size = 60)) %>% 
  visExport() %>%
  visLayout(randomSeed = 42) %>%
  visPhysics(solver = "forceAtlas2Based",
             forceAtlas2Based = list(gravitationalConstant = -100, avoidOverlap = 0.99),
             hierarchicalRepulsion = list(avoidOverlap = 0.99),
             minVelocity = 2) %>%
  visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)

visSave(curr.graph, file = 'standalone_networks/JURKAT_final.html')

#####

curr.graph <- K562_SL

#curr.graph <- curr.graph[(curr.graph$gene_1 %in% unique(c(K562_hub, JURKAT_hub))) & (curr.graph$gene_2 %in% unique(c(K562_hub, JURKAT_hub))),]

curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)



curr.graph <- toVisNetworkData(curr.graph)

#gene_idx <- curr.graph$nodes$id %in% genes

# color based on cell lines
category <- 'cell_line_origin'
#category <- 'study_origin'
color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
names(color_cl) <- sort(unique(curr.graph$edges[, category]))

print(color_cl)
color_cl[1] <- 'red'


color_vector <- rep('', length(curr.graph$edges$from))
for (cl in unique(curr.graph$edges[, category])){
  color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
}

curr.graph$edges$color <- color_vector

edge_legend <- data.frame(color = color_cl, 
                          label = names(color_cl)) 

curr.graph$nodes$group <- 'node'
curr.graph$nodes[curr.graph$nodes$label %in% K562_hub, 'group'] <- 'K562 Hub Gene'
curr.graph$nodes[(curr.graph$nodes$label %in% K562_hub) & (curr.graph$nodes$label %in% JURKAT_hub), 'group'] <- 'JURKAT & K562 Hub Gene'


print('len')
print(length(curr.graph$nodes))
curr.graph <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
  visNodes(shape='circle', font = list(color = '#FFFFFF')) %>%
  visGroups(groupname = "node", color = "#e5e5e5", size = 20, font = list(size = 0)) %>% 
  visGroups(groupname = "K562 Hub Gene", color = "red", size = 80, font = list(size = 80)) %>% 
  visGroups(groupname = "JURKAT & K562 Hub Gene", color = "purple", size = 100, font = list(size = 80)) %>% 
  visEdges(width = 0.5) %>%
  visExport() %>%
  visLayout(randomSeed = 42) %>%
  visPhysics(solver = "forceAtlas2Based",
             forceAtlas2Based = list(gravitationalConstant = -100, avoidOverlap = 0.99),
             hierarchicalRepulsion = list(avoidOverlap = 0.99),
             minVelocity = 2) %>%

  visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)

visSave(curr.graph, file = 'standalone_networks/K562_final.html')



#### combined

curr.graph <- horlbeck_SL

curr.graph <- curr.graph[(curr.graph$gene_1 %in% unique(c(K562_hub, JURKAT_hub))) & (curr.graph$gene_2 %in% unique(c(K562_hub, JURKAT_hub))),]

curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)



curr.graph <- toVisNetworkData(curr.graph)

#gene_idx <- curr.graph$nodes$id %in% genes

# color based on cell lines
category <- 'cell_line_origin'
#category <- 'study_origin'
color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
names(color_cl) <- sort(unique(curr.graph$edges[, category]))

print(color_cl)
color_cl[1] <- 'red'
color_cl[2] <- '#00008B'


color_vector <- rep('', length(curr.graph$edges$from))
for (cl in unique(curr.graph$edges[, category])){
  color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
}

curr.graph$edges$color <- color_vector

edge_legend <- data.frame(color = color_cl, 
                          label = names(color_cl)) 

curr.graph$nodes$group <- 'node'
curr.graph$nodes[(curr.graph$nodes$label %in% K562_hub) & !(curr.graph$nodes$label %in% JURKAT_hub), 'group'] <- 'K562 Hub Gene'
curr.graph$nodes[!(curr.graph$nodes$label %in% K562_hub) & (curr.graph$nodes$label %in% JURKAT_hub), 'group'] <- 'JURKAT Hub Gene'
curr.graph$nodes[(curr.graph$nodes$label %in% K562_hub) & (curr.graph$nodes$label %in% JURKAT_hub), 'group'] <- 'JURKAT & K562 Hub Gene'


print('len')
print(length(curr.graph$nodes))
curr.graph <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
  visGroups(groupname = "node", color = "black") %>% 
  visGroups(groupname = "K562 Hub Gene", color = "#00008B") %>% 
  visGroups(groupname = "JURKAT Hub Gene", color = "red") %>% 
  visGroups(groupname = "JURKAT & K562 Hub Gene", color = "purple") %>% 
  visExport() %>%
  visLayout(randomSeed = 42) %>%
  visPhysics(solver = "forceAtlas2Based",
             forceAtlas2Based = list(gravitationalConstant = -100),
             hierarchicalRepulsion = list(avoidOverlap = 0.99),
             minVelocity = 2) %>%
  visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)

visSave(curr.graph, file = 'standalone_networks/network1.html')



# Shuai
SL_list <- openxlsx::read.xlsx('www/Shuai_242_SL_list.xlsx')

data.all <- read.csv('www/SLKB_calculated_scores_Shuai_040323.csv')

curr_subset <- data.all[data.all$cell_line_origin == "SHUAI_CL",]

top_p_choice <- '10percent'
target_pairs <- SL_list$gene_pair
#target_genes <- unique(c(SL_list[SL_list$Count == 7, 'gene_1'], SL_list[SL_list$Count == 7, 'gene_2']))
target_genes <- c(SL_list[, 'gene_1'], SL_list[, 'gene_2'])

target_genes <- table(target_genes) %>% 
            as.data.frame() %>% 
            arrange(desc(Freq))

target_genes[1:5, 'target_genes']

#sort(table(c(SL_list[, 'gene_1'], SL_list[, 'gene_2'])), decreasing = FALSE)

curr.graph <- curr_subset[curr_subset$gene_pair %in% target_pairs,]

curr.graph1 <- create_plot_with_coloring(curr.graph, input_genes = target_genes[1:4, 'target_genes'], target_pairs = NULL) %>% visNodes(font = list(size = 24))
curr.graph2 <- create_plot_with_coloring(curr.graph, input_genes = NULL, target_pairs = NULL) %>% visNodes(font = list(size = 60))
curr.graph3 <- create_plot_with_coloring(curr.graph, input_genes = NULL, target_pairs = NULL) %>% visNodes(font = list(size = 80))


visSave(curr.graph1, file = 'shuai_share_v1/network1.html')
visSave(curr.graph2, file = 'shuai_share_v1/network2_font60.html')
visSave(curr.graph3, file = 'shuai_share_v1/network2_font80.html')

target_genes[1:4, 'target_genes']
# Shan
data.all <- read.csv('www/shan_SLKB_calculated_scores.csv')

curr_subset <- data.all[data.all$cell_line_origin == 'SAOS2',]

top_p_choice <- '20percent'
target_pairs <- c('ATR|PARP1', 'ATR|PARP2', 'BRD4|CHEK1')
target_genes <- c('ATR', 'PARP1', 'PARP2', 'BRD4', 'CHEK1')

# curr_scores <- curr_subset
# score_name <- "MEDIAN_B_SCORE_Z_SL_score"
# top_n_pairs <- top_p

get_top_n_pairs <- function(curr_scores, score_name, top_n_pairs){
  if (score_name == "GEMINI_SCORE_SL_score_Strong"){
    curr_scores <- curr_scores[order(curr_scores[[score_name]], decreasing = T), ]
  } else {
    curr_scores <- curr_scores[order(curr_scores[[score_name]], decreasing = F), ]
  }
  
  # remove the NA ones (if possible)
  curr_scores <- curr_scores[!(is.na(curr_scores[[score_name]])),]
  
  # in the case the remaining scores are less (too many NAs, in case)
  top_pairs_to_get <- min(top_n_pairs, dim(curr_scores)[1])
  return(curr_scores$gene_pair[1:top_pairs_to_get])
  
}

top_p <- dim(curr_subset)[1]
if (top_p_choice == 'all_pairs'){
  print('Getting all pairs...')
} else {
  if (grepl('percent', top_p_choice, fixed = TRUE)){
    print('Percent!!')
    top_p <- as.numeric(gsub('percent', '', top_p_choice, fixed = TRUE))
    top_p <- round((dim(curr_subset)[1] * top_p) / 100)
  } else {
    top_p <- as.numeric(top_p_choice)
  } 
  # at maximum, get all pairs if error by user
  top_p <- min(top_p, dim(curr_subset)[1])
  print(paste('Set pairs to get:', top_p))
}

scoring_methods <- colnames(curr_subset)[9:22]
for (method in scoring_methods){
  SL_pairs <- get_top_n_pairs(curr_subset, method, top_p)
  cond <- sum(target_pairs %in% SL_pairs)
  if (cond > 2){
    print(method)
  }
}

# "MAGECK_SCORE_Z_SL_score"
SL_pairs <- get_top_n_pairs(curr_subset, "MAGECK_SCORE_Z_SL_score", top_p)

top_SL_pairs <- c(sapply(strsplit(SL_pairs, split = '|', fixed =  T), '[', 1), sapply(strsplit(SL_pairs, split = '|', fixed =  T), '[', 2))

top_SL_pairs <- sort(table(top_SL_pairs), decrasing = F)

write.csv(top_SL_pairs, 'shan_share_v3/SAOS2_SL_pair_counts.csv')

curr.graph <- curr_subset[curr_subset$gene_pair %in% SL_pairs,]

curr.graph1 <- create_plot_with_coloring(curr.graph, input_genes = target_genes, target_pairs = target_pairs) %>% visNodes(font = list(size = 24))
curr.graph2 <- create_plot_with_coloring(curr.graph, input_genes = NULL, target_pairs = target_pairs) %>% visNodes(font = list(size = 60))
curr.graph3 <- create_plot_with_coloring(curr.graph, input_genes = NULL, target_pairs = target_pairs) %>% visNodes(font = list(size = 80))


visSave(curr.graph1, file = 'shan_share_v3/SAOS2_network1.html')
visSave(curr.graph2, file = 'shan_share_v3/SAOS2_network2_font60.html')
visSave(curr.graph3, file = 'shan_share_v3/SAOS2_network2_font80.html')


#####


curr_subset <- data.all[data.all$cell_line_origin == 'TT2',]

top_p_choice <- '22percent'
target_pairs <- c('ATR|PARP1', 'ATR|PARP2', 'BRD4|CHEK1')
target_genes <- c('ATR', 'PARP1', 'PARP2', 'BRD4', 'CHEK1')

# curr_scores <- curr_subset
# score_name <- "MEDIAN_B_SCORE_Z_SL_score"
# top_n_pairs <- top_p

get_top_n_pairs <- function(curr_scores, score_name, top_n_pairs){
  if (score_name == "GEMINI_SCORE_SL_score_Strong"){
    curr_scores <- curr_scores[order(curr_scores[[score_name]], decreasing = T), ]
  } else {
    curr_scores <- curr_scores[order(curr_scores[[score_name]], decreasing = F), ]
  }
  
  # remove the NA ones (if possible)
  curr_scores <- curr_scores[!(is.na(curr_scores[[score_name]])),]
  
  # in the case the remaining scores are less (too many NAs, in case)
  top_pairs_to_get <- min(top_n_pairs, dim(curr_scores)[1])
  return(curr_scores$gene_pair[1:top_pairs_to_get])
  
}

top_p <- dim(curr_subset)[1]
if (top_p_choice == 'all_pairs'){
  print('Getting all pairs...')
} else {
  if (grepl('percent', top_p_choice, fixed = TRUE)){
    print('Percent!!')
    top_p <- as.numeric(gsub('percent', '', top_p_choice, fixed = TRUE))
    top_p <- round((dim(curr_subset)[1] * top_p) / 100)
  } else {
    top_p <- as.numeric(top_p_choice)
  } 
  # at maximum, get all pairs if error by user
  top_p <- min(top_p, dim(curr_subset)[1])
  print(paste('Set pairs to get:', top_p))
}

scoring_methods <- colnames(curr_subset)[9:22]
for (method in scoring_methods){
  SL_pairs <- get_top_n_pairs(curr_subset, method, top_p)
  cond <- sum(target_pairs %in% SL_pairs)
  if (cond > 2){
    print(method)
  }
}

# "MAGECK_SCORE_Z_SL_score"
SL_pairs <- get_top_n_pairs(curr_subset, "HORLBECK_SCORE_SL_score", top_p)

top_SL_pairs <- c(sapply(strsplit(SL_pairs, split = '|', fixed =  T), '[', 1), sapply(strsplit(SL_pairs, split = '|', fixed =  T), '[', 2))

top_SL_pairs <- sort(table(top_SL_pairs), decrasing = F)

write.csv(top_SL_pairs, 'shan_share_v3/TT2_SL_pair_counts.csv')

curr.graph <- curr_subset[curr_subset$gene_pair %in% SL_pairs,]

curr.graph1 <- create_plot_with_coloring(curr.graph, input_genes = target_genes, target_pairs = target_pairs) %>% visNodes(font = list(size = 24))
curr.graph2 <- create_plot_with_coloring(curr.graph, input_genes = NULL, target_pairs = target_pairs) %>% visNodes(font = list(size = 60))
curr.graph3 <- create_plot_with_coloring(curr.graph, input_genes = NULL, target_pairs = target_pairs) %>% visNodes(font = list(size = 80))

plotVenn(curr.graph1, showPlot = F)



visSave(curr.graph1, file = 'shan_share_v3/TT2_network1.html')
visSave(curr.graph2, file = 'shan_share_v3/TT2_network2_font60.html')
visSave(curr.graph3, file = 'shan_share_v3/TT2_network2_font80.html')

######

#curr.graph <- 



# conn <- pool::dbPool(drv = RSQLite::SQLite(),
#                      dbname = "KB/SLKB_sqlite3")
con <- pool::dbPool(
  drv = RMySQL::MySQL(),
  dbname = "SLKB_mysql",
  host = "slkb-mysql.mysql.database.azure.com",
  username = "guest",
  password = "password"
)


data.all <- tbl( conn, sql(sqlInterpolate(conn, 'SELECT * FROM CDKO_ORIGINAL_SL_RESULTS'))) %>% collect()
data.all <- data.all[, -c(1,2)]
data.all <- data.all[, c("gene_1" , "gene_2", "gene_pair", "study_origin", "cell_line_origin", "SL_or_not",  "SL_score" , "statistical_score", "SL_score_cutoff", "statistical_score_cutoff")]

curr.graph_main <- data.all[(data.all['cell_line_origin'] == 'JURKAT') & (data.all['study_origin'] == '30033366') & ((data.all['SL_or_not'] == 'SL')),]
curr.graph <- curr.graph_main


input_genes <- c('ARL2', 'FAM50A', 'POLD1', 'WDR61')
# network data
# nodes <- data.frame(id = 1:15, label = paste("Label", 1:15),
#                     group = sample(LETTERS[1:3], 15, replace = TRUE))
# 
# edges <- data.frame(from = trunc(runif(15)*(15-1))+1,
#                     to = trunc(runif(15)*(15-1))+1)

input_pairs <- NULL
target_pairs <- NULL


create_plot_with_coloring <- function(curr.graph, input_genes = NULL, input_pairs = NULL, target_pairs = NULL){
  
  if (!is.null(input_genes)){
    # Filter to get interactions for the selected genes
    curr.graph <- curr.graph[(curr.graph$gene_1 %in% input_genes) | (curr.graph$gene_2 %in% input_genes), ]
    
    # identify N hop overlaps
    gene_list <- list()
    for (gene in input_genes){
      curr <- curr.graph[grepl(gene, curr.graph$gene_pair, fixed = TRUE),]
      gene_list[[gene]] <- unique(c(curr[grepl(gene, curr$gene_1, fixed = TRUE),'gene_2'], curr[grepl(gene, curr$gene_2, fixed = TRUE),'gene_1']))
    }
    
    if (length(gene_list) > 1){
      res.venn <- plotVenn(gene_list, showPlot = F)
      res.regions <- listVennRegions(res.venn, na.rm = T)
      
      # 2 way: red, 3 way: orange, 4 way: green
      overlapped_genes <- list()
      overlapped_genes[["2_way"]] <- c()
      overlapped_genes[["3_way"]] <- c()
      overlapped_genes[["4_way"]] <- c()
      for (name in names(res.regions)){
        count_category <- strsplit(name, "(", fixed = TRUE)[[1]][1]
        count_category <- str_count(count_category, "1")
        if (count_category < 2){
          next
        }
        count_category <- min(count_category, 4)
        overlapped_genes[[paste0(count_category, "_way")]] <- c(overlapped_genes[[paste0(count_category, "_way")]], res.regions[[name]])
      }
    }
    
    
    print(dim(curr.graph))
    
    curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)
    
    curr.graph <- toVisNetworkData(curr.graph)
    
    gene_idx <- curr.graph$nodes$id %in% input_genes
    
    curr.graph$nodes$group <- rep("node", length(gene_idx))
    curr.graph$nodes$group[gene_idx] <- "chosen_node"
    
    curr.graph$edges$color <- rep("blue", dim(curr.graph$edges)[1])
    
    if (length(gene_list) > 1){
      overlapped_genes[["2_way"]] <- setdiff(overlapped_genes[["2_way"]], input_genes)
      overlapped_genes[["3_way"]] <- setdiff(overlapped_genes[["3_way"]], input_genes)
      overlapped_genes[["4_way"]] <- setdiff(overlapped_genes[["4_way"]], input_genes)
      for (gene in overlapped_genes[["2_way"]]){
        curr.graph$edges$color[grepl(gene, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'red'
      }
      for (gene in overlapped_genes[["3_way"]]){
        curr.graph$edges$color[grepl(gene, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'orange'
      }
      for (gene in overlapped_genes[["4_way"]]){
        curr.graph$edges$color[grepl(gene, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'green'
      }
      
      for (i in seq_along(input_genes)){
        if (i == length(input_genes)){
          next
        }
        gene1 <- input_genes[i]
        for (gene2 in input_genes[(i+1):length(input_genes)]){
          curr.graph$edges$color[grepl(gene1, curr.graph$edges$gene_pair, fixed = TRUE) & grepl(gene2, curr.graph$edges$gene_pair, fixed = TRUE)] <- 'purple'
        }
      }
      
      gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["2_way"]]
      curr.graph$nodes$group[gene_idx] <- "chosen_node_2_way"
      
      gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["3_way"]]
      curr.graph$nodes$group[gene_idx] <- "chosen_node_3_way"
      
      gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["4_way"]]
      curr.graph$nodes$group[gene_idx] <- "chosen_node_4_way"
      
    }
    
    # color based on cell lines
    category <- 'cell_line_origin'
    #category <- 'study_origin'
    color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
    names(color_cl) <- sort(unique(curr.graph$edges[, category]))
    
    color_vector <- rep('', length(curr.graph$edges$from))
    for (cl in unique(curr.graph$edges[, category])){
      color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
    }
    
    curr.graph$edges$color <- color_vector
    
    edge_legend <- data.frame(color = color_cl, 
                              label = names(color_cl)) 
    
    if (!is.null(target_pairs)){
      curr.graph$edges[curr.graph$edges$gene_pair %in% target_pairs, 'color'] <- '#008000'
      print(table(curr.graph$edges$color))
    }
    
    print(length(curr.graph$nodes))
    res_plot <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
      visGroups(groupname = "chosen_node", color = "purple") %>%
      visGroups(groupname = "chosen_node_2_way", color = "red") %>%
      visGroups(groupname = "chosen_node_3_way", color = "orange") %>%
      visGroups(groupname = "chosen_node_4_way", color = "green") %>%
      visGroups(groupname = "node", color = "blue") %>% 
      visExport() %>%
      visLayout(randomSeed = 42) %>%
      visPhysics(solver = "forceAtlas2Based",
                 forceAtlas2Based = list(gravitationalConstant = -100),
                 hierarchicalRepulsion = list(avoidOverlap = 0.99)) %>%
      visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)
  } else {
    
    curr.graph <- graph_from_data_frame(curr.graph[,c('gene_1', 'gene_2', 'cell_line_origin', 'study_origin', 'gene_pair')], directed = F)
    
    curr.graph <- toVisNetworkData(curr.graph)
    
    #gene_idx <- curr.graph$nodes$id %in% genes
    
    # color based on cell lines
    category <- 'cell_line_origin'
    #category <- 'study_origin'
    color_cl <- rainbow(length(sort(unique(curr.graph$edges[, category]))))
    names(color_cl) <- sort(unique(curr.graph$edges[, category]))
    
    color_vector <- rep('', length(curr.graph$edges$from))
    for (cl in unique(curr.graph$edges[, category])){
      color_vector[which(cl == curr.graph$edges[, category])] <- color_cl[cl]
    }
    
    curr.graph$edges$color <- color_vector
    
    edge_legend <- data.frame(color = color_cl, 
                              label = names(color_cl)) 
    
    
    if (!is.null(target_pairs)){
      curr.graph$edges[curr.graph$edges$gene_pair %in% target_pairs, 'color'] <- '#008000'
      print(table(curr.graph$edges$color))
    }
    
    print('len')
    print(length(curr.graph$nodes))
    res_plot <- visNetwork(curr.graph$nodes, curr.graph$edges, height = "800px") %>%
      visGroups(groupname = "node", color = "blue") %>% 
      visExport() %>%
      visLayout(randomSeed = 42) %>%
      visPhysics(solver = "forceAtlas2Based",
                 forceAtlas2Based = list(gravitationalConstant = -100),
                 hierarchicalRepulsion = list(avoidOverlap = 0.99),
                 minVelocity = 2) %>%
      visLegend(useGroups = T, main = 'Legend', position = 'right', addEdges = edge_legend)
    
    
  }
  
  
  return(res_plot)
  
}

# Define UI
ui_i <- shinyUI(fluidPage(
  visNetworkOutput("network"), 
  actionButton("store_position", "Store positions !"),
  downloadLink('downloadNetwork', 'Download network')
))

# Define server
server_i <- shinyServer(function(input, output) {
  output$network <- renderVisNetwork({
    create_plot_with_coloring(curr.graph_main, input_genes = c('ARL2', 'FAM50A', 'POLD1', 'WDR61')) %>% visNodes(font = list(size = 33))
  })
  
  # get position info
  observeEvent(input$store_position, {
    visNetworkProxy("network") %>% visGetPositions()
  })
  
  # format positions
  nodes_positions <- reactive({
    positions <- input$network_positions
    if(!is.null(positions)){
      nodes_positions <- do.call("rbind", lapply(positions, function(x){ data.frame(x = x$x, y = x$y)}))
      nodes_positions$id <- names(positions)
      nodes_positions
    } else {
      NULL
    }
  })
  
  output$downloadNetwork <- downloadHandler(
    filename = function() {
      paste('network-', Sys.Date(), '.html', sep='')
    },
    content = function(con) {
      # nodes_positions <- nodes_positions()
      # if(!is.null(nodes_positions)){
      #   nodes_save <- merge(nodes, nodes_positions, by = "id", all = T)
      # } else  {
      #   nodes_save <- nodes
      # }
      
      create_plot_with_coloring(curr.graph_main, input_genes = c('ARL2', 'FAM50A', 'POLD1', 'WDR61')) %>% visNodes(font = list(size = 33)) %>% visSave(con)
      # 
      # visNetwork(nodes = nodes_save, edges = edges, height = "800px") %>%
      #   visOptions(highlightNearest = TRUE) %>% visExport() %>%
      #   visPhysics(enabled = FALSE) %>% visEdges(smooth = FALSE) %>% visSave(con)
    }
  )
  
})

# Run the application 
shinyApp(ui = ui_i, server = server_i)

