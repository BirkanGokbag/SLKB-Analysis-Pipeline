library(xlsx)
library(visNetwork)
library(dplyr)
library(nVennR)
library(VennDiagram)
library(igraph)
library(ggplot2)
library(ggVennDiagram)
library(stringr)
library(ggvenn)
library(webshot)



rm(list=ls())
gc()

# annotation file
cell_death <- read.xlsx(file = 'DKO_22RV1_target_LJ.xlsx', sheetName = 'Annotation_CD_pathway')

unique(cell_death$Pathways_Genes)

# create a variable for target annotations
annotations <- data.frame('annotation' = cell_death$Cell.death,
                          'genes' = cell_death$Pathways_Genes)

#annotations$joined <- paste0(annotations$annotation, '_', annotations$genes)

annotations <- annotations %>% distinct(annotation, genes)
# 
# table(annotations$annotation)
# 
# sort(table(annotations$annotation))
# 
# temp <- annotations[(annotations$genes %in% unique(c(results$Gene_A , results$Gene_B))),]
# table(temp$annotation)
# length(unique(temp$genes))
# 
# filtered_annotations <- 
# 
# length(setdiff(annotations$genes, c(results$Gene_A , results$Gene_B)))


# read previously calculated data
results <- read.xlsx(file = '3percent_majority_results.xlsx', sheetName = 'Voted Pairs')

results <- results[results$Total.Count > 1,]
results$Gene.Pair <- results$NA.


results$Gene_A <- sapply(strsplit(results$Gene.Pair, '_', fixed = TRUE), `[`, 1)
results$Gene_B <- sapply(strsplit(results$Gene.Pair, '_', fixed = TRUE), `[`, 2)


annotations <- annotations[(annotations$genes %in% unique(c(results$Gene_A , results$Gene_B))),]
print(length(unique(annotations$genes)))

top_genes <- sort(table(c(results$Gene_A, results$Gene_B)), decreasing = TRUE)
#top_genes <- names(top_genes)[1:10]
top_genes <- names(top_genes[top_genes >= 10])
#selected_gene_pairs <- results$NA.


#temp <- annotations[(annotations$genes %in% unique(c(results$Gene_A , results$Gene_B))),]
# create venn diagram of the 5 pathways
selected_pathways <- c('Apoptosis', 
                       'Autosis',
                       'Mitotic_CD',
                       'Necroptosis',
                       'Proliferation')

annotations <- annotations[(annotations$annotation %in% selected_pathways),]
print(length(unique(annotations$genes)))

pathway_list <- list()
for (pathway in selected_pathways){
  pathway_list[[pathway]] <- annotations[annotations$annotation == pathway, 'genes']
}


participation_matrix <- matrix(0, nrow = length(unique(annotations$genes)), ncol = length(unique(annotations$annotation)))
rownames(participation_matrix) <- sort(unique(annotations$genes))
colnames(participation_matrix) <- sort(unique(annotations$annotation))

for (pathway in colnames(participation_matrix)){
  for (gene in rownames(participation_matrix)){
    if (gene %in% pathway_list[[pathway]]){
      participation_matrix[gene, pathway] <- 1
    }
  }
}

freqs <- table(c(results$Gene_A, results$Gene_B))

participation_matrix <- as.data.frame(participation_matrix)
participation_matrix$Participation <- rowSums(participation_matrix)
participation_matrix$FrequencyInSL <- freqs[rownames(participation_matrix)]

participation_matrix[,selected_pathways][participation_matrix[,selected_pathways] == 0] <- ""
participation_matrix[,selected_pathways][participation_matrix[,selected_pathways] != ""] <- "1"


#write.csv(participation_matrix, file = 'participation_matrix_3percent_5pathways.csv')

max <- -1
for (pathway in selected_pathways){
  if (max < length(pathway_list[[pathway]])){
    max <- length(pathway_list[[pathway]])
  }
}

element_matrix <- matrix("", nrow = max, ncol = length(unique(annotations$annotation)))
colnames(element_matrix) <- sort(unique(annotations$annotation))

all <- c()
for (pathway in names(pathway_list)){
  all <- c(all, pathway_list[[pathway]])
}
for (pathway in colnames(participation_matrix)){
  i <- 1
  for (gene in sort(pathway_list[[pathway]])){
    element_matrix[i, pathway] <- gene
    i <- i + 1
  }
}
element_matrix <- as.data.frame(element_matrix)

#write.csv(element_matrix, file = 'element_matrix_3percent_5pathways.csv')
# 
# for (sheet in names(output_results)){
#   colnames(output_results[[sheet]])[1] <- 'Total Count'
#   write.xlsx(output_results[[sheet]], file=paste0(top_p_choice, '_', 'majority_results.xlsx'), sheetName = sheet, append=T)
# }
# 
# res.venn <- plotVenn(pathway_list, showPlot = F)
# res.regions <- listVennRegions(res.venn, na.rm = T)
# 
# 
# overlapped_genes <- list()
# overlapped_genes[["1_way"]] <- c()
# overlapped_genes[["2_way"]] <- c()
# overlapped_genes[["3_way"]] <- c()
# overlapped_genes[["4_way"]] <- c()
# overlapped_genes[["5_way"]] <- c()
# for (name in names(res.regions)){
#   count_category <- strsplit(name, "(", fixed = TRUE)[[1]][1]
#   count_category <- str_count(count_category, "1")
#   # if (count_category < 2){
#   #   next
#   # }
#   #count_category <- min(count_category, 4)
#   overlapped_genes[[paste0(count_category, "_way")]] <- c(overlapped_genes[[paste0(count_category, "_way")]], res.regions[[name]])
# }
# 
# for (name in names(overlapped_genes)){
#   print(name)
#   print(length(overlapped_genes[[name]]))
#   print(paste(overlapped_genes[[name]], collapse = ';'))
# }
# 
# #ggvenn( pathway_list, show_elements = T, label_sep = ",")
# # 
# # AA <- c("hi","foo", "bar","yep","woo","hoo")
# # BB <- c("baa","yep", "woo","yes")
# # CC <- c("yes","foo","hi","woo", "huh")
# # 
# # x <- list(AA=AA , BB=BB , CC=CC)
# # 
# # 
# # v0 <- venn.diagram( x, filename=NULL, 
# #                     fill = c("red", "blue", "green"),
# #                     alpha = 0.50,
# #                     col = "transparent")
# # 
# # grid.draw(v0)
# # 
# # overlaps <- calculate.overlap(x)
# # 
# # # extract indexes of overlaps from list names
# # indx <- as.numeric(substr(names(overlaps),2,2))
# # 
# # 
# # # labels start at position 7 in the list for Venn's with 3 circles
# # for (i in 1:length(overlaps)){
# #   v0[[6 + indx[i] ]]$label <- paste(overlaps[[i]], collapse = "\n") 
# # }
# 
# 
# 
# v <- venn.diagram(
#   x = pathway_list,
#   category.names = names(pathway_list),
#   filename = NULL,
#   # filename = 'pathway_all_venn_diagram.png',
#   # output=TRUE,
#   # 
#   # # Output features
#   # imagetype="png" ,
#   # height = 2560 , 
#   # width = 4000 , 
#   # resolution = 600,
#   # compression = "lzw",
#   # 
#   # # Circles
#   # #lwd = 2,
#   # #lty = 'blank',
#   # 
#   # Numbers
#   cex = 0.65,
#   fontface = "bold",
#   #fontfamily = "sans",
# 
#   # Set names
#   #cat.cex = 0.6,
#   cat.fontface = "bold",
#   cat.default.pos = "outer",
#   cat.just = list(c(0.6,1) , c(0,-2) , c(0,0) , c(1,1) , c(1,-2.5)),
#   fill = c('grey', 'blue', 'green', 'orange', 'yellow'),
#   #cat.pos = c(100, -100, 150, -100, 100),
#   #cat.dist = c(0.055, 0.055, 0.085, 0.055, 0.055),
#   #cat.fontfamily = "sans",
#   scaled = F
#   #rotation = 1
# )
# 
# # Draw plot
# grid.newpage()
# 
# grid.draw(v)
# 
# # Calculate overlap site
# overlaps <- calculate.overlap(pathway_list)
# indx <- as.numeric(substr(names(overlaps),2,3))
# 
# 
# # Apply name to global variable
# # Index of venn diagram start at calculate.overlaps + 8. You have to find the index value by yourself for (3,5,6,7,.. venn)
# for (i in 1:length(overlaps)){
#   if (length(overlaps[[i]]) == 7){
#     v[[10 + indx[i] ]]$label <- paste(c(paste(overlaps[[i]][1:3], collapse = ";"), overlaps[[i]][4], paste(overlaps[[i]][5:7], collapse = ";")), collapse = "\n")
#   } else if (length(overlaps[[i]]) == 4){
#     v[[10 + indx[i] ]]$label <- paste(c(paste(overlaps[[i]][1:2], collapse = ";"), paste(overlaps[[i]][3:4], collapse = ";")), collapse = "\n")
#   } else {
#     v[[10 + indx[i] ]]$label <- paste(overlaps[[i]], collapse = ";") 
#   }
#   
# }
# 
# grid.newpage()
# 
# # Draw plot
# grid.draw(v)
# ggsave(v, file="my_plot.svg", device = "svg")
# 

res.venn <- plotVenn(pathway_list, showPlot = F)
res.regions <- listVennRegions(res.venn, na.rm = T)

# query genes
query_genes <- paste0(unique(c(results$Gene_A, results$Gene_B)), collapse = ';')
#query_genes <- 'IRS1;AR'
# top_genes <- read.xlsx(file = '3percent_majority_results.xlsx', sheetName = 'Overlapping Genes')
# top_genes <- top_genes$NA.
# top_genes <- unique(c(names(sort(table(c(results$Gene_A, results$Gene_B)), decreasing = TRUE))[1:10], top_genes))

genes <- sub(" ", "", query_genes)
genes <- strsplit(genes, ";")[[1]]

curr.graph <- results

# Filter to get interactions for the selected genes
curr.graph <- curr.graph[(curr.graph$Gene_A %in% genes) | (curr.graph$Gene_B %in% genes), ]

# identify N hop overlaps
gene_list <- list()
# for (gene in genes){
#   curr <- curr.graph[grepl(gene, curr.graph$Gene.Pair, fixed = TRUE),]
#   gene_list[[gene]] <- unique(c(curr[grepl(gene, curr$Gene_A, fixed = TRUE),'Gene_B'], curr[grepl(gene, curr$Gene_B, fixed = TRUE),'Gene_A']))
# }

if (length(gene_list) > 1){
  res.venn <- plotVenn(gene_list, showPlot = F)
  res.regions <- listVennRegions(res.venn, na.rm = T)
  
  # 2 way: red, 3 way: orange, 4 way: green, 5 way: black
  overlapped_genes <- list()
  overlapped_genes[["2_way"]] <- c()
  overlapped_genes[["3_way"]] <- c()
  overlapped_genes[["4_way"]] <- c()
  overlapped_genes[["5_way"]] <- c()
  for (name in names(res.regions)){
    count_category <- strsplit(name, "(", fixed = TRUE)[[1]][1]
    count_category <- str_count(count_category, "1")
    if (count_category < 2){
      next
    }
    count_category <- min(count_category, 4)
    overlapped_genes[[paste0(count_category, "_way")]] <- c(overlapped_genes[[paste0(count_category, "_way")]], res.regions[[name]])
  }
}


print(dim(curr.graph))

curr.graph <- graph_from_data_frame(data.frame('Gene_A' = curr.graph$Gene_A,
                                               'Gene_B' = curr.graph$Gene_B), directed = FALSE)

#curr.graph <- simplify(curr.graph, edge.attr.comb="concat")

curr.graph <- toVisNetworkData(curr.graph)

gene_idx <- curr.graph$nodes$id %in% genes

curr.graph$nodes$group <- rep("node", length(gene_idx))
curr.graph$nodes$group[gene_idx] <- "chosen_node"

curr.graph$edges$color <- rep("blue", dim(curr.graph$edges)[1])

if (length(gene_list) > 1){
  overlapped_genes[["2_way"]] <- setdiff(overlapped_genes[["2_way"]], genes)
  overlapped_genes[["3_way"]] <- setdiff(overlapped_genes[["3_way"]], genes)
  overlapped_genes[["4_way"]] <- setdiff(overlapped_genes[["4_way"]], genes)
  overlapped_genes[["5_way"]] <- setdiff(overlapped_genes[["5_way"]], genes)
  for (gene in overlapped_genes[["2_way"]]){
    curr.graph$edges$color[grepl(gene, curr.graph$edges$Gene.Pair, fixed = TRUE)] <- 'red'
  }
  for (gene in overlapped_genes[["3_way"]]){
    curr.graph$edges$color[grepl(gene, curr.graph$edges$Gene.Pair, fixed = TRUE)] <- 'orange'
  }
  for (gene in overlapped_genes[["4_way"]]){
    curr.graph$edges$color[grepl(gene, curr.graph$edges$Gene.Pair, fixed = TRUE)] <- 'green'
  }
  for (gene in overlapped_genes[["5_way"]]){
    curr.graph$edges$color[grepl(gene, curr.graph$edges$Gene.Pair, fixed = TRUE)] <- 'black'
  }
  
  for (i in seq_along(genes)){
    if (i == length(genes)){
      next
    }
    gene1 <- genes[i]
    for (gene2 in genes[(i+1):length(genes)]){
      curr.graph$edges$color[grepl(gene1, curr.graph$edges$Gene.Pair, fixed = TRUE) & grepl(gene2, curr.graph$edges$Gene.Pair, fixed = TRUE)] <- 'purple'
    }
  }
  
  gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["2_way"]]
  curr.graph$nodes$group[gene_idx] <- "chosen_node_2_way"
  
  gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["3_way"]]
  curr.graph$nodes$group[gene_idx] <- "chosen_node_3_way"
  
  gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["4_way"]]
  curr.graph$nodes$group[gene_idx] <- "chosen_node_4_way"
  
  gene_idx <- curr.graph$nodes$id %in% overlapped_genes[["5_way"]]
  curr.graph$nodes$group[gene_idx] <- "chosen_node_5_way"
  
}
# add settings
curr.graph$nodes$level <- 1
curr.graph$nodes$shape <- 'circle'
curr.graph$nodes$font.color <- 'white'

temp <- curr.graph

# 
# 
curr.graph <- temp

available_annotations <- annotations[which(annotations$genes %in% curr.graph$nodes$label),]
#   
#   
# # add available annotations
# available_annotations <- annotations[which(annotations$genes %in% curr.graph$nodes$label),]
# 
# # add them as the respective edges
# append_rows <- available_annotations
# colnames(append_rows) <- c('from', 'to')
# append_rows$color <- 'black'
# rownames(append_rows) <- (1:dim(append_rows)[1])+dim(curr.graph$edges)[1]
# 
# curr.graph$edges <- rbind(curr.graph$edges, append_rows)
# 
# 
# available_annotations <- available_annotations %>% distinct(annotation)
# 
# # add them as nodes, and the respective edges
# append_rows <- data.frame(id = available_annotations$annotation,
#                           label = available_annotations$annotation,
#                           group = rep("annotation", length(available_annotations$annotation)))
# rownames(append_rows) <- append_rows$id
# append_rows$shape <- 'square'
# append_rows$level <- '2'
# 
# curr.graph$nodes <- rbind(append_rows, curr.graph$nodes)
# 
# curr.graph$nodes$temp1 <- T
# curr.graph$nodes$temp1[1:5] <- F
# curr.graph$nodes$temp2 <- T
# curr.graph$nodes$temp2[7:15] <- F
available_nodes <- rownames(curr.graph$nodes)
annotation_vector <- c()
for (curr_node in rownames(curr.graph$nodes)){
  annotation_vector <- c(annotation_vector, paste(sort(available_annotations[which(available_annotations$genes %in% curr_node), 'annotation']), collapse = ','))
}
curr.graph$nodes$annotation <- annotation_vector

curr.graph$nodes[top_genes,'group'] <- 'top_genes'
curr.graph$nodes[top_genes,'level'] <- 2
#width = 1920, height = 1920
plot.all <- visNetwork(curr.graph$nodes, curr.graph$edges, background = 'white') %>%
  visLayout(randomSeed = 42) %>%
  visGroups(groupname = "chosen_node", color = "purple") %>%
  visGroups(groupname = "top_genes", color = "red") %>%
  visGroups(groupname = "chosen_node_2_way", color = "red") %>%
  visGroups(groupname = "chosen_node_3_way", color = "orange") %>%
  visGroups(groupname = "chosen_node_4_way", color = "green") %>%
  visPhysics(solver = "forceAtlas2Based",
             forceAtlas2Based = list(gravitationalConstant = -100)) %>%
  #visGroups(groupname = "annotation", color = "black") %>%
  visGroups(groupname = "node", color = "blue") %>%
  visOptions(highlightNearest = list(enabled = TRUE, degree = 1,
                                     labelOnly = FALSE, hover = TRUE),
             #nodesIdSelection = TRUE,
             selectedBy = list(variable = "annotation", multiple = TRUE))

plot.all
#,
             #nodesIdSelection = list(selected = 6))
#%>%
#visEdges(color = list(color = "blue", highlight = "red"))

# export specific annotations

# there will be 5 levels,
# level 1: only pathway 1 associates, not within
# level 2: only pathway 1 within, no pathway 2
# level 3: pathway 1-2 overlap
# level 4: only pathway 2 within, no pathway 1
# level 4: only pathway 2 associates, not within


all_annotations <- list(c('Apoptosis', 'Autosis'),
                     c('Apoptosis', 'Mitotic_CD'),
                     c('Autosis', 'Mitotic_CD'))

specific_annotations <- all_annotations[[3]]

for (specific_annotations in all_annotations){
  
  print('Currently on:')
  print(paste0(specific_annotations, collapse = '_'))
  subset.graph <- curr.graph
  
  #specific_annotations <- c('Apoptosis', 'Autosis')
  #specific_annotations <- c('Autosis', 'Mitotic_CD')
  
  subset.graph$nodes$level <- -1
  subset.graph$nodes$group <- as.character(subset.graph$nodes$level)
  
  pathway_1 <- specific_annotations[1]
  pathway_2 <- specific_annotations[2]
  
  
  
  
  # level 3
  idx <- grepl(pathway_1, subset.graph$nodes$annotation, fixed = T) & grepl(pathway_2, subset.graph$nodes$annotation, fixed = T)
  subset.graph$nodes$level[idx] <- 3
  subset.graph$nodes$group[idx] <- "3"
  
  # level 2
  idx <- grepl(pathway_1, subset.graph$nodes$annotation, fixed = T) & !grepl(pathway_2, subset.graph$nodes$annotation, fixed = T)
  subset.graph$nodes$level[idx] <- 2
  subset.graph$nodes$group[idx] <- "2"
  
  # level 4
  idx <- !grepl(pathway_1, subset.graph$nodes$annotation, fixed = T) & grepl(pathway_2, subset.graph$nodes$annotation, fixed = T)
  subset.graph$nodes$level[idx] <- 4
  subset.graph$nodes$group[idx] <- "4"
  
  # level 3.5
  # for nodes that are connected to the overlap
  # curr_nodes <- rownames(subset.graph$nodes[subset.graph$nodes$level == 3,])
  # 
  # associate_nodes <- unique(c(subset.graph$edges[subset.graph$edges$from %in% curr_nodes, 'to'],
  #                             subset.graph$edges[subset.graph$edges$to %in% curr_nodes, 'from']))
  # 
  # intersect(associate_nodes, curr_nodes)
  # associate_nodes <- setdiff(associate_nodes, curr_nodes)
  # change_idx <- subset.graph$nodes[associate_nodes, 'level'] == -1
  # subset.graph$nodes[associate_nodes, 'level'][change_idx] <- 3
  # subset.graph$nodes[associate_nodes, 'group'][change_idx] <- '3associates_1_overlap'
  
  # level 1
  # get the nodes that are in group 2
  curr_nodes <- rownames(subset.graph$nodes[subset.graph$nodes$level == 2,])
  
  associate_nodes <- unique(c(subset.graph$edges[subset.graph$edges$from %in% curr_nodes, 'to'],
                       subset.graph$edges[subset.graph$edges$to %in% curr_nodes, 'from']))
  
  associate_nodes <- setdiff(associate_nodes, curr_nodes)
  change_idx <- subset.graph$nodes[associate_nodes, 'level'] == -1
  subset.graph$nodes[associate_nodes, 'level'][change_idx] <- 1
  subset.graph$nodes[associate_nodes, 'group'][change_idx] <- '1'
  
  # level 5
  # get the nodes that are in group 4
  curr_nodes <- rownames(subset.graph$nodes[subset.graph$nodes$level == 4,])
  
  associate_nodes <- unique(c(subset.graph$edges[subset.graph$edges$from %in% curr_nodes, 'to'],
                       subset.graph$edges[subset.graph$edges$to %in% curr_nodes, 'from']))
  
  associate_nodes <- setdiff(associate_nodes, curr_nodes)
  change_idx <- subset.graph$nodes[associate_nodes, 'level'] == -1
  subset.graph$nodes[associate_nodes, 'level'][change_idx] <- '5'
  subset.graph$nodes[associate_nodes, 'group'][change_idx] <- '5'
  
  # if shared with level 1, they are in the middle
  change_idx <- subset.graph$nodes[associate_nodes, 'level'] == 1
  subset.graph$nodes[associate_nodes, 'level'][change_idx] <- 3
  subset.graph$nodes[associate_nodes, 'group'][change_idx] <- '3associates_2_exclusion'
  
  
  # now, remove the genes that are not in the levels
  keep_genes <- rownames(subset.graph$nodes[subset.graph$nodes$level != '-1',])
  subset.graph$nodes <- subset.graph$nodes[keep_genes,]
  subset.graph$edges <- subset.graph$edges[(subset.graph$edges$from %in% keep_genes) & (subset.graph$edges$to %in% keep_genes), ]
  subset.graph$nodes <- subset.graph$nodes[order(subset.graph$nodes$group),]
  
  subset.graph$edges$color <- 'blue'
  subset.graph$edges$color[subset.graph$edges$color == 'blue'] <- 'light blue'
  
  # remove the edges between green-green
  green_nodes <- rownames(subset.graph$nodes[(subset.graph$nodes$group == '1') | (subset.graph$nodes$group == '5') | (subset.graph$nodes$group == '3associates_2_exclusion'),])
  subset.graph$edges <- subset.graph$edges[!((subset.graph$edges$from %in% green_nodes) & (subset.graph$edges$to %in% green_nodes)),]
  
  # any interaction with green nodes are light
  green_nodes <- rownames(subset.graph$nodes[(subset.graph$nodes$group == '1') | (subset.graph$nodes$group == '5') | (subset.graph$nodes$group == '3associates_2_exclusion'),])
  subset.graph$edges[(subset.graph$edges$from %in% green_nodes) | (subset.graph$edges$to %in% green_nodes), 'color'] <- 'light green'
  
  
  # blue color edges: within pathways
  orange_nodes <- rownames(subset.graph$nodes[(subset.graph$nodes$group == '2') | (subset.graph$nodes$group == '4'),])
  subset.graph$edges[(subset.graph$edges$from %in% orange_nodes) & (subset.graph$edges$to %in% orange_nodes), 'color'] <- 'dark blue'
  
  
  # red edges, across pathways
  left_side <- rownames(subset.graph$nodes[subset.graph$nodes$group == '2',])
  right_side <- rownames(subset.graph$nodes[subset.graph$nodes$group == '4',])
  idx <- (subset.graph$edges$from %in% left_side) & (subset.graph$edges$to %in% right_side)
  idx <- idx | ((subset.graph$edges$from %in% right_side) & (subset.graph$edges$to %in% left_side))
  subset.graph$edges[idx, 'color'] <- 'red'
  
  left_side <- rownames(subset.graph$nodes[(subset.graph$nodes$group == '2') | (subset.graph$nodes$group == '4'),])
  right_side <- rownames(subset.graph$nodes[subset.graph$nodes$group == '3',])
  idx <- (subset.graph$edges$from %in% left_side) & (subset.graph$edges$to %in% right_side)
  idx <- idx | ((subset.graph$edges$from %in% right_side) & (subset.graph$edges$to %in% left_side))
  subset.graph$edges[idx, 'color'] <- 'red'
  
  # blue edges, include
  
  
  # blue/ish-greenfor the black nodes
  black_nodes <- rownames(subset.graph$nodes[(subset.graph$nodes$group == '3associates_2_exclusion'),])
  subset.graph$edges[(subset.graph$edges$from %in% black_nodes) & (subset.graph$edges$to %in% black_nodes), 'color'] <- 'dark green'
  
  
  
  
  #table(subset.graph$edges$color)
  
  #subset.graph$nodes$group <- as.character(subset.graph$nodes$level)
  #subset.graph$nodes$shape
  subset.graph$nodes$shape <- 'dot'
  subset.graph$nodes$font.color <- 'black'
  ##
  # 
  # idx <- rep(F, dim(subset.graph$nodes)[1])
  # for (specific_annotation in specific_annotations){
  #   idx <- idx | grepl(specific_annotation, subset.graph$nodes$annotation, fixed = T)
  # }
  # 
  # subset.graph$nodes <- subset.graph$nodes[idx, ]
  # subset.graph$edges <- subset.graph$edges[(subset.graph$edges$from %in% rownames(subset.graph$nodes)) | (subset.graph$edges$to %in% rownames(subset.graph$nodes)), ]
  
  #length(unique(c(pathway_list[['Autosis']], pathway_list[['Mitotic_CD']])))
  
  ### the layouts does an overlap on the nodes, so keep them askew
  subset.graph$nodes$level <- as.numeric(subset.graph$nodes$level)
  table(subset.graph$nodes$level)
  
  unique_level <- sort(unique(subset.graph$nodes$level))
  seperator <- 3
  seperator <- -1 * (seq(0, (length(unique_level) - 1) * seperator, seperator) + 1)
  names(seperator) <- unique_level
  
  
  for (count in seq_along(unique_level)){
    level <- unique_level[count]
    subset.graph$nodes$level[subset.graph$nodes$level == level] <- seperator[level]
  }
  subset.graph$nodes$level <- -1 * subset.graph$nodes$level
  
  
  #subset.graph$nodes$level <- subset.graph$nodes$level - min(subset.graph$nodes$level) + 1
  
  temp <- subset.graph$nodes
  # to_remove <- rownames(subset.graph$nodes[subset.graph$nodes$group == "3associates_1_overlap",])
  # subset.graph$nodes <- subset.graph$nodes[subset.graph$nodes$group != "3associates_1_overlap",]
  # subset.graph$edges <- subset.graph$edges[!((subset.graph$edges$from %in% to_remove) | (subset.graph$edges$from %in% to_remove)),]
  # 
  
  # 
  subset.graph$nodes <- temp
  node_set <- 3
  increment_val <- 2/node_set
  #increment_val <- 0.2
  increment_val <- increment_val * (seq(node_set) - 1)
  for (curr_level in sort(unique(subset.graph$nodes$level))){
    curr_nodes <- subset.graph$nodes[subset.graph$nodes$level == curr_level,]
    if (dim(curr_nodes)[1] < 2){
      next
    }
    for (increment_idx in seq(ceiling((dim(curr_nodes)[1])/node_set)) - 1){
      start_idx <- (node_set * increment_idx) + 1
      end_idx <- (node_set * increment_idx) + node_set
      if (end_idx > dim(curr_nodes)[1]){
        end_idx <- dim(curr_nodes)[1]
      }
      num_to_increase <- end_idx - start_idx + 1
      curr_nodes$level[start_idx:end_idx] <- curr_nodes$level[start_idx:end_idx] + increment_val[1:num_to_increase]
    }
    subset.graph$nodes[subset.graph$nodes$level == curr_level,] <- curr_nodes
  
  }
  
  table(subset.graph$edges$color)
  
  color_mapper <- list()
  color_mapper[['dark blue']] <- 'orange' #00008B'
  color_mapper[['light blue']] <- '#ADD8E6'
  color_mapper[['dark green']] <- '#4B0092'
  color_mapper[['light green']] <- '#6f6A68'##03C03C'
  color_mapper[['red']] <- '#FF007F'#'#D41159' ##03C03C'
  
  
  for (color in names(color_mapper)){
    subset.graph$edges$color[subset.graph$edges$color == color] <- color_mapper[[color]]
  }
  subset.graph$nodes$color.border <- 'black'
  subset.graph$nodes[subset.graph$nodes$group == '1', 'color'] <- '#FEFEFA' #'#6f6A68' 
  subset.graph$nodes[subset.graph$nodes$group == '2', 'color'] <- 'orange'# '#1A85FF'
  subset.graph$nodes[subset.graph$nodes$group == '3', 'color'] <- '#FF007F' 
  subset.graph$nodes[subset.graph$nodes$group == '3associates_2_exclusion', 'color'] <- '#808080'#'black' #'#4B0092
  subset.graph$nodes[subset.graph$nodes$group == '4', 'color'] <- 'orange'
  subset.graph$nodes[subset.graph$nodes$group == '5', 'color'] <- '#FEFEFA'# '#6f6A68'
  # 
  #background = 'white'
  
  plot.subset <- visNetwork(subset.graph$nodes, subset.graph$edges, width = 1920, height = 1920) %>%
    visLayout(randomSeed = 42) %>%
    #visNodes(scaling = list(label = list(enabled = T))) %>%
    visNodes(size = 10) %>%#, font = list(size = 0)
    visHierarchicalLayout(direction = "LR") %>%
    # visGroups(groupname = "1", color = 'white', color.border = 'black') %>% #light greencolor_mapper[['light green']]
    # visGroups(groupname = "2", color = color_mapper[['dark blue']]) %>%
    # visGroups(groupname = "3", color = "red") %>%
    # visGroups(groupname = "3associates_1_overlap", color = "white") %>%
    # visGroups(groupname = "3associates_2_exclusion", color = color_mapper[['dark green']]) %>% #dark green
    # visGroups(groupname = "4", color = color_mapper[['dark blue']]) %>%
    # visGroups(groupname = "5", color = color_mapper[['light green']]) %>%
    visPhysics(solver = "forceAtlas2Based",
               forceAtlas2Based = list(gravitationalConstant = -100),
               hierarchicalRepulsion = list(avoidOverlap = 0.99)) %>%
    #visGroups(groupname = "annotation", color = "black") %>%
    #visGroups(groupname = "node", color = "blue") %>%
    visOptions(highlightNearest = list(enabled = TRUE, degree = 1,
                                       labelOnly = T, hover = TRUE),
               #nodesIdSelection = TRUE,
               selectedBy = list(variable = "annotation", multiple = TRUE))
  
  
  
  plot.subset
  # 
  # nodes <- data.frame(id = 1:3)
  # edges <- data.frame(from = c(1,2), to = c(1,3), value = c(1:2))
  # 
  # edges$color <- c('#00008B', '#006400')
  # nodes$color <- 'white'
  # # 
  # visNetwork(nodes, edges) %>% visNodes(shape = 'dot', color = list(border = 'purple'))
  
  save_file_loc <- file.path('plots_010523_V4', paste0(paste(specific_annotations, collapse = '_'), '.html'))
  
  visSave(plot.subset, file = save_file_loc, background = "white")

}
#webshot(save_file_loc, zoom = 2, file = file.path('plots_010523', paste0(paste(specific_annotations, collapse = '_'), '_webshot.png')))

# remove connections green-green

# green nodes: light edges

# blue color edges: between pathways
# blue/ish-greenfor the black nodes





visExport(plot.subset, type = "jpeg", name = file.path('plots_010523', 'export_network'), 
          float = "left", label = "Save network", background = "purple", style= "") 

visSave(plot.subset, file= file.path('plots_010223', paste0(paste(specific_annotations, collapse = '_'), '.html')))


plot.subset %>% visNetwork::visEvents(type = "on", beforeDrawing = "function(ctx) {
    ctx.font = \"50px serif\";
    ctx.fillText(\"Apoptosis\", -120, -650);
    ctx.fillText(\"Autosis\", 130, -650);
    ctx.fillStyle = 'rgba(255, 0, 255, 0.1)';
    ctx.ellipse(0, -150, 150, 500, 0, 0, 2 * Math.PI);
    ctx.fill();
    ctx.fillStyle = 'rgba(64, 255, 255,0.1)';
    ctx.ellipse(210 , -150, 200, 500, 0, 0, 2 * Math.PI, true);
    ctx.fill();
}")

visSave(plot, file= file.path('plots', 'network.html'))



visExport(plot, type = "jpeg", name = file.path('plots', 'export_network'), 
          float = "left", label = "Save network", background = "purple", style= "") 

visSave(plot, file= file.path('plots', 'network.html'))

nodes <- data.frame(id = 1:15, label = paste("Label", 1:15),
                    group = sample(LETTERS[1:3], 15, replace = TRUE), 
                    sex = sample(c("H", "F"), 15, replace = TRUE))

edges <- data.frame(from = trunc(runif(15)*(15-1))+1,
                    to = trunc(runif(15)*(15-1))+1)


# and with multiple groups ?
nodes$sel <- paste(nodes$group, nodes$sex, sep = ",")

visNetwork(nodes, edges) %>% 
  visOptions(selectedBy = list(variable = "sel", multiple = TRUE))


## proceed to color the nodes based on annotations


annotation_list <- list()
