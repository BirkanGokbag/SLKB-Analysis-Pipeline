library(grid)
library(VennDiagram)
library(nVennR)
library(stringr)
library(dbplyr)
#venn.plot <- draw.pairwise.venn(100, 70, 30, c("First", "Second"))
rm(list=ls())
gc()
# 
# load('1000_env.Rdata')
# names <- colnames(interaction_table)
# top1000_avg_percentage <- matrix(as.numeric(interaction_table), nrow = 5, ncol = 5)
# load('10percent_env.Rdata')
# names <- colnames(interaction_table)
# top10percent_avg_percentage <- matrix(as.numeric(interaction_table), nrow = 5, ncol = 5)
# 
# avg_table <- (top1000_avg_percentage + top10percent_avg_percentage)/2
# rownames(avg_table) <- names
# colnames(avg_table) <- names
# avg_table <- round(avg_table, 2)
# write.csv(avg_table, file = 'top1000_10percent_average_percentage.csv')

computed_data <- read.csv("../www/all_GI_RESULTS_110322.csv")
top_10p_choice <- '10percent'
#top_10p_choice <- 'all_pairs'
save_Rdata_name <- paste0(top_10p_choice, "_env_no_Zhao.Rdata")
save_dir <- paste0(c('venn_diagrams', top_10p_choice, '_no_ZHAO'), collapse = '_')
computed_data$Median.NB <- computed_data$Median.NB.Z
computed_data$Median.B <- computed_data$Median.B.Z
computed_data$MAGECK <- computed_data$MAGECK.Z

master.approaches.regions <- list()


master.area.vector.percentage <- list()
master.area.vector.count <- list()
pairwise_table <- list()

study <- 'Horlbeck'
cell_line <- "K562"
study <- 'Shantang'
cell_line <- "22Rv1"

ordered_names_3_way <- c("1, 0, 0 (Horlbeck)",
                         "1, 1, 0 (Horlbeck, MAGECK)",
                         "0, 1, 0 (MAGECK)",
                         "1, 0, 1 (Horlbeck, GEMINI)", 
                         "1, 1, 1 (Horlbeck, MAGECK, GEMINI)",
                         "0, 1, 1 (MAGECK, GEMINI)",
                         "0, 0, 1 (GEMINI)")

ordered_names_5_way <- c("1, 0, 0, 0, 0 (Median-NB)", #1
                         "0, 1, 0, 0, 0 (Median-B)", #2
                         "0, 0, 1, 0, 0 (Horlbeck)", #3
                         "0, 0, 0, 1, 0 (MAGECK)", #4
                         "0, 0, 0, 0, 1 (GEMINI)", #5
                         "0, 0, 1, 0, 1 (Horlbeck, GEMINI)", #6
                         "1, 0, 0, 0, 1 (Median-NB, GEMINI)", #7
                         "1, 0, 0, 1, 0 (Median-NB, MAGECK)", #8
                         "1, 1, 0, 0, 0 (Median-NB, Median-B)", #9
                         "0, 1, 0, 0, 1 (Median-B, GEMINI)", #10
                         "0, 1, 1, 0, 0 (Median-B, Horlbeck)", #11
                         "1, 0, 1, 0, 0 (Median-NB, Horlbeck)", #12
                         "0, 0, 1, 1, 0 (Horlbeck, MAGECK)", #13
                         "0, 1, 0, 1, 0 (Median-B, MAGECK)", #14
                         "0, 0, 0, 1, 1 (MAGECK, GEMINI)", #15
                         "0, 0, 1, 1, 1 (Horlbeck, MAGECK, GEMINI)", #16
                         "1, 0, 1, 0, 1 (Median-NB, Horlbeck, GEMINI)", #17
                         "1, 0, 0, 1, 1 (Median-NB, MAGECK, GEMINI)", #18
                         "1, 1, 0, 1, 0 (Median-NB, Median-B, MAGECK)", #19
                         "1, 1, 0, 0, 1 (Median-NB, Median-B, GEMINI)", #20
                         "0, 1, 1, 0, 1 (Median-B, Horlbeck, GEMINI)", #21
                         "1, 1, 1, 0, 0 (Median-NB, Median-B, Horlbeck)", #22
                         "1, 0, 1, 1, 0 (Median-NB, Horlbeck, MAGECK)", #23
                         "0, 1, 1, 1, 0 (Median-B, Horlbeck, MAGECK)", #24
                         "0, 1, 0, 1, 1 (Median-B, MAGECK, GEMINI)", #25
                         "0, 1, 1, 1, 1 (Median-B, Horlbeck, MAGECK, GEMINI)", #26
                         "1, 0, 1, 1, 1 (Median-NB, Horlbeck, MAGECK, GEMINI)", #27
                         "1, 1, 0, 1, 1 (Median-NB, Median-B, MAGECK, GEMINI)", #28
                         "1, 1, 1, 0, 1 (Median-NB, Median-B, Horlbeck, GEMINI)" , #29
                         "1, 1, 1, 1, 0 (Median-NB, Median-B, Horlbeck, MAGECK)", #30
                         "1, 1, 1, 1, 1 (Median-NB, Median-B, Horlbeck, MAGECK, GEMINI)") #31

num_SL <- list()

# temp <- draw.quintuple.venn(category = c("Median-NB", "Median-B", "Horlbeck", "MAGECK", "GEMINI"),
#                                  fill = c("orange", "red", "green", "blue", "pink"),
#                                  lty = "dashed",
#                                  cex = 2,
#                                  cat.cex = 2,
#                                  cat.col = c("orange", "red", "green", "blue", "pink"),
#                                  direct.area = TRUE,
#                                  area.vector = 1:33,
#                                  cat.just=list(c(0.6,1) , c(0,-4) , c(0,0) , c(1,1) , c(1,-2))
#                                  
# );
# 
# png(filename ='temp_plot.png', width = 1920, height = 1080)
# 
# grid.draw(temp);
# dev.off();





study <- 'Wong'
cell_line <- "OVCAR8"

for (study in sort(unique(computed_data$Study_Source))){
  print(study)
  curr_study <- computed_data[computed_data$Study_Source == study, ]
  
  master.area.vector.percentage[[study]] <- list()
  master.area.vector.count[[study]] <- list()
  num_SL[[study]] <- list()
  pairwise_table[[study]] <- list()
  
  for (cell_line in sort(unique(curr_study$Cell_Line))){
    
    save_loc <- file.path(save_dir, study, cell_line)
    
    master.area.vector.percentage[[study]][[cell_line]] <- list()
    master.area.vector.count[[study]][[cell_line]] <- list()
    pairwise_table[[study]][[cell_line]] <- list()
    
    approaches.median.nb <- c()
    approaches.median <- c()
    approaches.horlbeck <- c()
    approaches.mageck <- c()
    approaches.gemini <- c()
    
    print(cell_line)
    
    curr_subset <- curr_study[curr_study$Cell_Line == cell_line, ]
    
    print(dim(curr_subset))
    
    if (top_10p_choice == 'all_pairs'){
      ## Horlbeck
      horlbeck <- curr_subset[order(curr_subset$Horlbeck.Original), ]
      horlbeck <- horlbeck[horlbeck$Horlbeck.Original != Inf, ]
      horlbeck <- horlbeck[horlbeck$Horlbeck.Original < 0, 'Gene.Pair']
      horlbeck <- horlbeck[!is.na(horlbeck)]
      
      ## Median-NB Custom..1.
      median.nb <- curr_subset[order(curr_subset$Median.NB), ]
      median.nb <- median.nb[median.nb$Median.NB != Inf, ]
      median.nb <- median.nb[median.nb$Median.NB < 0, 'Gene.Pair']
      median.nb <- median.nb[!is.na(median.nb)]
      
      ## Median
      median <- curr_subset[order(curr_subset$Median.B), ]
      median <- median[median$Median.B != Inf, ]
      median <- median[median$Median.B < 0, 'Gene.Pair']
      median <- median[!is.na(median)]
      
      ## Mageck
      mageck <- curr_subset[order(curr_subset$MAGECK), ]
      mageck <- mageck[mageck$MAGECK != Inf, ]
      mageck <- mageck[mageck$MAGECK < 0, 'Gene.Pair']
      mageck <- mageck[!is.na(mageck)]
      
      ## GEMINI
      gemini <- curr_subset[order(curr_subset$GEMINI), ]
      gemini <- gemini[gemini$GEMINI != Inf, ]
      gemini <- gemini[gemini$GEMINI < 0, 'Gene.Pair']
      gemini <- gemini[!is.na(gemini)]
      
    } else {
      
      if (grepl('percent', top_10p_choice, fixed = TRUE)){
        top_10p <- as.numeric(gsub('percent', '', top_10p_choice, fixed = TRUE))
        top_10p <- round(dim(curr_subset)[1] * top_10p / 100)
      } else {
        top_10p <- as.numeric(top_10p_choice)
      }
      top_10p <- min(top_10p, dim(curr_subset)[1])
      
      
      ## Horlbeck
      horlbeck <- curr_subset[order(curr_subset$Horlbeck.Original), ]
      horlbeck <- horlbeck[horlbeck$Horlbeck.Original != Inf, ]
      #horlbeck <- horlbeck[horlbeck$Horlbeck.Original < 0, 'Gene.Pair']
      horlbeck <- horlbeck$Gene.Pair[1:top_10p]
      horlbeck <- horlbeck[!is.na(horlbeck)]
      
      ## Median-NB Custom..1.
      median.nb <- curr_subset[order(curr_subset$Median.NB), ]
      median.nb <- median.nb[median.nb$Median.NB != Inf, ]
      #median.nb <- median.nb[median.nb$Median.NB < 0, 'Gene.Pair']
      median.nb <- median.nb$Gene.Pair[1:top_10p]
      median.nb <- median.nb[!is.na(median.nb)]
      
      ## Median
      median <- curr_subset[order(curr_subset$Median.B), ]
      median <- median[median$Median.B != Inf, ]
      #median <- median[median$Median.B < 0, 'Gene.Pair']
      median <- median$Gene.Pair[1:top_10p]
      median <- median[!is.na(median)]
      
      ## Mageck
      mageck <- curr_subset[order(curr_subset$MAGECK), ]
      mageck <- mageck[mageck$MAGECK != Inf, ]
      #mageck <- mageck[mageck$MAGECK < 0, 'Gene.Pair']
      mageck <- mageck$Gene.Pair[1:top_10p]
      mageck <- mageck[!is.na(mageck)]
      
      ## GEMINI
      gemini <- curr_subset[order(curr_subset$GEMINI), ]
      gemini <- gemini[gemini$GEMINI != Inf, ]
      #gemini <- gemini[gemini$GEMINI < 0, 'Gene.Pair']
      gemini <- gemini$Gene.Pair[1:top_10p]
      gemini <- gemini[!is.na(gemini)]
    }
    
    num_SL[[study]][[cell_line]] <- unique(c(median.nb, median, horlbeck, mageck, gemini))
   
    approaches.median.nb <- c(approaches.median.nb, median.nb)
    approaches.median <- c(approaches.median, median)
    approaches.horlbeck <- c(approaches.horlbeck, horlbeck)
    approaches.mageck <- c(approaches.mageck, mageck)
    approaches.gemini <- c(approaches.gemini, gemini)
    
    approaches <- list("Median-NB" = median.nb, 
                       "Median-B" = median, 
                       "Horlbeck" = horlbeck, 
                       "MAGECK" = mageck, 
                       "GEMINI" = gemini)
    
    approaches <- plotVenn(approaches, showPlot = F)
    approaches.regions <- listVennRegions(approaches, na.rm = F)
    
    approaches_3_way <- list("Horlbeck" = approaches.horlbeck, 
                             "MAGECK" = approaches.mageck, 
                             "GEMINI" = approaches.gemini)
    
    approaches_3_way <- plotVenn(approaches_3_way, showPlot = F)
    approaches_3_way.regions <- listVennRegions(approaches_3_way, na.rm = F)
    
    #names(approaches.regions)
    
    sum_of_all = 0
    for (name in names(approaches.regions)){
      sum_of_all <- sum_of_all + sum(!is.na(approaches.regions[[name]]))
    }
    
    dir.create(save_loc, recursive = TRUE)
    
    ####### unique counts
    
    numbered <- list()
    for (name in names(approaches.regions)){
      numbered[[name]] <- sum(!is.na(approaches.regions[[name]]))
    }
    
    area.vector <- c()
    for (name in ordered_names_5_way){
      area.vector <- c(area.vector, numbered[[name]])
    }
    
    venn.plot <- draw.quintuple.venn(category = c("Median-NB", "Median-B", "Horlbeck", "MAGECK", "GEMINI"),
                                     fill = c("orange", "red", "green", "blue", "pink"),
                                     lty = "dashed",
                                     cex = 2,
                                     cat.cex = 2,
                                     cat.col = c("orange", "red", "green", "blue", "pink"),
                                     direct.area = TRUE,
                                     area.vector = area.vector,
                                     print.mode = 'raw',
                                     cat.just=list(c(0.6,1) , c(0,-4) , c(0,0) , c(1,1) , c(1,-2))
                                     
    );
    
    master.area.vector.count[[study]][[cell_line]][['5-way']] <- area.vector
    
    png(filename =  file.path(save_loc, paste0(sum_of_all, "unique_pairs+", top_10p_choice, "_venn_unique_counts.png")), width = 1920, height = 1080)
    
    grid.draw(venn.plot);
    dev.off();
    
    
    ## w/ percentage
    
    master.area.vector.percentage[[study]][[cell_line]][['5-way']] <- area.vector * 100 / sum_of_all
    
    venn.plot <- draw.quintuple.venn(category = c("Median-NB", "Median-B", "Horlbeck", "MAGECK", "GEMINI"),
                                     fill = c("orange", "red", "green", "blue", "pink"),
                                     lty = "dashed",
                                     cex = 2,
                                     cat.cex = 2,
                                     cat.col = c("orange", "red", "green", "blue", "pink"),
                                     direct.area = TRUE,
                                     area.vector = round(area.vector * 100 / sum_of_all, 2),
                                     #print.mode = 'percentage',
                                     cat.just=list(c(0.6,1) , c(0,-4) , c(0,0) , c(1,1) , c(1,-2))
                                     
    )
    
    dir.create(save_loc, recursive = TRUE)
    
    png(filename =  file.path(save_loc, paste0(sum_of_all, "unique_pairs+", top_10p_choice, "_percentage.png")), width = 1920, height = 1080)
    
    grid.draw(venn.plot);
    dev.off();
    
    ##### 3 way
    ####### unique counts
    sum_of_all = 0
    for (name in names(approaches_3_way.regions)){
      sum_of_all <- sum_of_all + sum(!is.na(approaches_3_way.regions[[name]]))
    }
    
    numbered <- list()
    for (name in names(approaches_3_way.regions)){
      numbered[[name]] <- sum(!is.na(approaches_3_way.regions[[name]]))
    }
    
    area.vector <- c()
    for (name in ordered_names_3_way){
      area.vector <- c(area.vector, numbered[[name]])
    }
    
    venn.plot <- draw.triple.venn(category = c("Horlbeck", "MAGECK", "GEMINI"),
                                     fill = c("green", "blue", "pink"),
                                     lty = "dashed",
                                     cex = 2,
                                     cat.cex = 2,
                                     cat.col = c("green", "blue", "pink"),
                                     direct.area = TRUE,
                                     print.mode = 'raw',
                                     area.vector = area.vector)
                                     #cat.just=list(c(0,0) , c(0.6,0.6) , c(0.6,-1.2)))

    
    master.area.vector.count[[study]][[cell_line]][['3-way']] <- area.vector
    
    png(filename =  file.path(save_loc, paste0(sum_of_all, "unique_pairs+", top_10p_choice, "_3_way_venn_unique_counts.png")), width = 1920, height = 1080)
    
    grid.draw(venn.plot);
    dev.off();
    
    
    ## w/ percentage
    
    master.area.vector.percentage[[study]][[cell_line]][['3-way']] <- area.vector * 100 / sum_of_all
    
    venn.plot <- draw.triple.venn(category = c("Horlbeck", "MAGECK", "GEMINI"),
                                  fill = c("green", "blue", "pink"),
                                  lty = "dashed",
                                  cex = 2,
                                  cat.cex = 2,
                                  cat.col = c("green", "blue", "pink"),
                                  direct.area = TRUE,
                                  #print.mode = 'percentage',
                                  area.vector = round(area.vector * 100 / sum_of_all, 2))
    
    
    dir.create(save_loc, recursive = TRUE)
    
    png(filename =  file.path(save_loc, paste0(sum_of_all, "unique_pairs+", top_10p_choice, "_3_way_venn_percentage.png")), width = 1920, height = 1080)
    
    grid.draw(venn.plot);
    dev.off();
    
    ###### pairwise table
    
    all_pairs <- list()
    all_pairs[['Horlbeck']] <- horlbeck
    all_pairs[['GEMINI']] <- gemini
    all_pairs[['MAGeCK']] <- mageck
    all_pairs[['Median-B']] <- median
    all_pairs[['Median-NB']] <- median.nb
    
    interaction_table <- matrix(0, nrow = 5, ncol = 5)
    colnames(interaction_table) <- c('Median-NB', 'Median-B', 'Horlbeck', 'MAGeCK', 'GEMINI')
    rownames(interaction_table) <- c('Median-NB', 'Median-B', 'Horlbeck', 'MAGeCK', 'GEMINI')
    for (i in rownames(interaction_table)){
      for (j in colnames(interaction_table)){
        # if (i == j){
        #   next
        # }
        union_genes <- union(all_pairs[[i]], all_pairs[[j]])
        intersecting_genes <- intersect(all_pairs[[i]], all_pairs[[j]])
        interaction_table[i, j] <- length(intersecting_genes) * 100 / length(union_genes)
        #interaction_table[j, i] <- length(intersecting_genes) / length(union_genes)
      }
    }
    #interaction_table['Median-B', 'Median-B'] <- 100
    #interaction_table[lower.tri(interaction_table)] <- NaN
    interaction_table[is.na(interaction_table)] <- 0
    
    pairwise_table[[study]][[cell_line]] <- interaction_table
    
    interaction_table <- round(interaction_table, 2)
    write.csv(interaction_table, na = "-", file = file.path(save_loc, paste0(sum_of_all, "unique_pairs+", top_10p_choice, "_pairwise_percentage_table.csv")))
    
    
    
    
  }
  
  print("------")
}

master.area.vector.count[['Zhao']] <- NULL
pairwise_table[['Zhao']] <- NULL
                         


### N way overlap indexes ###
idx.N_way <- list()

for (i in seq_along(ordered_names_5_way)){
  name <- ordered_names_5_way[i]
  num_repeated <- paste0(str_count(name, "1"), '_way')
  
  if (num_repeated %in% names(idx.N_way)){
    idx.N_way[[num_repeated]] <- c(idx.N_way[[num_repeated]], i)
  } else {
    idx.N_way[[num_repeated]] <- c(i)
  }
  
}

idx.N_way_names <- names(idx.N_way) 

num_studies <- 0
for (study in names(master.area.vector.count)){
  for (cell_line in names(master.area.vector.count[[study]])){
    num_studies <- num_studies + 1
  }
}
print(num_studies)

grepl('Median-B', ordered_names_5_way, fixed = TRUE)
for (study in names(master.area.vector.count)){
  for (cell_line in names(master.area.vector.count[[study]])){
    
    # print(unlist(master.area.vector.count[[study]][[cell_line]]))
    # 
    # print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['4_way']]])
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['5_way']]])
    if(sum(unlist(master.area.vector.count[[study]][[cell_line]][['5-way']])[grepl('Median-B', ordered_names_5_way, fixed = TRUE)]) == 0){
      print(study)
      print(cell_line)
    }
  }
}

## 5 way
## average the counts
area.vector <- unlist(c(rep(0, length(ordered_names_5_way))))
for (study in names(master.area.vector.count)){
  for (cell_line in names(master.area.vector.count[[study]])){
    
    # print(unlist(master.area.vector.count[[study]][[cell_line]]))
    # 
    # print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['4_way']]])
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['5_way']]])
    area.vector <- area.vector + unlist(master.area.vector.count[[study]][[cell_line]][['5-way']])
  }
}
area.vector <- area.vector / num_studies
area.vector <- floor(area.vector)
#area.vector <- round(area.vector, 2)

venn.plot <- draw.quintuple.venn(category = c("Median-NB", "Median-B", "Horlbeck", "MAGECK", "GEMINI"),
                                 fill = c("orange", "red", "green", "blue", "pink"),
                                 lty = "dashed",
                                 cex = 2,
                                 cat.cex = 2,
                                 cat.col = c("orange", "red", "green", "blue", "pink"),
                                 direct.area = TRUE,
                                 area.vector = area.vector,
                                 cat.just=list(c(0.6,1) , c(0,-4) , c(0,0) , c(1,1) , c(1,-2))
                                 
)

png(filename = file.path(save_dir, paste0(top_10p_choice, "_5_way_intersecting_average_counts.png")), width = 1920, height = 1080)
#png(filename = file.path(save_dir, paste0(top_10p_choice, "_5_way_intersecting_average_counts_no_Zhao.png")), width = 1920, height = 1080)

grid.draw(venn.plot)
dev.off()

# for (way in idx.N_way_names){
#   idx.N_way[[paste0(way, '_counts_avg')]] <- mean(area.vector[idx.N_way[[way]]])
# }
# 
# for (way in idx.N_way_names){
#   idx.N_way[[paste0(way, '_counts_max')]] <- max(area.vector[idx.N_way[[way]]])
#   
#   names(idx.N_way[[paste0(way, '_counts_max')]]) <- ordered_names_5_way[[idx.N_way[[way]][[which(area.vector[idx.N_way[[way]]] == idx.N_way[[paste0(way, '_counts_max')]])]]]]
#   
# }

## do the average percentage as well

## average the percentages
area.vector <- unlist(c(rep(0, length(ordered_names_5_way))))
for (study in names(master.area.vector.percentage)){
  for (cell_line in names(master.area.vector.percentage[[study]])){
    
    #print(unlist(master.area.vector.count[[study]][[cell_line]]))
    
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['4_way']]])
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['5_way']]])
    #print(sum(master.area.vector.percentage[[study]][[cell_line]]))
    area.vector <- area.vector + unlist(master.area.vector.percentage[[study]][[cell_line]][['5-way']])
  }
}
area.vector <- area.vector / num_studies
area.vector <- round(area.vector, 2)

venn.plot <- draw.quintuple.venn(category = c("Median-NB", "Median-B", "Horlbeck", "MAGECK", "GEMINI"),
                                 fill = c("orange", "red", "green", "blue", "pink"),
                                 lty = "dashed",
                                 cex = 2,
                                 cat.cex = 2,
                                 cat.col = c("orange", "red", "green", "blue", "pink"),
                                 direct.area = TRUE,
                                 area.vector = area.vector,
                                 cat.just=list(c(0.6,1) , c(0,-4) , c(0,0) , c(1,1) , c(1,-2))
                                 
)

png(filename = file.path(save_dir, paste0(top_10p_choice, "_5_way_intersecting_average_percentage.png")), width = 1920, height = 1080)
#png(filename = file.path(save_dir, paste0(top_10p_choice, "_5_way_intersecting_average_percentage_no_Zhao.png")), width = 1920, height = 1080)

grid.draw(venn.plot)
dev.off()

## do the tables
avg_interaction_table <- matrix(0, nrow = 5, ncol = 5)
colnames(avg_interaction_table) <- c('Median-NB', 'Median-B', 'Horlbeck', 'MAGeCK', 'GEMINI')
rownames(avg_interaction_table) <- c('Median-NB', 'Median-B', 'Horlbeck', 'MAGeCK', 'GEMINI')
for (study in names(pairwise_table)){
  for (cell_line in names(pairwise_table[[study]])){
    avg_interaction_table <- avg_interaction_table + pairwise_table[[study]][[cell_line]]
    #print(pairwise_table[[study]][[cell_line]])
  }
}
avg_interaction_table <- avg_interaction_table / num_studies
avg_interaction_table['Median-B','Median-B'] <- 100
avg_interaction_table <- round(avg_interaction_table, 2)
write.csv(avg_interaction_table, file = file.path(save_dir, paste0(top_10p_choice, "_average_pairwise_percentage.csv")))
#write.csv(avg_interaction_table, file = file.path(save_dir, paste0(top_10p_choice, "_average_pairwise_percentage_no_Zhao.csv")))


avg_interaction_table <- matrix(0, nrow = 5, ncol = 5)
colnames(avg_interaction_table) <- c('Median-NB', 'Median-B', 'Horlbeck', 'MAGeCK', 'GEMINI')
rownames(avg_interaction_table) <- c('Median-NB', 'Median-B', 'Horlbeck', 'MAGeCK', 'GEMINI')
adjust_for_median_b <- 0
for (study in names(pairwise_table)){
  for (cell_line in names(pairwise_table[[study]])){
    avg_interaction_table <- avg_interaction_table + pairwise_table[[study]][[cell_line]]
    #print(pairwise_table[[study]][[cell_line]])
    if (pairwise_table[[study]][[cell_line]]['Median-B', 'Median-B'] == 0){
      print(study)
      print(cell_line)
      adjust_for_median_b <- adjust_for_median_b + 1
    }
  }
}
avg_interaction_table <- avg_interaction_table / num_studies
avg_interaction_table['Median-B',] <- avg_interaction_table['Median-B',] * num_studies / (num_studies - adjust_for_median_b)
avg_interaction_table[,'Median-B'] <- avg_interaction_table[,'Median-B'] * num_studies / (num_studies - adjust_for_median_b)
avg_interaction_table['Median-B','Median-B'] <- 100
avg_interaction_table <- round(avg_interaction_table, 2)
write.csv(avg_interaction_table, file = file.path(save_dir, paste0(top_10p_choice, "_average_pairwise_percentage_median_b_adjusted.csv")))
# avg_interaction_table <- matrix(0, nrow = 5, ncol = 5)
# colnames(interaction_table) <- names(all_pairs)
# rownames(interaction_table) <- names(all_pairs)
# for (study in names(pairwise_table)){
#   for (cell_line in names(pairwise_table[[study]])){
#     avg_interaction_table <- avg_interaction_table + pairwise_table[[study]][[cell_line]]
#     #print(pairwise_table[[study]][[cell_line]])
#   }
# }
# avg_interaction_table <- avg_interaction_table / num_studies
# 
# write.csv(avg_interaction_table, file = file.path(save_dir, paste0(top_10p_choice, "_average_pairwise.csv")))
# 
## pairwise table
# interaction_table <- matrix(0, nrow = 5, ncol = 5)
# colnames(interaction_table) <- c('Median-B', 'Median-NB','Horlbeck','MAGECK','GEMINI')
# rownames(interaction_table) <- c('Median-B', 'Median-NB','Horlbeck','MAGECK','GEMINI')
# 
# for (row_name in rownames(interaction_table)){
#   for (col_name in colnames(interaction_table)){
#     for (i in seq_along(area.vector)){
#       curr_name <- ordered_names_5_way[i]
#       curr_percentage <- area.vector[i]
# 
#       if (grepl(row_name, curr_name, fixed = TRUE) & grepl(col_name, curr_name, fixed = TRUE)){
#         interaction_table[row_name, col_name] <- interaction_table[row_name, col_name] + curr_percentage
#         #interaction_table[col_name, row_name] <- interaction_table[col_name, row_name] + curr_percentage
#       }
#     }
#   }
# }
# 
# interaction_table['Median-B', 'Median-B'] <- area.vector[which(ordered_names_5_way == '0, 1, 0, 0, 0 (Median-B)')]
# interaction_table['Median-NB', 'Median-NB'] <- area.vector[which(ordered_names_5_way == '1, 0, 0, 0, 0 (Median-NB)')]
# interaction_table['Horlbeck', 'Horlbeck'] <- area.vector[which(ordered_names_5_way == '0, 0, 1, 0, 0 (Horlbeck)')]
# interaction_table['MAGECK', 'MAGECK'] <- area.vector[which(ordered_names_5_way == '0, 0, 0, 1, 0 (MAGECK)')]
# interaction_table['GEMINI', 'GEMINI'] <- area.vector[which(ordered_names_5_way == '0, 0, 0, 0, 1 (GEMINI)')]
# 
# interaction_table[lower.tri(interaction_table)] <- '-'
# 
# write.csv(interaction_table, file = file.path(save_dir, paste0(top_10p_choice, "_average_pairwise_percentage.csv")))

#### 3 way
## average the counts
area.vector <- unlist(c(rep(0, length(ordered_names_3_way))))
for (study in names(master.area.vector.count)){
  for (cell_line in names(master.area.vector.count[[study]])){
    
    # print(unlist(master.area.vector.count[[study]][[cell_line]]))
    # 
    # print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['4_way']]])
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['5_way']]])
    area.vector <- area.vector + unlist(master.area.vector.count[[study]][[cell_line]][['3-way']])
  }
}
area.vector <- area.vector / num_studies
area.vector <- floor(area.vector)
#area.vector <- round(area.vector, 2)

venn.plot <- draw.triple.venn(category = c("Horlbeck", "MAGECK", "GEMINI"),
                              fill = c("green", "blue", "pink"),
                              lty = "dashed",
                              cex = 2,
                              cat.cex = 2,
                              cat.col = c("green", "blue", "pink"),
                              direct.area = TRUE,
                              area.vector = area.vector)

png(filename = file.path(save_dir, paste0(top_10p_choice, "_3_way_intersecting_average_counts.png")), width = 1920, height = 1080)

grid.draw(venn.plot)
dev.off()

# for (way in idx.N_way_names){
#   idx.N_way[[paste0(way, '_counts_avg')]] <- mean(area.vector[idx.N_way[[way]]])
# }
# 
# for (way in idx.N_way_names){
#   idx.N_way[[paste0(way, '_counts_max')]] <- max(area.vector[idx.N_way[[way]]])
#   
#   names(idx.N_way[[paste0(way, '_counts_max')]]) <- ordered_names_5_way[[idx.N_way[[way]][[which(area.vector[idx.N_way[[way]]] == idx.N_way[[paste0(way, '_counts_max')]])]]]]
#   
# }

## do the average percentage as well

## average the percentages
area.vector <- unlist(c(rep(0, length(ordered_names_3_way))))
for (study in names(master.area.vector.percentage)){
  for (cell_line in names(master.area.vector.percentage[[study]])){
    
    #print(unlist(master.area.vector.count[[study]][[cell_line]]))
    
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['4_way']]])
    #print(unlist(master.area.vector.count[[study]][[cell_line]])[idx.N_way[['5_way']]])
    #print(sum(master.area.vector.percentage[[study]][[cell_line]]))
    area.vector <- area.vector + unlist(master.area.vector.percentage[[study]][[cell_line]][['3-way']])
  }
}
area.vector <- area.vector / num_studies
area.vector <- round(area.vector, 2)

venn.plot <- draw.triple.venn(category = c("Horlbeck", "MAGECK", "GEMINI"),
                              fill = c("green", "blue", "pink"),
                              lty = "dashed",
                              cex = 2,
                              cat.cex = 2,
                              cat.col = c("green", "blue", "pink"),
                              direct.area = TRUE,
                              area.vector = area.vector)

png(filename = file.path(save_dir, paste0(top_10p_choice, "_3_way_intersecting_average_percentage.png")), width = 1920, height = 1080)

grid.draw(venn.plot)
dev.off()





# for (way in idx.N_way_names){
#   idx.N_way[[paste0(way, '_percentage_avg')]] <- mean(area.vector[idx.N_way[[way]]])
# }
# 
# for (way in idx.N_way_names){
#   idx.N_way[[paste0(way, '_percentage_max')]] <- max(area.vector[idx.N_way[[way]]])
#   
#   names(idx.N_way[[paste0(way, '_percentage_max')]]) <- ordered_names_5_way[[idx.N_way[[way]][[which(area.vector[idx.N_way[[way]]] == idx.N_way[[paste0(way, '_percentage_max')]])]]]]
#   
# }

save.image(file = save_Rdata_name)
