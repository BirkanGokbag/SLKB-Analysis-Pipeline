source("global.R")
source("ui.R")
source("server.R")

# install.packages(c('shiny', 'dplyr', 'ggplot2'), repos='https://cran.rstudio.com/')
# iinstall.packages('https://cran.r-project.org/src/contrib/Archive/nVennR/nVennR_0.2.3.tar.gz', repos = NULL, method='curl')
# iinstall.packages(c('visNetwork', 'igraph', 'DT', 'shinyWidgets', 'ggVennDiagram'), repos='https://cran.rstudio.com/')
# iinstall.packages(c('readxl', 'shinythemes', 'Venndiagram', 'dbplyr', 'stringr', 'DBI', 'pool', 'RMySQL', 'RSQLite'), repos='https://cran.rstudio.com/')

app <- shiny::shinyApp(ui = ui, server = server)