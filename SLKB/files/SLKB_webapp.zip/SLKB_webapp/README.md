# SLKB

# Getting Started

Install specificed packages outlined in app.R

Please update server.R with the newly created database connection.