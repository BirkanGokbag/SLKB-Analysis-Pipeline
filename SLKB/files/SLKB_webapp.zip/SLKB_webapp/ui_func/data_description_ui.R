data_description.UI <- function(id){
  ns <- NS(id)
  
  tabPanel("Available Studies",
           
           # display statistics of the entire available SL data
           DT::dataTableOutput(ns("datatable"))
  )
}