overview.UI <- function(id){
  ns <- NS(id)
  
  tabPanel("Project Description",
           fluidRow(
             column(width = 12,
                    mainPanel(
                       h1("Introduction to SLKB", style = "font-size:300%"),
                       h2("Project Description", style = "font-size:200%"),
                       p('Synthetic lethality knowledge base (SLKB) is dedicated to curating CRISPR dual knockdown/out experiments (CDKO)
                         aiming to identify synthetic lethal (SL) interactions between two genes. SL identification is highly context dependent, and may different across pathways, gene targets, cell lines, and CDKO libraries. SLKB pipeline and generalized CDKO SL experiment design are illustrated below.'
                         , style = "font-size:125%"),
                       h2("Synthetic Lethality Scoring Methods", style = "font-size:200%"),
                       p('SLKB employs 5 main scoring methods for the deposited studies to assess the impact of scoring on SL pair identification. The current available methods are: Horlbeck Score, GEMINI Score, MAGeCK Score, Median Background/No Background Score, sgRNA Derived Background/No Background Score.'
                         , style = "font-size:125%"),
                       h2("SLKB Data Browsing and Querying", style = "font-size:200%"),
                       p('In SLKB, SL pairs can be browsed across all settings, mainly via tabular data browsing, KB query, SL network visualization, and Venn diagram comparison.'
                         , style = "font-size:125%"),
                       h2("SLKB Analysis Pipeline and Web Application For Browsing", style = "font-size:200%"),
                       p('In addition, SLKB\'s analysis pipeline and web app are available on GitHub, via the downloads page. Users may utilize the pipelines to analyze their own CDKO data, come up with their own scoring methods, and view the full results within the web app.'
                         , style = "font-size:125%")
                    )
             ),
           ),
           fluidRow(
             column(width = 6,align = 'center',
                    uiOutput(ns("fig1"), inline  = F),
             ),
             column(width = 6,align = 'center',
                    uiOutput(ns("fig2"), inline  = F),
             ),
           ),
           )

  #)
  
}