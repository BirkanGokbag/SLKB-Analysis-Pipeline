source("global.R")
source("ui.R")
source("server.R")

# install.packages(c('shiny', 'shinyjs','shinydashboard', 'dplyr', 'ggplot2'), repos='https://cran.rstudio.com/')
# install.packages('https://cran.r-project.org/src/contrib/Archive/nVennR/nVennR_0.2.3.tar.gz', repos = NULL, method='curl')
# install.packages(c('visNetwork', 'igraph', 'DT', 'shinyWidgets', 'ggVennDiagram'), repos='https://cran.rstudio.com/')
# install.packages(c('readxl', 'shinythemes', 'Venndiagram', 'dbplyr', 'stringr', 'DBI', 'pool', 'RMySQL', 'RSQLite'), repos='https://cran.rstudio.com/')

app <- shiny::shinyApp(ui = ui, server = server)