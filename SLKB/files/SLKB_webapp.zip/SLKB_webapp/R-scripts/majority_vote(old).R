library(xlsx)
library(visNetwork)
#rm(list=ls())
#gc()


# read data
#curr_subset <- read.csv(file = '22Rv1_ST.csv')
#curr_subset <- read.csv(file = 'temp.csv')
#ref <- read.csv(file = '22Rv1_ST.csv')

sum(temp2$`Total Count` > 1)

# set top percent to get, or top X number of pairs
top_p_choice <- '3percent'
if (grepl('percent', top_p_choice, fixed = TRUE)){
  top_p <- as.numeric(gsub('percent', '', top_p_choice, fixed = TRUE))
  top_p <- round(dim(curr_subset)[1] * top_p / 100)
} else {
  top_p <- as.numeric(top_p_choice)
}

print(paste('Desired to number of gene pairs from each approach:', top_p))


# choose scoring strategies to consider
#scoring_strategies <- c('Horlbeck.Original', 'Median.NB', 'Median.NB.Z', 'Median.B', 'Median.B.Z', 'sgRNA.Derived.NB.Z', 'sgRNA.Derived.B.Z', 'MAGECK', 'MAGECK.Z', 'GEMINI')
scoring_strategies <- c("HORLBECK_SCORE_SL_score", "MEDIAN_B_SCORE_SL_score", 
                        "MEDIAN_B_SCORE_Z_SL_score","MEDIAN_NB_SCORE_SL_score", "MEDIAN_NB_SCORE_Z_SL_score", "GEMINI_SCORE_SL_score_Strong",   
                        "MAGECK_SCORE_SL_score","MAGECK_SCORE_Z_SL_score",  "SGRA_DERIVED_B_SCORE_SL_score", "SGRA_DERIVED_NB_SCORE_SL_score")
# store results for majority votes in list
majority_votes_genes <- list()
majority_votes_pairs <- list()

for (strategy in scoring_strategies){
  if (strategy == "GEMINI_SCORE_SL_score_Strong"){
    curr_subset <- curr_subset[order(curr_subset[[strategy]], decreasing = T), ]
  } else {
    curr_subset <- curr_subset[order(curr_subset[[strategy]], decreasing = F), ]
  }
  
  
  voted_pairs <- curr_subset$gene_pair[1:top_p]#curr_subset$Gene.Pair[1:top_p]
  voted_genes <- c(curr_subset$gene_1[1:top_p], curr_subset$gene_2[1:top_p])# c(curr_subset$Gene_A[1:top_p], curr_subset$Gene_B[1:top_p])
  
  majority_votes_genes[[strategy]] <- voted_genes
  majority_votes_pairs[[strategy]] <- voted_pairs
}

# union the majority votes
voted_genes <-  unlist(majority_votes_genes, recursive = FALSE)
voted_genes <- sort(table(voted_genes), decreasing = T)

voted_pairs <- unlist(majority_votes_pairs, recursive = FALSE)
voted_pairs <- sort(table(voted_pairs), decreasing = T)

# get overlapping info for context
overlapping_genes <- sort(voted_genes[Reduce(intersect, majority_votes_genes)], decreasing = T)
overlapping_pairs <- sort(voted_pairs[Reduce(intersect, majority_votes_pairs)], decreasing = T)

# annotation for each SL gene/pair
participation_table_genes <- matrix(0, nrow = length(voted_genes), ncol = length(scoring_strategies), dimnames = list(names(voted_genes), scoring_strategies))
participation_table_pairs <- matrix(0, nrow = length(voted_pairs), ncol = length(scoring_strategies), dimnames = list(names(voted_pairs), scoring_strategies))

for (item in rownames(participation_table_genes)){
  for (strategy in colnames(participation_table_genes)){
    if (item %in% majority_votes_genes[[strategy]]){
      participation_table_genes[item, strategy] <- sum(majority_votes_genes[[strategy]] %in% item)
    }
  }
}

for (item in rownames(participation_table_pairs)){
  for (strategy in colnames(participation_table_pairs)){
    if (item %in% majority_votes_pairs[[strategy]]){
      participation_table_pairs[item, strategy] <- 1
    }
  }
}

# output results
output_results <- list()

output_results[['Voted Genes']] <- cbind(voted_genes, participation_table_genes)
output_results[['Voted Pairs']] <- cbind(voted_pairs, participation_table_pairs)
output_results[['Overlapping Genes']] <- cbind(overlapping_genes, participation_table_genes[names(overlapping_genes),])
output_results[['Overlapping Pairs']] <- cbind(overlapping_pairs, participation_table_pairs[names(overlapping_pairs),])

for (sheet in names(output_results)){
  colnames(output_results[[sheet]])[1] <- 'Total Count'
  write.xlsx(output_results[[sheet]], file=paste0(top_p_choice, '_', 'TEMP_majority_results.xlsx'), sheetName = sheet, append=T)
}
