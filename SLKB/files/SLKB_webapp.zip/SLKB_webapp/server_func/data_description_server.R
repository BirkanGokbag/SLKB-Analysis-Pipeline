dataDescriptionServer <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
      
      ns <- session$ns
      
      output$datatable <- DT::renderDataTable(data_annotations_orig, 
                                              extensions = "Buttons",
                                              server = TRUE,
                                              options = list(scrollY = T,
                                                             pageLength = 20,
                                                             buttons = c('copy', 'csv', 'excel','pdf'),
                                                             paging = F
                                                             #columnDefs = list(list(visible=FALSE, targets=c(3, 5, 7, 9)))
                                              ))
      
      
    }
  )
}