library(openxlsx)
library(visNetwork)
library(dplyr)
library(nVennR)
library(VennDiagram)
library(igraph)
library(ggplot2)
library(ggVennDiagram)
library(stringr)
library(ggvenn)
library(KEGGREST)
library(dplyr)

# KEGG_genes <- c()
# for (row in seq(dim(KEGG_db)[1])){
#   if (row == 1){
#     next
#   }
#   split <- strsplit(KEGG_db[row, ], split = '(RefSeq)', fixed = T)[[1]]
#   curr_genes <- split[[2]]
#   curr_genes <- gsub(" ", "", curr_genes)
#   curr_genes <- gsub(",", "&", curr_genes)
#   curr_genes <- gsub(";", "&", curr_genes)
#   curr_genes <- strsplit(curr_genes, split = '&', fixed = T)[[1]]
#   KEGG_genes <- c(KEGG_genes, curr_genes)
# }
# KEGG_genes <- unique(KEGG_genes)

getwd()
temp <- read.csv(file = file.path(getwd(), '..', 'www', 'original_GI_110422.csv'))
temp <- temp[temp$Gene_A != temp$Gene_B,]

data.sig <- temp[temp$Study_Source =='Zhao',]
data.sig[(data.sig$Stat_Score < data.sig$Stat_Cutoff) & (data.sig$GI_Score < data.sig$GI_Cutoff) & (data.sig$GI_Score != 0), ]



rm(list=ls())
gc()

folder_loc <- file.path('Gene_Selection')

# annotation file
#cell_death <- openxlsx::read.xlsx(xlsxFile = 'DKO_22RV1_target_LJ.xlsx', sheet = 'Annotation_CD_pathway')
cell_death <- read.csv(file = file.path(folder_loc, 'XDeath_Key_Genes.csv'))
table(cell_death$keyword)
#unique(cell_death$Pathways_Genes)

# create a variable for target annotations
annotations <- data.frame('annotation' = cell_death$keyword,
                          'genes' = cell_death$symbol)

#annotations$joined <- paste0(annotations$annotation, '_', annotations$genes)

annotations <- annotations %>% distinct(annotation, genes)


pathway_list <- list()
for (pathway in unique(annotations$annotation)){
  pathway_list[[pathway]] <- annotations[annotations$annotation == pathway, 'genes']
}


# read the original scores
study_scores <- read.csv(file = '22Rv1_ST.csv')

# read previously calculated data
results <- openxlsx::read.xlsx(xlsxFile = '3percent_majority_results.xlsx', sheet = 'Voted Pairs')

results <- results[results$Total.Count > 1,]
results$Gene.Pair <- results$X1

results$Gene_A <- sapply(strsplit(results$Gene.Pair, '_', fixed = TRUE), `[`, 1)
results$Gene_B <- sapply(strsplit(results$Gene.Pair, '_', fixed = TRUE), `[`, 2)

########################################

# get the KEGG genes
KEGG_genes <- keggGet("hsa04210")[[1]]$GENE
KEGG_genes <-  KEGG_genes[seq(0,length(KEGG_genes),2)]
KEGG_genes <- unique(gsub("\\;.*","",KEGG_genes))

pathway_list[['Apoptosis']] <- KEGG_genes

#unique(c(pathway_list[['Apoptosis']], KEGG_genes))

########################################

# get all genes

length(pathway_list[['Apoptosis']])
length(pathway_list[['Autosis']])
length(pathway_list[['Mitotic_CD']])

all_genes <- sort(unique(c(pathway_list[['Apoptosis']], pathway_list[['Autosis']], pathway_list[['Mitotic_CD']])))

length(all_genes)
# create the table

num_possible_gene_pairs <- ((length(all_genes) ** 2) - length(all_genes))/2

# create gene pairs
gene_pairs <- c()
gene_A <- c()
gene_B <- c()
# 
# 
# for (gene_1_idx in seq_along(all_genes)){
#   gene_1 <- all_genes[gene_1_idx]
#   for (gene_2_idx in seq_along(all_genes)){
#     gene_2 <- all_genes[gene_2_idx]
#     
#     sorted <- sort(c(gene_1, gene_2))
#     gene_1 <- sorted[1]
#     gene_2 <- sorted[2]
# 
# #
# #
#     insertion <- paste0(gene_1, '_', gene_2)
# #
# #     #if (gene_1 != 'ACTB'){
# #       #print(paste0(gene_1, '_', gene_2))
# #      print(insertion)
# #     #}
# #
# #     if (!(insertion %in% gene_pairs)){
#     gene_pairs <- c(gene_pairs, insertion)
#     gene_A <- c(gene_A, gene_1)
#     gene_B <- c(gene_B, gene_2)
# 
#   }
# 
# }
# 
for (gene in all_genes){
  #curr_insertion <-  paste0(gene, '_', all_genes)
  #gene_pairs <- c(gene_pairs, paste0(gene, '_', all_genes))
  gene_A <- c(gene_A, rep(gene, length(all_genes)))
  gene_B <- c(gene_B, all_genes)
}

for (i in seq_along(gene_A)){
  sorted <- sort(c(gene_A[i], gene_B[i]))
  gene_1 <- sorted[1]
  gene_2 <- sorted[2]
  insertion <- paste0(gene_1, '_', gene_2)
  gene_pairs <- c(gene_pairs, insertion)

}




gene_selection_table <- matrix(nrow = length(gene_pairs), ncol = 19)
rownames(gene_selection_table) <- gene_pairs
colnames(gene_selection_table) <- c('Gene_A', 'Gene_B', 'Gene_Pair', 
                                    'Gene_A_Apoptosis?', 'Gene_A_Autosis?', 'Gene_A_Mitotic_CD?', 'Gene_A_Num_Pathways', 
                                    'Gene_B_Apoptosis?', 'Gene_B_Autosis?', 'Gene_B_Mitotic_CD?', 'Gene_B_Num_Pathways', 
                                    'Any Crosstalk?', 'Within 22Rv1 Data (1225 pairs)?', 'Within Top3% (88) Gene Pairs?',
                                    'Gene 1 SL Connectivity', 'Gene 2 SL Connectivity', 'SL Prediction Score', 'SL Pair Selection Criteria', 'SL Pair Selection Type')
gene_selection_table <- as.data.frame(gene_selection_table)

# add the rows
gene_selection_table$Gene_A <- gene_A
gene_selection_table$Gene_B <- gene_B
gene_selection_table$Gene_Pair <- gene_pairs

# distinct
gene_selection_table <- gene_selection_table[!duplicated(gene_selection_table$Gene_Pair), ]

# remove the same pairs
gene_selection_table <- gene_selection_table[!(gene_selection_table$Gene_A == gene_selection_table$Gene_B), ]

# add the annotations
for (gene_loc in c('A', 'B')){
  for (gene_set in c('Apoptosis', 'Autosis', 'Mitotic_CD')){
    curr_column <- paste0('Gene_', gene_loc, '_', gene_set, '?')
    gene_selection_table[[curr_column]] <- gene_selection_table[[paste0('Gene_', gene_loc)]] %in% pathway_list[[gene_set]]
  }
}

# curr_column <- paste0('Gene_', gene_loc, '_Num_Pathways')
# 
# gene_selection_table[[curr_column]] <- rowSums(gene_selection_table[, c('Gene_A_Apoptosis?', 'Gene_A_Autosis?', 'Gene_A_Mitotic_CD?')])
# $Gene_A_Num_Pathways

gene_selection_table$Gene_A_Num_Pathways <- rowSums(gene_selection_table[, c('Gene_A_Apoptosis?', 'Gene_A_Autosis?', 'Gene_A_Mitotic_CD?')])
gene_selection_table$Gene_B_Num_Pathways <- rowSums(gene_selection_table[, c('Gene_B_Apoptosis?', 'Gene_B_Autosis?', 'Gene_B_Mitotic_CD?')])

all_crosstalk <- rep(T, dim(gene_selection_table)[1])

# crosstalk is not the case when both genes have 1 annotation and they are the same
idx <- (gene_selection_table$Gene_A_Num_Pathways == 1) & (gene_selection_table$Gene_B_Num_Pathways == 1)
# preemptively set them to be false
all_crosstalk[idx] <- F

matches <- gene_selection_table[, c('Gene_A_Apoptosis?', 'Gene_A_Autosis?', 'Gene_A_Mitotic_CD?')] == gene_selection_table[, c('Gene_B_Apoptosis?', 'Gene_B_Autosis?', 'Gene_B_Mitotic_CD?')]
matches <- rowSums(matches)

# for the idx that only have 1 annotation, if they do not completely match then they are in different pathways
all_crosstalk[(idx & (matches != 3))] <- T

# 
# gene_selection_table[1, c('Gene_A_Apoptosis?', 'Gene_A_Autosis?', 'Gene_A_Mitotic_CD?')]
# gene_selection_table[1, c('Gene_B_Apoptosis?', 'Gene_B_Autosis?', 'Gene_B_Mitotic_CD?')]
# 
# # check for crosstalk
# apoptosis_crosstalk <- xor(gene_selection_table[idx, c('Gene_A_Apoptosis?')], gene_selection_table[idx, c('Gene_B_Apoptosis?')])
# autosis_crosstalk <- xor(gene_selection_table[idx, c('Gene_A_Autosis?')], gene_selection_table[idx, c('Gene_B_Autosis?')])
# mitoticcd_crosstalk <- xor(gene_selection_table[idx, c('Gene_A_Mitotic_CD?')], gene_selection_table[idx, c('Gene_B_Mitotic_CD?')])
# 
# all_crosstalk <- apoptosis_crosstalk | autosis_crosstalk | mitoticcd_crosstalk
# 
# # if they are in all of them too, count that as well
# pathway_sum <- rowSums(gene_selection_table[, c('Gene_A_Apoptosis?', 'Gene_A_Autosis?', 'Gene_A_Mitotic_CD?',
#                                                 'Gene_B_Apoptosis?', 'Gene_B_Autosis?', 'Gene_B_Mitotic_CD?')])
# 
# pathway_sum <- pathway_sum == 6
# 
# all_crosstalk <- all_crosstalk | pathway_sum 
  
gene_selection_table[['Any Crosstalk?']] <- all_crosstalk

# add the record as to whether they are available in the original data, and the top pairs
gene_selection_table[['Within Top3% (88) Gene Pairs?']] <- gene_selection_table$Gene_Pair %in% results$Gene.Pair
gene_selection_table[['Within 22Rv1 Data (1225 pairs)?']] <- gene_selection_table$Gene_Pair %in% study_scores$Gene.Pair


sum(gene_selection_table[['Within Top3% (88) Gene Pairs?']])
sum(gene_selection_table[['Within 22Rv1 Data (1225 pairs)?']])

gene_selection_table[gene_selection_table[['Within 22Rv1 Data (1225 pairs)?']] == T,]
sum(gene_selection_table[['Gene_A_Num_Pathways']])
sum(gene_selection_table[['Gene_B_Num_Pathways']])

# load Predictions
pair_prediction <- read.csv(file = file.path(folder_loc, 'pair_prediction_V2.csv'))

connectivity_prediction <- read.csv(file = file.path(folder_loc, 'connectivity_prediction_V2.csv'))

setdiff(all_genes, unique(connectivity_prediction$gene))

for (i in seq(dim(connectivity_prediction)[1])){
  gene <- connectivity_prediction$gene[i]
  connectivity <- connectivity_prediction$pred_connectivity[i]
  gene_selection_table[gene_selection_table$Gene_A == gene, "Gene 1 SL Connectivity"] <- connectivity
  gene_selection_table[gene_selection_table$Gene_B == gene, "Gene 2 SL Connectivity"] <- connectivity
}

sorted_pairs <- c()
temp <- pair_prediction[pair_prediction$gene1 == 'ACTB' | pair_prediction$gene2 == 'ACTB',]
for (i in seq(dim(pair_prediction)[1])){
  gene_A <- pair_prediction$gene1[i]
  gene_B <- pair_prediction$gene2[i]
  
  gene_pair <- paste(sort(c(gene_A, gene_B)), collapse = '_')
  sorted_pairs <- c(sorted_pairs, gene_pair)
  prediction <- pair_prediction$pred_score[i]
  gene_selection_table[gene_selection_table$Gene_Pair == gene_pair, "SL Prediction Score"] <- prediction
}

sum(is.na(gene_selection_table[['Gene 1 SL Connectivity']]))
sum(is.na(gene_selection_table[['Gene 2 SL Connectivity']]))
sum(is.na(gene_selection_table[['SL Prediction Score']]))

# order 
gene_selection_table <- gene_selection_table[order(gene_selection_table[['SL Prediction Score']], decreasing = T),]

# use the rank of the prediction scores for the actual score
gene_selection_table[['SL Prediction Score']] <- (dim(gene_selection_table)[1]:1)/dim(gene_selection_table)[1]

######## filter out genes that are not available for a sequence

filter_genes <- c("CDC26P1","CDC27P5","CDC27P6") 
idx <- (gene_selection_table$Gene_A %in% filter_genes) | (gene_selection_table$Gene_B %in% filter_genes)
print(paste('Filtering :', paste0(filter_genes, collapse = ';')))
print(paste('Num sgRNAs filtered:', sum(idx)))
gene_selection_table <- gene_selection_table[!idx,]

for (ann in c('Apoptosis', 'Autosis', 'Mitotic_CD')){
  print(paste('Checking for removed', ann, ':', sum(pathway_list[[ann]] %in% filter_genes)))
}
######## proceed with SL pair selection

# before anything, get HUB genes
connectivity_prediction <- connectivity_prediction[order(connectivity_prediction$pred_connectivity, decreasing = T),]
hub_genes <- connectivity_prediction$gene[1:5]

gene_selection_table[['SL Pair Selection Criteria']] <- 'None'
gene_selection_table[['SL Pair Selection Type']] <- 'None'

###### biology gene selection

selections <- list(c('Apoptosis', 'Apoptosis', 300),
              c('Apoptosis', 'Autosis', 20),
              c('Apoptosis', 'Mitotic_CD', 80),
              c('Autosis', 'Mitotic_CD', -1),
              c('Autosis', 'Autosis', -1),
              c('Mitotic_CD', 'Mitotic_CD', 50))


curr_selection <- selections[[1]]
for (curr_selection in selections){
  pathway_1 <- curr_selection[1]
  pathway_2 <- curr_selection[2]
  top_to_get <- as.numeric(curr_selection[3])
  print(paste('Currently working on', pathway_1, 'and', pathway_2, 'with top', top_to_get))
  idx <- gene_selection_table[[paste0('Gene_A_', pathway_1, '?')]] & gene_selection_table[[paste0('Gene_B_', pathway_2, '?')]] | (gene_selection_table[[paste0('Gene_A_', pathway_2, '?')]] & gene_selection_table[[paste0('Gene_B_', pathway_1, '?')]])
  print(paste('Found possible:', sum(idx)))
  
  selection <- gene_selection_table[idx, 'Gene_Pair']
  if (top_to_get != -1){
    print(paste('Getting top', top_to_get))
    selection <- selection[1:top_to_get]
  } else {
    print('Took all selection')
  }
  
  if ((table(gene_selection_table[selection, 'SL Pair Selection Criteria'])['None'] != length(selection)) | (length(selection) != top_to_get)){
    print('!!!!!Error!!!!!')
  }
  
  gene_selection_table[selection, 'SL Pair Selection Criteria'] <- 'Biology'
  gene_selection_table[selection, 'SL Pair Selection Type'] <- paste(sort(c(pathway_1, pathway_2)), collapse = '/')
  
  print('---------')
}

# Remove the selected pairs, then get the middle ones
not_selected <- gene_selection_table[gene_selection_table[['SL Pair Selection Criteria']] == 'None',]

middle_selections <- list(c('Apoptosis', 'Apoptosis', 300),
                   c('Apoptosis', 'Autosis', 20),
                   c('Apoptosis', 'Mitotic_CD', 80),
                   c('Mitotic_CD', 'Mitotic_CD', 50))

# temp <- 1:1000
# middle_idx <- length(temp)/2
# top_to_get <- 4
# temp[((middle_idx - top_to_get/2)+1):(middle_idx + top_to_get/2)]

for (curr_selection in middle_selections){
  pathway_1 <- curr_selection[1]
  pathway_2 <- curr_selection[2]
  top_to_get <- as.numeric(curr_selection[3])
  print(paste('Currently working on', pathway_1, 'and', pathway_2, 'with middle', top_to_get))
  idx <- not_selected[[paste0('Gene_A_', pathway_1, '?')]] & not_selected[[paste0('Gene_B_', pathway_2, '?')]] | (not_selected[[paste0('Gene_A_', pathway_2, '?')]] & not_selected[[paste0('Gene_B_', pathway_1, '?')]])
  print(paste('Found possible:', sum(idx)))
  
  middle_idx <- sum(idx)/2
  
  selection <- not_selected[idx, 'Gene_Pair']
  print(paste('Getting middle', top_to_get))
  selection <- selection[((middle_idx - top_to_get/2)+1):(middle_idx + top_to_get/2)]

  if ((table(not_selected[selection, 'SL Pair Selection Criteria'])['None'] != length(selection)) | (length(selection) != top_to_get)){
    print(table(not_selected[selection, 'SL Pair Selection Criteria']))
    print('Error')
  }
    
  
  not_selected[selection, 'SL Pair Selection Criteria'] <- 'Active Learning'
  not_selected[selection, 'SL Pair Selection Type'] <- paste(sort(c(pathway_1, pathway_2)), collapse = '/')
  
  print('---------')
}

# place it back
gene_selection_table[gene_selection_table[['SL Pair Selection Criteria']] == 'None',] <- not_selected

# now, get the none selected once more for hub SL interactions
not_selected <- gene_selection_table[gene_selection_table[['SL Pair Selection Criteria']] == 'None',]

idx <- (not_selected$Gene_A %in% hub_genes) | (not_selected$Gene_B %in% hub_genes) 

# get the top 50 hub gene interactions from the non-chosen ones
print(paste('Found possible:', sum(idx)))

selection <- not_selected[idx, 'Gene_Pair'][1:50]
not_selected[selection, 'SL Pair Selection Criteria'] <- 'Hub Genes'
not_selected[selection, 'SL Pair Selection Type'] <- 'Hub Genes'

# place it back
gene_selection_table[gene_selection_table[['SL Pair Selection Criteria']] == 'None',] <- not_selected

gene_selection_table[['SL Pair Selection Criteria+Type']] <- paste0(gene_selection_table[['SL Pair Selection Criteria']], '_', gene_selection_table[['SL Pair Selection Type']])

table(gene_selection_table[['SL Pair Selection Criteria']])
table(gene_selection_table[['SL Pair Selection Type']])
table(gene_selection_table[['SL Pair Selection Criteria+Type']] )

gene_selection_table <- gene_selection_table %>% mutate_all(as.character)

gene_selection_table[which(gene_selection_table == 'TRUE', arr.ind = T)] <- 'Yes'
gene_selection_table[which(gene_selection_table == 'FALSE', arr.ind = T)] <- 'No'

table(gene_selection_table$`Within Top3% (88) Gene Pairs?`)
table(gene_selection_table$`Within 22Rv1 Data (1225 pairs)?`)
table(gene_selection_table$`SL Pair Selection Criteria`)
table(gene_selection_table$`SL Pair Selection Type`)
table(gene_selection_table$`SL Pair Selection Criteria+Type`)

sum(is.na(gene_selection_table))

results_xlsx <- list()
results_xlsx[['All_Pairs']] <- gene_selection_table
results_xlsx[['Selected_Pairs']] <- gene_selection_table[gene_selection_table[['SL Pair Selection Criteria']] != 'None',]

for (sheet in names(results_xlsx)){
  xlsx::write.xlsx(results_xlsx[[sheet]], file= file.path(folder_loc, 'gene_selection_012722_filtered3genes.xlsx'), sheetName = sheet, append=T, row.names = F)
}

#write.csv(gene_selection_table, file = file.path(folder_loc, 'gene_selection_V2.xlsx'), row.names = F)


table(gene_selection_table[['SL Pair Selection Criteria']])
temp <-results_xlsx[['Selected_Pairs']]

temp <- c(temp$Gene_A, temp$Gene_B)
sort(table(temp), decreasing = T)
length(sort(table(temp), decreasing = T))


##### library generation

gene_selection_table <- openxlsx::read.xlsx(file.path('Gene_Selection', 'gene_selection_012722_filtered3genes.xlsx'), sheet = 'Selected_Pairs')
barcodes_table <- openxlsx::read.xlsx(file.path('Gene_Selection', '20230128 Selected gRNA 151 target genes.xlsx'), sheet = 'Sheet1')

all_pairs <- sort(unique(c(gene_selection_table$Gene_A, gene_selection_table$Gene_B)))
barcodes_table$Guide <- barcodes_table$Gene
barcode_locs <- 1:dim(barcodes_table)[1]

# evens and odds
barcodes_table$Guide[(barcode_locs %% 2) == 1] <- paste0(barcodes_table$Gene[(barcode_locs %% 2) == 1], '_guide1')
barcodes_table$Guide[(barcode_locs %% 2) == 0] <- paste0(barcodes_table$Gene[(barcode_locs %% 2) == 0] , '_guide2')

# read the controls
chosen_controls <- read.csv(file.path('Gene_Selection', '22Rv1_control_impact.csv'))
chosen_controls <- chosen_controls[chosen_controls$Passes.Threshold == 'True', 'sgRNA_guide_name_g1']

all_controls <- read.csv(file.path('Gene_Selection', '22Rv1_all_controls.csv'))
all_controls <- all_controls[all_controls$sgRNA_guide_name %in% chosen_controls, ]

all_controls <- all_controls[, c('sgRNA_target_name', 'sgRNA_guide_seq', 'sgRNA_guide_name')]
colnames(all_controls) <- colnames(barcodes_table)

# store here
guides_A <- c()
guides_B <- c()
genes_A <- c()
genes_B <- c()
guides_sorted <- c()
guide_pair <- c()
gene_pair_sorted <- c()
target_type <- c()

# First, the single targets including controls
set.seed(42)

curr_gene_guides <- barcodes_table$Guide
curr_gene_targets <- barcodes_table$Gene
curr_controls <- sample(all_controls$Guide)
control_repeat <- c(rep(curr_controls, 30), curr_controls[5:6])
#curr_idx <- 1:length(control_repeat)#sample(1:length(control_repeat))
#control_repeat_sampled <- control_repeat[curr_idx]

guides_A <- c(guides_A, curr_gene_guides)
guides_B <- c(guides_B, control_repeat)
genes_A <- c(genes_A, curr_gene_targets)
genes_B <- c(genes_B, rep('CONTROL', length(curr_gene_guides)))
#guides_sorted <- c()
guide_pair <- c(guide_pair, paste0(curr_gene_guides, '|', control_repeat))
#gene_pair_sorted <- c()
target_type <- c(target_type, rep('Single', length(curr_gene_guides)))

# repeat
guides_B <- c(guides_B, curr_gene_guides)
guides_A <- c(guides_A, control_repeat)
genes_B <- c(genes_B, curr_gene_targets)
genes_A <- c(genes_A, rep('CONTROL',  length(curr_gene_guides)))
#guides_sorted <- c()
guide_pair <- c(guide_pair, paste0(control_repeat, '|', curr_gene_guides))
#gene_pair_sorted <- c()
target_type <- c(target_type, rep('Single', length(curr_gene_guides)))

# reverse
control_repeat <- rev(control_repeat)

guides_A <- c(guides_A, curr_gene_guides)
guides_B <- c(guides_B, control_repeat)
genes_A <- c(genes_A, curr_gene_targets)
genes_B <- c(genes_B, rep('CONTROL', length(curr_gene_guides)))
#guides_sorted <- c()
guide_pair <- c(guide_pair, paste0(curr_gene_guides, '|', control_repeat))
#gene_pair_sorted <- c()
target_type <- c(target_type, rep('Single', length(curr_gene_guides)))

# repeat
guides_B <- c(guides_B, curr_gene_guides)
guides_A <- c(guides_A, control_repeat)
genes_B <- c(genes_B, curr_gene_targets)
genes_A <- c(genes_A, rep('CONTROL', length(curr_gene_guides)))
#guides_sorted <- c()
guide_pair <- c(guide_pair, paste0(control_repeat, '|', curr_gene_guides))
#gene_pair_sorted <- c()
target_type <- c(target_type, rep('Single', length(curr_gene_guides)))


# 
# 
# repetition_size <- 90
# repetition_num <- floor(length(barcodes_table$Guide)/repetition_size)
# control_repeat <- rep(all_controls$Guide, repetition_size/length(all_controls$Guide))
# 
# for (i in seq(repetition_num)){
#   curr_idx <- ((repetition_size * (i - 1)) + 1): (repetition_size * i)
# 
#   # at position A
#   sample_idx <- sample(1:repetition_size)
#   curr_gene_guides <- barcodes_table$Guide[curr_idx][sample_idx]
#   curr_gene_targets <- barcodes_table$Gene[curr_idx][sample_idx]
# 
#   guides_A <- c(guides_A, curr_gene_guides)
#   guides_B <- c(guides_B, control_repeat)
#   genes_A <- c(genes_A, curr_gene_targets)
#   genes_B <- c(genes_B, rep('CONTROL', repetition_size))
#   #guides_sorted <- c()
#   guide_pair <- c(guide_pair, paste0(curr_gene_guides, '|', control_repeat))
#   #gene_pair_sorted <- c()
#   target_type <- c(target_type, rep('Single', repetition_size))
# 
#   # repeat
#   guides_B <- c(guides_B, curr_gene_guides)
#   guides_A <- c(guides_A, control_repeat)
#   genes_B <- c(genes_B, curr_gene_targets)
#   genes_A <- c(genes_A, rep('CONTROL', repetition_size))
#   #guides_sorted <- c()
#   guide_pair <- c(guide_pair, paste0(control_repeat, '|', curr_gene_guides))
#   #gene_pair_sorted <- c()
#   target_type <- c(target_type, rep('Single', repetition_size))
# 
#   # at position B
#   sample_idx <- sample(1:repetition_size)
#   curr_gene_guides <- barcodes_table$Guide[curr_idx][sample_idx]
#   curr_gene_targets <- barcodes_table$Gene[curr_idx][sample_idx]
# 
#   guides_A <- c(guides_A, control_repeat)
#   guides_B <- c(guides_B, curr_gene_guides)
#   genes_A <- c(genes_A, rep('CONTROL', repetition_size))
#   genes_B <- c(genes_B, curr_gene_targets)
#   #guides_sorted <- c()
#   guide_pair <- c(guide_pair, paste0(control_repeat, '|',curr_gene_guides))
#   #gene_pair_sorted <- c()
#   target_type <- c(target_type, rep('Single', repetition_size))
# 
#   # repeat
#   guides_B <- c(guides_B, control_repeat)
#   guides_A <- c(guides_A, curr_gene_guides)
#   genes_B <- c(genes_B, rep('CONTROL', repetition_size))
#   genes_A <- c(genes_A, curr_gene_targets)
#   #guides_sorted <- c()
#   guide_pair <- c(guide_pair, paste0(curr_gene_guides, '|', control_repeat))
#   #gene_pair_sorted <- c()
#   target_type <- c(target_type, rep('Single', repetition_size))
# 
# }
# 
# curr_idx <- ((repetition_size * i) + 1):length(barcodes_table$Guide)
# # at position A
# sample_idx <- sample(1:length(curr_idx))
# curr_gene_guides <- barcodes_table$Guide[curr_idx][sample_idx]
# curr_gene_targets <- barcodes_table$Gene[curr_idx][sample_idx]
# 
# guides_A <- c(guides_A, curr_gene_guides)
# guides_B <- c(guides_B, control_repeat[1:length(curr_idx)])
# genes_A <- c(genes_A, curr_gene_targets)
# genes_B <- c(genes_B, rep('CONTROL', length(curr_idx)))
# #guides_sorted <- c()
# guide_pair <- c(guide_pair, paste0(curr_gene_guides, '|', control_repeat[1:length(curr_idx)]))
# #gene_pair_sorted <- c()
# target_type <- c(target_type, rep('Single', length(curr_idx)))
# 
# # repeat
# guides_B <- c(guides_B, curr_gene_guides)
# guides_A <- c(guides_A, control_repeat[1:length(curr_idx)])
# genes_B <- c(genes_B, curr_gene_targets)
# genes_A <- c(genes_A, rep('CONTROL', length(curr_idx)))
# #guides_sorted <- c()
# guide_pair <- c(guide_pair, paste0(control_repeat[1:length(curr_idx)], '|', curr_gene_guides))
# #gene_pair_sorted <- c()
# target_type <- c(target_type, rep('Single', length(curr_idx)))
# 
# # at position B, remaining
# sample_idx <- sample(1:length(curr_idx))
# curr_gene_guides <- barcodes_table$Guide[curr_idx][sample_idx]
# curr_gene_targets <- barcodes_table$Gene[curr_idx][sample_idx]
# 
# guides_A <- c(guides_A, control_repeat[1:length(curr_idx)])
# guides_B <- c(guides_B, curr_gene_guides)
# genes_A <- c(genes_A,  rep('CONTROL', length(curr_idx)))
# genes_B <- c(genes_B, curr_gene_targets)
# #guides_sorted <- c()
# guide_pair <- c(guide_pair, paste0(control_repeat[1:length(curr_idx)], '|', curr_gene_guides))
# #gene_pair_sorted <- c()
# target_type <- c(target_type, rep('Single', length(curr_idx)))
# 
# # repeat
# guides_B <- c(guides_B, control_repeat[1:length(curr_idx)])
# guides_A <- c(guides_A, curr_gene_guides)
# genes_B <- c(genes_B,  rep('CONTROL', length(curr_idx)))
# genes_A <- c(genes_A, curr_gene_targets)
# #guides_sorted <- c()
# guide_pair <- c(guide_pair, paste0(curr_gene_guides, '|', control_repeat[1:length(curr_idx)]))
# #gene_pair_sorted <- c()
# target_type <- c(target_type, rep('Single', length(curr_idx)))


# then, create the control targets (dual controls), yields 100

for (i in all_controls$Guide){
  for (j in all_controls$Guide){
    guides_A <- c(guides_A, i)
    guides_B <- c(guides_B, j )
    #guides_sorted <- c(guides_sorted, paste0(sort(c(i,j)), collapse = '_'))
    guide_pair <- c(guide_pair, paste0(c(i,j), collapse = '|'))
    
    gene_A <- 'CONTROL'
    gene_B <-'CONTROL'
    genes_A <- c(genes_A, gene_A)
    genes_B <- c(genes_B, gene_B)
    #gene_pair_sorted <- c(gene_pair_sorted, paste0(sort(c(gene_A,gene_B)), collapse = '_'))
    if (grepl('SAFE', i, fixed = T) & grepl('SAFE', j, fixed = T)){
      target_type <- c(target_type, 'Control')
    } else if  (grepl('SAFE', i, fixed = T) | grepl('SAFE', j, fixed = T) ){
      target_type <- c(target_type, 'Single')
    } else if (gene_A == gene_B){
      target_type <- c(target_type, 'Single (Same Gene)')
    } else {
      target_type <- c(target_type, 'Dual')
    }
  }
}

# Finally, create dual targets (two different gene targeting, this includes singles as well)

for (i in barcodes_table$Guide){
  for (j in barcodes_table$Guide){
    guides_A <- c(guides_A, i)
    guides_B <- c(guides_B, j )
    #guides_sorted <- c(guides_sorted, paste0(sort(c(i,j)), collapse = '_'))
    guide_pair <- c(guide_pair, paste0(c(i,j), collapse = '|'))
    
    gene_A <- strsplit(i, '_', fixed = T)[[1]][1]
    gene_B <- strsplit(j, '_', fixed = T)[[1]][1]
    genes_A <- c(genes_A, gene_A)
    genes_B <- c(genes_B, gene_B)
    #gene_pair_sorted <- c(gene_pair_sorted, paste0(sort(c(gene_A,gene_B)), collapse = '_'))
    if (grepl('SAFE', i, fixed = T) & grepl('SAFE', j, fixed = T)){
      target_type <- c(target_type, 'Control')
    } else if  (grepl('SAFE', i, fixed = T) | grepl('SAFE', j, fixed = T) ){
      target_type <- c(target_type, 'Single')
    } else if (gene_A == gene_B){
      target_type <- c(target_type, 'Single (Same Gene)')
    } else {
      target_type <- c(target_type, 'Dual')
    }
  }
}

# now, add a guide_sorted column and gene_sorted_column
guides_sorted <- c()
gene_pair_sorted <- c()
for (i in seq_along(genes_A)){
  gene_pair_sorted <- c(gene_pair_sorted, paste0(sort(c(genes_A[i],genes_B[i])), collapse = '_'))
  guides_sorted <- c(guides_sorted, paste0(sort(c(guides_A[i],guides_B[i])), collapse = '_'))
}

guide_design <- list()

guide_design[['1-library_sequences']] <- rbind(barcodes_table, all_controls)
rownames(guide_design[['1-library_sequences']]) <- 1:dim(guide_design[['1-library_sequences']])[1]

# seqs_A <- c()
# seqs_B <- c()
# for (i in seq_along(genes_A)){
#   gene_pair_sorted <- c(gene_pair_sorted, paste0(sort(c(genes_A[i],genes_B[i])), collapse = '_'))
#   guides_sorted <- c(guides_sorted, paste0(sort(c(guides_A[i],guides_B[i])), collapse = '_'))
# }
# 
# guides_A %in% guide_design[['library_sequences']]$Guide


guide_design[['2-complete_library']] <- data.frame(guide_A = guides_A,
                                                   guide_B = guides_B,
                                                   target_A = genes_A,
                                                   target_B = genes_B,
                                                   guide_pair_sorted = guides_sorted,
                                                   target_pair_sorted = gene_pair_sorted,
                                                   guide_pair= guide_pair,
                                                   target_type = target_type
)

temp <- dplyr::inner_join(guide_design[['2-complete_library']], guide_design[['1-library_sequences']], by = c('guide_A'='Guide'))
guide_design[['2-complete_library']]['seq_A'] <- temp$gRNA_seq
temp <- dplyr::inner_join(guide_design[['2-complete_library']], guide_design[['1-library_sequences']], by = c('guide_B'='Guide'))
guide_design[['2-complete_library']]['seq_B'] <- temp$gRNA_seq
rm(temp)

# comb_seq <- c()
# for (i in seq(dim(guide_design[['2-complete_library']])[1])){
#   comb_seq <- c(comb_seq, paste0(guide_design[['2-complete_library']][i, 'seq_A'], ';', guide_design[['2-complete_library']][i, 'seq_B']))
# }
# 
# length()
# 
# guide_design[['2-complete_library']]['seq_A'] + ';'

guide_design[['2-complete_library']]['seq_joined'] <- paste0(guide_design[['2-complete_library']]$seq_A, ';', guide_design[['2-complete_library']]$seq_B)

# move around the columns 
guide_design[['2-complete_library']] <- guide_design[['2-complete_library']][c("guide_A", "target_A", "seq_A", "guide_B", "target_B", "seq_B", "seq_joined", "target_type", "guide_pair" , "guide_pair_sorted", "target_pair_sorted")]


# new_all_pairs <- sort(unique(c(guide_design[['complete_library']]$target_A, guide_design[['complete_library']]$target_B)))
# setdiff(new_all_pairs, all_pairs)


guide_design[['2-target_library']] <- guide_design[['2-complete_library']][(guide_design[['2-complete_library']]$target_pair_sorted %in% gene_selection_table$Gene_Pair) | (guide_design[['2-complete_library']]$target_type %in% c('Single', 'Control', 'Single (Same Gene)')), ]

# remove the same targeting sgRNAs
guide_design[['2-target_library']] <- guide_design[['2-target_library']][!(guide_design[['2-target_library']]$target_type %in% c('Single (Same Gene)')),]
# get subset columns
guide_design[['2-complete_library']] <- guide_design[['2-complete_library']][c("guide_A", "target_A", "seq_A", "guide_B", "target_B", "seq_B", "target_type", "guide_pair", "seq_joined", "target_pair_sorted")]
guide_design[['2-target_library']] <- guide_design[['2-target_library']][c("guide_A", "target_A", "seq_A", "guide_B", "target_B", "seq_B", "target_type", "guide_pair", "seq_joined", "target_pair_sorted")]

guide_design[['2-complete_library']] <- NULL

if (max(table(guide_design[['2-target_library']]$seq_joined)) != 1){
  print('Problem')
}

# data.table::fwrite(guide_design[['1-library_sequences']], file = file.path('Gene_Selection', '1-library_sequences.csv'))
# data.table::fwrite(guide_design[['2-complete_library']], file = file.path('Gene_Selection', '2-complete_library.csv'))
# data.table::fwrite(guide_design[['3-target_library']], file = file.path('Gene_Selection', '3-target_library.csv'))
for (i in seq(dim(guide_design[['1-library_sequences']])[1])){
  curr_sgRNA <- guide_design[['1-library_sequences']]$Guide[i]
  curr_seq <- guide_design[['1-library_sequences']]$gRNA_seq[i]
  
  matching_sgRNA <- guide_design[['2-target_library']]$guide_A == curr_sgRNA
  matching_seq <- guide_design[['2-target_library']]$seq_A == curr_seq
  
  if (sum(matching_sgRNA == matching_seq) != dim(guide_design[['2-target_library']])[1]){
    print('problem')
  }
  
  matching_sgRNA <- guide_design[['2-target_library']]$guide_B == curr_sgRNA
  matching_seq <- guide_design[['2-target_library']]$seq_B == curr_seq
  
  if (sum(matching_sgRNA == matching_seq) != dim(guide_design[['2-target_library']])[1]){
    print('problem')
  }
}

table(guide_design[['2-target_library']]$target_type)

openxlsx::write.xlsx(
  x = guide_design,
  file = file.path('Gene_Selection', 'library_screening_SL_finalized.xlsx'),
  overwrite = TRUE
)