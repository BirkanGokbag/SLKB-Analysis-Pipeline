download.UI <- function(id){
  ns <- NS(id)
  tabPanel("Download & Contact",
           
           fluidPage(
             
             fluidRow(
                      
             column(12, align="center",
             #div(
             tags$table(border = 2,height = '60%', width = '80%', style = 'font-size:120%',
                                  tags$tbody(
                                    tags$tr(
                                      tags$td(align = "center", strong("Data Name")),
                                      tags$td(align = "center", strong("Data Description")),
                                      tags$td(align = "center", strong("Data Download"))
                                    ),
                                    tags$tr(
                                      tags$td(align = "center", "Raw SL Data"),
                                      tags$td(align = "center", "Contains original scores for the CDKO studies."),
                                      tags$td(align = "center", downloadButton(ns('rawSL'), label="rawSL"))
                                    ),
                                    tags$tr(
                                      tags$td(align = "center", "SLKB Calculated SL Scores"),
                                      tags$td(align = "center", "Contains SLKB score calculation for the CDKO studies."),
                                      tags$td(align = "center", downloadButton(ns('calcSL'), label="calcSL"))
                                    ),
                                    tags$tr(
                                      tags$td(align = "center", "SLKB Predicted Pairs"),
                                      tags$td(align = "center", "Contains the Venn diagram contents of SLKB scoring methods, separated by study and cell line."),
                                      tags$td(align = "center", downloadButton(ns('predSL'), label="predSL"))
                                    ),
                                    tags$tr(
                                      tags$td(align = "center", "SQL dump file"),
                                      tags$td(align = "center", "Contains the entirety of SLKB database, from counts to scores."),
                                      tags$td(align = "center", shiny::actionButton(inputId='glink', label="FigShare",
                                                                                    icon = icon("link"),
                                                                                    onclick ="window.open('https://figshare.com/s/06c2fc68cb33ec22f591', '_blank')"))
                                  ),
                                  tags$tr(
                                    tags$td(align = "center", "SLKB Pipeline"),
                                    tags$td(align = "center", "Full SLKB pipeline (i.e., scoring, database creation) can be accessed at the project link."),
                                    tags$td(align = "center", shiny::actionButton(inputId='glink', label="Github",
                                                                                  icon = icon("link"),
                                                                                  onclick ="window.open('https://birkangokbag.github.io/SLKB-Analysis-Pipeline', '_blank')"))
                                  ),
                                  tags$tr(
                                    tags$td(align = "center", "SLKB WebApp Source"),
                                    tags$td(align = "center", "SLKB Webapp can be accessed at the GitHub link. Results from the pipeline can be inserted for browsing."),
                                    tags$td(align = "center", shiny::actionButton(inputId='glink', label="Github",
                                                                                  icon = icon("link"),
                                                                                  onclick ="window.open(https://github.com/BirkanGokbag/SLKB-Analysis-Pipeline/blob/main/SLKB/files/SLKB_webapp.zip', '_blank')"))
                                  )
                                  
                                )
                          )
             
               )
             ),
             hr(),
             fluidRow(
               column(12, align = 'center',
                 h1('Citation', style = 'font-size:200%'),
                 p('If SLKB, through its pipeline or webapp has helped with your research, please cite us!'
                   , style = 'font-size:125%'),
                 p(code('[In Progress]'), style = 'font-size:125%'),
                 # p(code('Gökbağ B, Tang S, Fan K, Cheng L, Li L. SLKB: Synthetic lethality knowledge base for gene combination double knockout experiments [abstract]. In: Proceedings of the 114th Annual Meeting of the American Association for Cancer Research; 2023 Apr 14–19; Orlando. Florida (FL): AACR; 2023. Abstract nr 6581.'
                 #        , style = 'font-size:125%')),
                 p('Bibtex:', style = 'font-size:125%'),
                 p(code('[In Progress]'), style = 'font-size:125%'),
                 # p(code('  @Article{,
                 #            author = {Birkan Gökbağ, Shan Tang, Kunjie Fan, Lijun Cheng, Lang Li},
                 #            title = {SLKB: Synthetic lethality knowledge base for gene combination double knockout experiments},
                 #            journal = {Proceedings of the 114th Annual Meeting of the American Association for Cancer Research},
                 #            year = {2023},
                 #            volume = {},
                 #            pages = {},
                 #            doi = {},
                 #            url = {},
                 #          }'), style = 'font-size:125%')
             )),
             hr(),
             fluidRow(
               column(12, align = 'center',
                 h1('Contact Us!', style = 'font-size:200%'),
                 p('Correspondance Mail: ', style = 'font-size:125%'),
                 p(tags$a('lang.li@osumc.edu', href="mailto:lang.li@osumc.edu"), style = 'font-size:125%')
               )
             )
           )
  )
}