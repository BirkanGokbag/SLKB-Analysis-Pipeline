library(VennDiagram)
library(nVennR)
library(stringr)
rm(list=ls())
gc()

computed_data <- read.csv("../www/all_GI_RESULTS_112822.csv")

temp <- computed_data[computed_data$Study_Source == 'ShanTang',]
temp <- subset(temp, select = -c(1,14))
rownames(temp) <- temp$Gene.Pair
sum(temp$Gene_A == 'LUCIFERASE')
sum(temp$Gene_A == 'EGFP')
sum(temp$Gene_A == 'LACZ')

remove_idx <- temp$Gene_A == 'LUCIFERASE' | temp$Gene_A == 'EGFP' | temp$Gene_A == 'LACZ' | 
  temp$Gene_B == 'LUCIFERASE' | temp$Gene_B == 'EGFP' | temp$Gene_B == 'LACZ'
temp <- temp[!remove_idx, ]
write.csv(temp, file = 'shan_CDKO.csv')

#original_scores <- read.csv("./www/original_GI_110422.csv")
#temp2 <- original_scores[original_scores$Study_Source == 'ShanTang',]
#temp2 <- read.csv('./ShanScore/121122/DKO_22RV1_GI_gene(22Dec).txt', sep = '\t')
temp2 <- read.csv('./ShanScore/121122/DKO_22RV1_GIstd_gene(22Dec).txt', sep = '\t')
#DKO_22RV1_GIstd_gene(22Dec).txt
sorted_genes <- c()
for (i in seq_along(temp2$GI_overall)){
  gene_a <- temp2$target_a_id[i]
  gene_b <- temp2$target_b_id[i]
  sorted_genes <- c(sorted_genes, paste0(sort(c(gene_a, gene_b)), collapse = '_'))
}
temp2$sorted_genes <- sorted_genes
temp2 <- temp2 %>% group_by(sorted_genes) %>% summarise(GI_Score=median(GI_overall))
#summarise_each(funs(median=median(., na.rm=TRUE)))
temp2 <- as.data.frame(temp2)
rownames(temp2) <-  temp2$sorted_genes#temp2$Gene.Pair


#union(temp$Gene_A, temp$Gene_B)
comb_genes <- union(temp$Gene_A, temp$Gene_B)
comb_genes2 <- union(temp$Gene_A, temp$Gene_B)
comb_genes
#PARP1 and the ATM/CHK2/TP53, ATR/CHK1/WEE1

temp <- temp[order(temp$Median.B), ]
temp2 <- temp2[order(temp2$GI_Score), ]
SLs <- c('AR_PARP1', # https://www.nature.com/articles/s41467-017-00393-y#author-information
         #'NRAS_PLK1', #synlethdb 2.0
         'MAP2K1_PIK3CA',
         'HSP90AA1_UPF2',
         'TGFBR2_TOP2A',
         'IRS1_TOP2A',
         'HSP90AA1_MAP3K1')

SynLethDB_scores <- read.csv("../www/SynLethDB_Human_SL.csv")
SynLethDB_pairs <- (SynLethDB_scores$gene_a.name %in% comb_genes) & (SynLethDB_scores$gene_b.name %in% comb_genes)
SynLethDB_scores <- SynLethDB_scores[SynLethDB_pairs, ]
SynLethDB_scores <- SynLethDB_scores[SynLethDB_scores$SL.source != 'Computational Prediction',]
prostate_idx <- grepl('prostate', SynLethDB_scores$SL.cell_line) | grepl('PC3', SynLethDB_scores$SL.cell_line) 
SynLethDB_scores <-SynLethDB_scores[prostate_idx, ]

SLs <- c('AR_PARP1', # https://www.nature.com/articles/s41467-017-00393-y#author-information
         #'NRAS_PLK1', #synlethdb 2.0
         'MAP2K1_PIK3CA',
         'HSP90AA1_UPF2',
         'TGFBR2_TOP2A',
         'IRS1_TOP2A',
         'HSP90AA1_MAP3K1')
SynLethDB_SLs <- c()
for (i in seq(dim(SynLethDB_scores)[1])){
  gene_a <- SynLethDB_scores$gene_a.name[i]
  gene_b <- SynLethDB_scores$gene_b.name[i]
  sorted <- sort(c(gene_a, gene_b))
  SynLethDB_SLs <- c(SynLethDB_SLs, paste(sorted, collapse = '_'))
}
SLs_SynLethDB <- sort(unique(c(SLs, SynLethDB_SLs)))

all_SLs <- list()
all_SLs[['original']] <- c('MAP2K1_PIK3CA',
                           'HSP90AA1_UPF2',
                           'TGFBR2_TOP2A',
                           'IRS1_TOP2A',
                           'HSP90AA1_MAP3K1')
all_SLs[['experimentally_validated']] <- unique(SLs)
all_SLs[['SynLethDB_pairs']] <- unique(SynLethDB_SLs)


combined_SLs <- c()
for (item in names(all_SLs)){
  combined_SLs <- c(combined_SLs, all_SLs[[item]])
}
all_SLs[['combined_SLs']] <- unique(combined_SLs)
scoring_strategies <- c('Horlbeck.Original', 'Median.NB', 'Median.NB.Z', 'Median.B', 'Median.B.Z', 'MAGECK', 'MAGECK.Z', 'GEMINI')
temp2 <- temp2[order(temp2$GI_Score), ]

item <- 'combined_SLs'
item <- 'experimentally_validated'
for (item in names(all_SLs)){
  print(item)
  current_SLs <- all_SLs[[item]]
  
  sums_original <- sum(which(temp2$sorted_genes %in% current_SLs))
  print('Shan')
  print(sums_original)
  sums_strategies <- list()
  best_strategy <- 'ShanScore'
  min_score <- sums_original
  for (strategy in scoring_strategies){
    temp <- temp[order(temp[[strategy]]), ]
    sums_strategies[[strategy]] <- sum(which(temp$Gene.Pair %in% current_SLs))
    if (sums_strategies[[strategy]] < sums_original){
      print(strategy)
      print(sums_strategies[[strategy]])
      if (sums_strategies[[strategy]] <= min_score){
        min_score <- sums_strategies[[strategy]]
        best_strategy <- strategy
      }
    }
  }
  print('Best Strategy:')
  print(best_strategy)
  print('Difference in Score to ShanScore')
  print(min_score - sums_original)
  print('+++++++++++++++')
}

capture.output(all_SLs, file = "all_SLs.txt")




sums_original <- sum(which(temp2$Gene.Pair %in% SLs))

sums_strategies <- list()
for (strategy in scoring_strategies){
  temp <- temp[order(temp[[strategy]]), ]
  sums_strategies[[strategy]] <- sum(which(temp$Gene.Pair %in% SLs))
  if (sums_strategies[[strategy]] < sums_original){
    print(strategy)
  }
}

temp[SLs,]
temp2[SLs,]

computed_data <- read.csv("../www/all_GI_RESULTS_112822.csv")


horlbeck_JURKAT <- computed_data[computed_data$Study_Source == 'Horlbeck' & computed_data$Cell_Line == 'JURKAT',]
horlbeck_K562 <- computed_data[computed_data$Study_Source == 'Horlbeck' & computed_data$Cell_Line == 'K562',]

# sums_strategies[['Median.B.Z']]
# temp <- temp[order(temp[['GEMINI']]), ]

all_top_100_genes <- list()

temp_horlbeck <- horlbeck_JURKAT

scoring_strategies <- c('GEMINI','Horlbeck.Original', 'Median.NB.Z', 'Median.B.Z', 'MAGECK.Z')

for (strategy in scoring_strategies){
  temp_horlbeck <- temp_horlbeck[order(temp_horlbeck[[strategy]]), ]
  top_100_genes <- temp_horlbeck[1:11115,]
  top_100_genes <- c(top_100_genes[,'Gene_A'], top_100_genes[,'Gene_B'])
  top_100_genes <- sort(table(top_100_genes), decreasing = TRUE)
  all_top_100_genes[[strategy]] <- top_100_genes
}


overlapping <- names(all_top_100_genes[[strategy]])
for (strategy in scoring_strategies){
  overlapping <- intersect(overlapping, names(all_top_100_genes[[strategy]]))
}

top_overlapping <- rep(0, length(overlapping))
names(top_overlapping) <- overlapping
for (strategy in scoring_strategies){
  
  top_overlapping <- top_overlapping + all_top_100_genes[[strategy]][overlapping]
}

top_overlapping <- sort(top_overlapping, decreasing = TRUE)
top_overlapping <- top_overlapping[1:100]


overlapping1 <-  top_overlapping
overlapping_JURKAT_K562 <- intersect(names(overlapping1), names(top_overlapping))
for (strategy in scoring_strategies){
  print(strategy)
  print(all_top_100_genes[[strategy]][overlapping_JURKAT_K562][1:6])
}



which(temp$Gene.Pair %in% SLs)
which(temp2$Gene.Pair %in% SLs)

# 
# temp <- temp[order(temp[['Median.B.Z']]), ]
# length(which(temp$Gene.Pair %in% SLs))
# 
# > temp[which(temp$Gene.Pair %in% SLs), 'Gene.Pair']
# [1] "MAP2K1_PIK3CA"   "HSP90AA1_UPF2"   "AR_PARP1"        "HSP90AA1_MAP3K1" "IRS1_TOP2A"      "TGFBR2_TOP2A"   
# > temp2[which(temp2$Gene.Pair %in% SLs), 'Gene.Pair']
# [1] "TGFBR2_TOP2A"    "IRS1_TOP2A"      "MAP2K1_PIK3CA"   "HSP90AA1_UPF2"   "HSP90AA1_MAP3K1" "AR_PARP1"   



which(temp$Gene.Pair %in% SLs)

which(temp2$Gene.Pair %in% SLs)



computed_data <- read.csv("../www/all_GI_RESULTS_112822.csv")

temp <- computed_data[computed_data$Study_Source == 'ShanTang',]
remove_idx <- temp$Gene_A == 'LUCIFERASE' | temp$Gene_A == 'EGFP' | temp$Gene_A == 'LACZ' | 
  temp$Gene_B == 'LUCIFERASE' | temp$Gene_B == 'EGFP' | temp$Gene_B == 'LACZ'
temp <- temp[!remove_idx, ]
computed_data[computed_data$Study_Source == 'ShanTang',] <- temp

computed_data$Cell_Line <- toupper(computed_data$Cell_Line)
computed_data$Study_Source <- toupper(computed_data$Study_Source)

# computed_data$Median.NB <- computed_data$Median.NB.Z
# computed_data$Median.B <- computed_data$Median.B.Z
# computed_data$MAGECK <- computed_data$MAGECK.Z
original_scores <- read.csv("./www/original_GI_110422.csv")

original_scores$Cell_Line <- toupper(original_scores$Cell_Line)
original_scores$Study_Source <- toupper(original_scores$Study_Source)


results_matrix <- matrix(0, 
                         nrow = length(unique(paste0(computed_data$Cell_Line, '_', computed_data$Study_Source))),
                         ncol = 11)
colnames(results_matrix) <- c('Study', 'Cell_Line', 'Data_Size', 'Median.NB', 'Median.NB.Z', 'Median.B', 'Median.B.Z', 'MAGECK', 'MAGECK.Z', 'GEMINI', 'Horlbeck.Original')

curr_index <- 1
top_10p_choice <- '10percent'

study <- 'PARRISH'
cell_line <- 'HELA'

cell_line <- 'PC9'

for (study in unique(computed_data$Study_Source)){
  print(paste('For study:', study))
  curr_study <- computed_data[computed_data$Study_Source == study, ]
  original_study <- original_scores[original_scores$Study_Source == study, ]
  
  for (cell_line in unique(curr_study$Cell_Line)){
    print(paste('For cell line:', cell_line))
    original_subset <- original_study[original_study$Cell_Line == cell_line, ]
    print(sum(original_subset$GI_Score))
  }
}

scoring_strategies <- c('Median.NB', 'Median.B', 'GEMINI', 'MAGECK', 'Horlbeck.Original', 'Median.NB.Z', 'Median.B.Z', 'MAGECK.Z')

for (study in unique(computed_data$Study_Source)){
  print(paste('For study:', study))
  curr_study <- computed_data[computed_data$Study_Source == study, ]
  original_study <- original_scores[original_scores$Study_Source == study, ]
  
  for (cell_line in unique(curr_study$Cell_Line)){
    results_matrix[curr_index, 'Study'] <- study
    results_matrix[curr_index, 'Cell_Line'] <- cell_line
    
    print(paste('For cell line:', cell_line))
    save_loc <- file.path(paste0('results_and_original+', top_10p_choice), study, cell_line)
    
    dir.create(save_loc, recursive = TRUE)
    
    curr_subset <- curr_study[curr_study$Cell_Line == cell_line, ]
    
    original_subset <- original_study[original_study$Cell_Line == cell_line, ]
    original_subset <- original_subset[order(original_subset$GI_Score), ]
    # 
    # genes_after_filtering <- sort(unique(intersect(union(curr_subset$Gene_A, curr_subset$Gene_B),
    #                                                union(original_subset$Gene_A, original_subset$Gene_B))))
    
    genes_after_filtering_pairs <- sort(intersect(curr_subset$Gene.Pair, original_subset$Gene.Pair))
    
    #idx <- c()
    # for (i in seq(dim(original_subset)[1])){
    #   if ((original_subset$Gene_A[i] %in% genes_after_filtering) & (original_subset$Gene_B[i] %in% genes_after_filtering)){
    #     idx <- c(idx, i)
    #   }
    # }
    #genes_after_filtering_pairs %in% original_subset$Gene.Pair
    #original_subset <- original_subset[idx, ]
    original_subset <- original_subset[original_subset$Gene.Pair %in% genes_after_filtering_pairs,]
    
    #idx <- c()
    # for (i in seq(dim(curr_subset)[1])){
    #   if ((curr_subset$Gene_A[i] %in% genes_after_filtering) & (curr_subset$Gene_B[i] %in% genes_after_filtering)){
    #     idx <- c(idx, i)
    #   }
    # }
    #curr_subset <- curr_subset[idx, ]
    curr_subset <- curr_subset[curr_subset$Gene.Pair %in% genes_after_filtering_pairs,]
    
    #########
    
    if (grepl('percent', top_10p_choice, fixed = TRUE)){
      top_10p <- as.numeric(gsub('percent', '', top_10p_choice, fixed = TRUE))
      top_10p <- round(dim(curr_subset)[1] * top_10p / 100)
    } else {
      top_10p <- as.numeric(top_10p_choice)
    }
    top_10p <- min(top_10p, dim(original_subset)[1])
    
    original_subset <- original_subset[order(original_subset$GI_Score), 'Gene.Pair']
    
    # add the total gene pair number
    results_matrix[curr_index, 'Data_Size'] <- length(original_subset)
    
    original_subset <- original_subset[1:top_10p]
    
    top_genes <- list()
    
    for (approach in scoring_strategies){
      current_pairs <- curr_subset[order(curr_subset[,approach]), ]
      current_pairs <- current_pairs[current_pairs[, approach] != Inf, ]
      current_pairs <- c(current_pairs[,'Gene_A'], current_pairs[,'Gene_B'])
      current_pairs <- sort(table(current_pairs), decreasing = TRUE)
      
      top_genes[[approach]] <- current_pairs
    }
    
    all_top_genes <- c()
    for (approach in scoring_strategies){
      
    }
    
      
      
      
      
      current_pairs <- current_pairs[1:top_10p, 'Gene.Pair']
      current_pairs <- current_pairs[!is.na(current_pairs)]
      
      intersecting_genes <- intersect(current_pairs, original_subset)
      intersecting_single_genes <- c(str_split_fixed(intersecting_genes, pattern = '_', n = 2)[,1],
                                     str_split_fixed(intersecting_genes, pattern = '_', n = 2)[,2])
      
      intersecting_single_genes <- sort(table(intersecting_single_genes), decreasing = TRUE)
      
      write.csv(as.data.frame(intersecting_single_genes), file = file.path(save_loc, 'frequency_table.csv'))
      write.csv(as.data.frame(intersecting_genes), file = file.path(save_loc, 'intersecting_SL_pairs.csv'))
      
      
      union_genes <- union(current_pairs, original_subset)
      
      percentage_overlap <- round((length(intersecting_genes) * 100/length(union_genes)), 2)
      
      results_matrix[curr_index, approach] <- paste0(percentage_overlap, '%')
      
      print(paste0('Union For: ', approach, ' - Percentage Overlap: ', percentage_overlap, '%'))
    }
    print('-----------------------------------')
    curr_index <- curr_index + 1
  }
  
}

all_top_100_genes <- list()
for (strategy in scoring_strategies){
  temp <- temp[order(temp[[strategy]]), ]
  top_100_genes <- temp[1:100,]
  top_100_genes <- c(top_100_genes[,'Gene_A'], top_100_genes[,'Gene_B'])
  top_100_genes <- sort(table(top_100_genes), decreasing = TRUE)
  all_top_100_genes[[strategy]] <- top_100_genes[1:10]
}


write.csv(results_matrix, file = paste0('original_score_setting_', top_10p_choice, '.csv'))
write.csv(results_matrix, file = paste0('original_score_setting_TEMP_', top_10p_choice, '.csv'))





