BioCManagerLibraries <- c()
requiredLibraries <- c(BioCManagerLibraries, 
                       "shiny",
                       "VennDiagram",
                       "nVennR",
                       "visNetwork",
                       "igraph",
                       "DT",
                       'dplyr',
                       'dbplyr',
                       "shinyWidgets",
                       "ggVennDiagram",
                       "ggplot2",
                       "readxl",
                       "shinythemes",
                       "stringr",
                       'DBI',
                       'pool'
                       )

for (packageName in requiredLibraries){
  if (!is.element(packageName, installed.packages()[,1])){
    print(paste("Installing package: ", packageName))
    if (packageName %in% BioCManagerLibraries) {
      BiocManager::install(packageName, type="binary")#INSTALL_opts = '--no-lock')
    }
    else {
      install.packages(packageName, dependencies = TRUE, INSTALL_opts = '--no-lock')
      #install.packages("table1", dependencies = TRUE, INSTALL_opts = '--no-lock')#type="binary")#
      
    }
    
  } 
  
  suppressMessages(library(packageName, character.only = TRUE))
  print(paste("Loaded package: ", packageName))
  
}

# con <- pool::dbPool(drv = RSQLite::SQLite(), 
#                     dbname = "KB/SLKB_sqlite3")
con <- pool::dbPool(
  drv = RMySQL::MySQL(),
  dbname = "SLKB_mysql",
  host = "slkb-mysql.mysql.database.azure.com",
  username = "guest",
  password = "password"
)
#dbListTables(con)

#computed_data <- read.csv('www/SLKB_calculated_scores.csv')
computed_data <- read.csv('www/SLKB_calculated_scores_horlbeck.csv')

original_scores <- tbl( con, sql(sqlInterpolate(con, 'SELECT * FROM CDKO_ORIGINAL_SL_RESULTS'))) %>% collect()

# computed_data <- read.csv("../www/all_GI_RESULTS_102322.csv")
# original_scores <- read.csv("../www/original_GI_102322.csv")

study <- '30033366'

curr_study <- computed_data[computed_data$study_origin == study, ]
original_study <- original_scores[original_scores$study_origin == study, ]

top_10p <- 10

cell_line <- 'JURKAT'

for (cell_line in c('JURKAT', 'K562')){
  #print(paste('For:', cell_line))
  curr_subset <- curr_study[curr_study$cell_line_origin == cell_line, ]
  # curr_study2 <- computed_data[computed_data$Study_Source == study, ]
  # curr_subset2 <- curr_study[curr_study$Cell_Line == cell_line, ]
  
  
  original_subset <- original_study[original_study$cell_line_origin == cell_line, ]
  original_subset <- original_subset[order(original_subset$SL_score), ]
  
  
  # new_pairs <- c()
  # for (i in strsplit(original_subset$gene_pair, split = '_')){
  #   new_pairs <- c(new_pairs, paste(i, collapse = '|'))
  # }
  # 
  # original_subset$gene_pair <- new_pairs
  
  # 
  genes_after_filtering <- sort(unique(intersect(union(curr_subset$gene_1, curr_subset$gene_2),
                                                 union(original_subset$gene_1, original_subset$gene_2))))
  
  print(length(setdiff(union(curr_subset$gene_1, curr_subset$gene_2), union(original_subset$gene_1, original_subset$gene_2))))
  
  
  #genes_after_filtering_pairs <- sort(intersect(curr_subset$gene_pair, original_subset$gene_pair))
  
  #idx <- c()
  # for (i in seq(dim(original_subset)[1])){
  #   if ((original_subset$Gene_A[i] %in% genes_after_filtering) & (original_subset$Gene_B[i] %in% genes_after_filtering)){
  #     idx <- c(idx, i)
  #   }
  # }
  #genes_after_filtering_pairs %in% original_subset$Gene.Pair
  #original_subset <- original_subset[idx, ]
  original_subset <- original_subset[original_subset$gene_pair %in% genes_after_filtering_pairs,]
  
  #idx <- c()
  # for (i in seq(dim(curr_subset)[1])){
  #   if ((curr_subset$Gene_A[i] %in% genes_after_filtering) & (curr_subset$Gene_B[i] %in% genes_after_filtering)){
  #     idx <- c(idx, i)
  #   }
  # }
  #curr_subset <- curr_subset[idx, ]
  curr_subset <- curr_subset[curr_subset$gene_pair %in% genes_after_filtering_pairs,]
  
  
  #########
  top_10p <- round(dim(curr_subset)[1] * 10 / 100)
  
  horlbeck <- curr_subset[order(curr_subset$HORLBECK_SCORE_SL_score), ]
  rownames(horlbeck) <- horlbeck$gene_pair
  
  horlbeck <- horlbeck[horlbeck$HORLBECK_SCORE_SL_score != Inf, ]
  
  horlbeck <- horlbeck$gene_pair[1:top_10p]
  horlbeck <- horlbeck[!is.na(horlbeck)]
  
  horlbeck_original <- as.data.frame(original_subset[order(original_subset$SL_score), ])
  rownames(horlbeck_original) <- horlbeck_original$gene_pair
  horlbeck_original <- horlbeck_original$gene_pair[1:top_10p]
  
  overlapping_genes <- intersect(horlbeck, horlbeck_original)
  horlbeck_original_only <- setdiff(horlbeck_original, horlbeck)
  horlbeck_only <- setdiff(horlbeck, horlbeck_original)
  union_genes <- union(horlbeck, horlbeck_original)
  
  #print(paste0('Percentage Overlap: ', length(overlapping_genes) * 100/top_10p, '%'))
  print(paste0('top10p For: ', cell_line, ' - Percentage Overlap: ', round(length(overlapping_genes) * 100/top_10p, 2), '%'))
  print(paste0('Union For: ', cell_line, ' - Percentage Overlap: ', round(length(overlapping_genes) * 100/length(union_genes), 2), '%'))
  # 10000:
  # [1] "For: JURKAT"
  # [1] "Percentage Overlap: 97.24%"
  # [1] "For: K562"
  # [1] "Percentage Overlap: 95.83%"
  # 1000:
  # [1] "For: JURKAT"
  # [1] "Percentage Overlap: 89.3%"
  # [1] "For: K562"
  # [1] "Percentage Overlap: 86.4%"
  
  # 1000
  # [1] "top10p For: JURKAT - Percentage Overlap: 97.3%"
  # [1] "Union For: JURKAT - Percentage Overlap: 94.74%"
  # [1] "top10p For: K562 - Percentage Overlap: 96.6%"
  # [1] "Union For: K562 - Percentage Overlap: 93.42%"
  
  # 10000
  # [1] "top10p For: JURKAT - Percentage Overlap: 98.25%"
  # [1] "Union For: JURKAT - Percentage Overlap: 96.56%"
  # [1] "top10p For: K562 - Percentage Overlap: 97.3%"
  # [1] "Union For: K562 - Percentage Overlap: 94.74%"
  
  # actual top 10%
  # [1] "top10p For: JURKAT - Percentage Overlap: 98.15%"
  # [1] "Union For: JURKAT - Percentage Overlap: 96.36%"
  # [1] "top10p For: K562 - Percentage Overlap: 97.38%"
  # [1] "Union For: K562 - Percentage Overlap: 94.9%"
}

