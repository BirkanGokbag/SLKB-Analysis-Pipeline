
browseNetworkServer <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
      
      ns <- session$ns
      
      # reactive_data <- reactiveValues(plot = visNetwork(curr.graph$nodes, curr.graph$edges),
      #                                 table = data.all,
      #                                 mode = "all")
      
    }
  )
}