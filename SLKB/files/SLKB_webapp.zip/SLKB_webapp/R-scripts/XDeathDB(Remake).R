library(openxlsx)
library(visNetwork)
library(dplyr)
library(nVennR)
library(VennDiagram)
library(igraph)
library(ggplot2)
library(ggVennDiagram)
library(stringr)
library(ggvenn)
library(biomaRt)
library(KEGGREST)


rm(list=ls())
gc()

#useEnsembl(mirror = 'useast.ensembl.org')

human_set = useMart("ensembl", dataset = "hsapiens_gene_ensembl", host = "https://dec2021.archive.ensembl.org")
mouse_set = useMart("ensembl", dataset = "mmusculus_gene_ensembl", host = "https://dec2021.archive.ensembl.org")

# Basic function to convert mouse to human gene names
convert_to_human <- function(genes, mouse_set, human_set){

  genesV2 = getLDS(attributes = c("mgi_symbol"), filters = "mgi_symbol", values = genes, mart = mouse_set, attributesL = c("hgnc_symbol"), martL = human_set, uniqueRows=T)
  humanx <- unique(genesV2[, 2])
  return(humanx)
}

# annotation file
cell_death <- read.xlsx(xlsxFile = 'DKO_22RV1_target_LJ.xlsx', sheet = 'Annotation_CD_pathway')

unique(cell_death$Pathways_Genes)

# create a variable for target annotations
annotations <- data.frame('annotation' = cell_death$Cell.death,
                          'genes' = cell_death$Pathways_Genes)

#annotations$joined <- paste0(annotations$annotation, '_', annotations$genes)

annotations <- annotations %>% distinct(annotation, genes)


pathway_list <- list()
for (pathway in unique(annotations$annotation)){
  pathway_list[[pathway]] <- annotations[annotations$annotation == pathway, 'genes']
}

overlapping_pathway_list <- list()

########################################

# load external db locations
save_loc <- 'GeneSets'



## APOPTOSIS ##
gene_set_loc <- 'Apoptosis'

GO_db <-read.xlsx(xlsxFile = file.path(save_loc, gene_set_loc, 'GO_Apoptosis_M.xlsx'))
#KEGG_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'KEGG_APOPTOSIS_Orig.txt'), sep = '\t')
REACTOME_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'REACTOME_APOPTOSIS.v2022.1.Hs.tsv'), sep = '\t')

# get the genes
GO_genes <- unique(convert_to_human(GO_db$Symbol, mouse_set, human_set))
KEGG_genes <- keggGet("hsa04210")[[1]]$GENE
KEGG_genes <-  KEGG_genes[seq(0,length(KEGG_genes),2)]
KEGG_genes <- unique(gsub("\\;.*","",KEGG_genes))
REACTOME_genes <- unique(strsplit(REACTOME_db$REACTOME_APOPTOSIS[19], split = ',', fixed = T)[[1]])

all_intersecting <- c(GO_genes, KEGG_genes, REACTOME_genes)
all_intersecting_table <- table(all_intersecting)
# add to the excel

overlapping_pathway_list[[gene_set_loc]] <- list()
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 3])
all_intersecting_table <- table(c(all_intersecting, pathway_list[[gene_set_loc]]))
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 4])
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Gene-Frequencies']] <- all_intersecting_table

## Autosis ##
gene_set_loc <- 'Autosis'

GO_db <-read.xlsx(xlsxFile = file.path(save_loc, gene_set_loc, 'GO_Autosis_M.xlsx'))
KEGG_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'KEGG_Autosis_Orig.txt'), sep = '\t')
REACTOME_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'REACTOME_AUTOPHAGY.v2022.1.Hs.tsv'), sep = '\t')

# get the genes
GO_genes <- unique(convert_to_human(GO_db$Symbol, mouse_set, human_set))

KEGG_genes <- c()
row <- 1
for (row in seq(dim(KEGG_db)[1])){
  split <- strsplit(KEGG_db[row, ], split = ';', fixed = T)[[1]]
  
  curr_genes <- split[[1]]
  curr_genes <- strsplit(curr_genes, split = '   ', fixed = T)[[1]]
  curr_genes <- curr_genes[length(curr_genes)]
  curr_genes <- gsub(" ", "", curr_genes)
  curr_genes <- gsub(",", "&", curr_genes)
  curr_genes <- gsub(";", "&", curr_genes)
  curr_genes <- strsplit(curr_genes, split = '&', fixed = T)[[1]]
  KEGG_genes <- c(KEGG_genes, curr_genes)
}
KEGG_genes <- unique(KEGG_genes)

REACTOME_genes <- unique(strsplit(REACTOME_db$REACTOME_AUTOPHAGY[19], split = ',', fixed = T)[[1]])

all_intersecting <- c(GO_genes, KEGG_genes, REACTOME_genes)
all_intersecting_table <- table(all_intersecting)
# add to the excel

overlapping_pathway_list[[gene_set_loc]] <- list()
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 3])
all_intersecting_table <- table(c(all_intersecting, pathway_list[[gene_set_loc]]))
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 4])
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Gene-Frequencies']] <- all_intersecting_table


## Mitotic - CD ##
gene_set_loc <- 'Mitotic_CD'

GO_db <-read.xlsx(xlsxFile = file.path(save_loc, gene_set_loc, 'GO_Mitotic_cell_cycle_M.xlsx'))
#KEGG_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'KEGG_Autosis_Orig.txt'), sep = '\t')
REACTOME_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'REACTOME_CELL_CYCLE_MITOTIC.v2022.1.Hs.tsv'), sep = '\t')

# get the genes
GO_genes <- unique(convert_to_human(GO_db$Symbol, mouse_set, human_set))
KEGG_genes <- keggGet("hsa04110")[[1]]$GENE
KEGG_genes <-  KEGG_genes[seq(0,length(KEGG_genes),2)]
KEGG_genes <- unique(gsub("\\;.*","",KEGG_genes))
REACTOME_genes <- unique(strsplit(REACTOME_db$REACTOME_CELL_CYCLE_MITOTIC[19], split = ',', fixed = T)[[1]])

all_intersecting <- c(GO_genes, KEGG_genes, REACTOME_genes)
all_intersecting_table <- table(all_intersecting)
# add to the excel

overlapping_pathway_list[[gene_set_loc]] <- list()
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 3])
all_intersecting_table <- table(c(all_intersecting, pathway_list[[gene_set_loc]]))
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 4])
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Gene-Frequencies']] <- all_intersecting_table


## Proliferation ##
gene_set_loc <- 'Proliferation'

GO_db <-read.xlsx(xlsxFile = file.path(save_loc, gene_set_loc, 'GO_Cell_Population_Proliferation_M.xlsx'))
#KEGG_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'KEGG_Autosis_Orig.txt'), sep = '\t')
REACTOME_db <- read.csv(file = file.path(save_loc, gene_set_loc, 'REACTOME_CELL_CYCLE.v2022.1.Hs.tsv'), sep = '\t')

# get the genes
GO_genes <- unique(convert_to_human(GO_db$Symbol, mouse_set, human_set))
KEGG_genes <- keggGet("hsa04110")[[1]]$GENE
KEGG_genes <-  KEGG_genes[seq(0,length(KEGG_genes),2)]
KEGG_genes <- unique(gsub("\\;.*","",KEGG_genes))
REACTOME_genes <- unique(strsplit(REACTOME_db$REACTOME_CELL_CYCLE[19], split = ',', fixed = T)[[1]])

all_intersecting <- c(GO_genes, KEGG_genes, REACTOME_genes)
all_intersecting_table <- table(all_intersecting)
# add to the excel

overlapping_pathway_list[[gene_set_loc]] <- list()
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 3])
all_intersecting_table <- table(c(all_intersecting, pathway_list[[gene_set_loc]]))
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Overlap']] <- names(all_intersecting_table[all_intersecting_table == 4])
overlapping_pathway_list[[gene_set_loc]][['GO-KEGG-REACTOME-XDeathDB-Gene-Frequencies']] <- all_intersecting_table

# write to excel ...

overlapping_pathway_list[['Apoptosis']][['GO-KEGG-REACTOME-XDeathDB-Overlap']]
overlapping_pathway_list[['Apoptosis']][['GO-KEGG-REACTOME-Overlap']]

overlapping_pathway_list[['Autosis']][['GO-KEGG-REACTOME-XDeathDB-Overlap']]
overlapping_pathway_list[['Autosis']][['GO-KEGG-REACTOME-Overlap']]

overlapping_pathway_list[['Mitotic_CD']][['GO-KEGG-REACTOME-XDeathDB-Overlap']]
overlapping_pathway_list[['Mitotic_CD']][['GO-KEGG-REACTOME-Overlap']]

overlapping_pathway_list[['Proliferation']][['GO-KEGG-REACTOME-XDeathDB-Overlap']]
overlapping_pathway_list[['Proliferation']][['GO-KEGG-REACTOME-Overlap']]


overlapping_pathway_list[['Autosis']][['GO-KEGG-REACTOME-XDeathDB-Gene-Frequencies']]


for (pathway in names(overlapping_pathway_list)){
  for (overlap in c('GO-KEGG-REACTOME-Overlap', 'GO-KEGG-REACTOME-XDeathDB-Overlap', 'GO-KEGG-REACTOME-XDeathDB-Gene-Frequencies')){
    if (overlap == 'GO-KEGG-REACTOME-Overlap'){
      sheet_name <- paste0(pathway, '_', 'External')
    } else if (overlap == 'GO-KEGG-REACTOME-XDeathDB-Overlap'){
      sheet_name <- paste0(pathway, '_', 'XDeathDB+external')
    } else {
      sheet_name <- paste0(pathway, '_', 'All_Freqs')
    }
    
    xlsx::write.xlsx(sort(overlapping_pathway_list[[pathway]][[overlap]], decreasing = T), file= 'overlapping_genes_XDeathDB.xlsx', sheetName = sheet_name, append=T)
    
  }
}

