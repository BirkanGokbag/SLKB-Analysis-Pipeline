downloadDataServer <- function(id) {
  moduleServer(
    id,
    function(input, output, session) {
      
      ns <- session$ns
      
      output$fig1_img <- renderImage({
        
        #width  <- session$clientData$output_fig1_width
        #height <- session$clientData$output_fig1_height
        
        list(src = "www/Figure1.png",
             contentType = "image/png",
             alt = "Figure 1: CDKO SL Library Design",
             width = '100%',
             height =  '130%'
        )
      }, deleteFile = F)#, outputArgs = list(width = "50px", height = "50px")
      
      output$fig1 <- renderUI({
        imageOutput(ns("fig1_img"))
      })
      
      output$fig2_img <- renderImage({
        
        #width  <- session$clientData$output_fig1_width
        #height <- session$clientData$output_fig1_height
        
        list(src = "www/Figure2.png",
             contentType = "image/png",
             alt = "Figure 2: SLKB Overview",
             width = '100%',
             height =  '130%'
        )
      }, deleteFile = F)#, outputArgs = list(width = "50px", height = "50px")
      
      output$fig2 <- renderUI({
        imageOutput(ns("fig2_img"))
      })
      
      output$rawSL <- downloadHandler(
        filename <- 'SLKB_original_scores.csv',
        content <- function(file) {
          data.all <- study_SL_init
          write.csv(data.all[, -c(1,2)], file)
        },
        contentType = 'text/csv'
      )
      
      output$calcSL <- downloadHandler(
        filename <- 'SLKB_calculated_scores.csv',
        content <- function(file) {
          data.calc <- computed_SL_init
          write.csv(data.calc[, -c(1,2)], file)
        },
        contentType = 'text/csv'
      )
    }
  )
}